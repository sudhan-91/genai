"""Universal orchestrator agent built on `deepagents`.

Wraps the existing product/shipment/far sub-agent LangGraph graphs as
`CompiledSubAgent`s and lets a `deepagents`-powered main agent select the
appropriate delegated sub-agent(s), run them in sequence/parallel, and synthesize
one final answer.
"""

import asyncio
import json
import logging
import sys
from collections.abc import AsyncIterator
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

from deepagents import create_deep_agent
from deepagents.backends.filesystem import FilesystemBackend
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage

sys.path.append(str(Path(__file__).resolve().parent.parent))

from configs.config_data import configData
from nodes.common_nodes import GPT_ERROR_MESSAGE, _is_api_error
from nodes.far_sub_agent import farSubAgent
from nodes.product_sub_agent import productSubAgent
from nodes.shipment_sub_agent import shipmentSubAgent

from .context import UniversalAgentContext
from .history import load_history_messages, save_turn
from .prompts import SYSTEM_PROMPT
from .subagent_adapters import (
    build_far_subagent,
    build_product_subagent,
    build_shipment_subagent,
)

logger = logging.getLogger(__name__)

config = configData()

BASE_DIR = Path(__file__).resolve().parent
CURRENT_DATE = datetime.now().strftime("%Y-%m-%d")
_universal_agent = None

# `CompiledSubAgent` registered names (used by `stream.subagents`, see
# `subagent_adapters.py`'s `build_*_subagent()`) vs. the `bot_tag` each adapter
# reports through `context.progress_events` -- kept in sync so progress entries
# from both sources use the same `subagent` label.
_SUBAGENT_NAME_TO_BOT_TAG = {
    "product-agent": "product_bot",
    "shipment-agent": "shipment_bot",
    "far-agent": "far_bot",
}


def _normalize_nested_list_values(raw_value: Any) -> list[str]:
    """Flatten nested JSON/list payloads into a deduplicated list of strings."""
    if raw_value is None:
        return []

    if isinstance(raw_value, (list, tuple, set)):
        flattened: list[str] = []
        for item in raw_value:
            flattened.extend(_normalize_nested_list_values(item))
        return flattened

    if isinstance(raw_value, str):
        stripped = raw_value.strip()
        if not stripped:
            return []
        if stripped.startswith("["):
            try:
                parsed = json.loads(stripped)
            except json.JSONDecodeError:
                return [raw_value]
            return _normalize_nested_list_values(parsed)
        return [stripped]

    return [str(raw_value)]


def _deduplicate_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def _normalize_sql_data_source_keys(subagent_results: list[dict]) -> dict[str, str]:
    """Rename merged dataframe payloads to sequential df_1..df_n keys."""
    normalized: dict[str, str] = {}
    next_index = 1
    for entry in subagent_results:
        for _df_key, csv_str in (entry.get("sql_data_source") or {}).items():
            normalized[f"df_{next_index}"] = csv_str
            next_index += 1
    return normalized


def _build_turn_messages(user_input: str, user_id: str, chat_id: str) -> list[BaseMessage]:
    """Load recent chat context and append the current user message."""
    history = load_history_messages(user_id, chat_id)
    reminder = "\n\n[Write the final answer in the same language as the message above.]"
    return [*history, HumanMessage(content=user_input + reminder)]


def _master_langfuse_config(context: UniversalAgentContext) -> dict:
    """Master-run tracing config; its handler is stored on the context so sub-agents nest under it."""
    langfuse_config = config.get_langfuse_config(
        "universal_agent",
        "master_agent",
        user_id=context.user_id,
        session_id=context.chat_id,
        run_name="universal_agent",
    )
    callbacks = langfuse_config.get("callbacks")
    context.langfuse_handler = callbacks[0] if callbacks else None
    return langfuse_config


def _extract_subagent_payloads(context: UniversalAgentContext) -> list[dict]:
    """Return the normalized sub-agent metadata collected during the turn."""
    return list(getattr(context, "subagent_results", []) or [])


def _get_final_answer(result: dict) -> str:
    """Safely extract the last agent message as a human-readable answer."""
    messages = result.get("messages") if isinstance(result, dict) else []
    if not messages:
        return ""

    final_message = messages[-1]
    content = getattr(final_message, "content", "") or ""
    if isinstance(content, list):
        text_parts = []
        for part in content:
            if isinstance(part, dict):
                text = part.get("text")
                if text is not None:
                    text_parts.append(str(text))
                    continue
            text_parts.append(str(part))
        joined = "".join(text_parts)
        return joined
    if not isinstance(content, str):
        return str(content)
    return content


def build_universal_agent():
    """Construct the deep-agent orchestrator that delegates to product, shipment,
    and FAR sub-agents."""
    config = configData()
    product_obj = productSubAgent()
    shipment_obj = shipmentSubAgent()
    far_obj = farSubAgent()

    subagents = [
        build_product_subagent(product_obj.product_app),
        build_shipment_subagent(shipment_obj.shipment_app),
        build_far_subagent(far_obj.far_app),
    ]

    return create_deep_agent(
        model=config.universal_agent_llm,
        system_prompt=SYSTEM_PROMPT.format(date=CURRENT_DATE),
        subagents=subagents,
        memory=["./AGENTS.md"],
        backend=FilesystemBackend(root_dir=str(BASE_DIR)),
        context_schema=UniversalAgentContext,
    )


def get_universal_agent():
    """Lazily build and cache the universal agent singleton."""
    global _universal_agent
    if _universal_agent is None:
        _universal_agent = build_universal_agent()
    return _universal_agent


def invoke_universal_agent(user_input: str, user_id: str, chat_id: str) -> str:
    """Run one universal-agent turn and persist the synthesized answer."""
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})
    context = UniversalAgentContext(user_id=user_id, chat_id=chat_id)

    try:
        result = agent.invoke(
            agent_input,
            config=_master_langfuse_config(context),
            context=context,
        )
        answer = _get_final_answer(result)
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[invoke_universal_agent] GPT API error detected: {exc}")
        answer = GPT_ERROR_MESSAGE
    save_turn(user_id, chat_id, user_input, answer)
    return answer


def invoke_universal_agent_full(user_input: str, user_id: str, chat_id: str) -> dict:
    """Run one turn and return top-level payload metadata plus each sub-agent's
    SQL/table payloads in the shape expected by the rest of the application."""
    context = UniversalAgentContext(user_id=user_id, chat_id=chat_id)
    result = run_universal_agent_turn(user_input, user_id, chat_id, context)
    return build_full_result(user_input, user_id, chat_id, result, context)


def run_universal_agent_turn(user_input: str, user_id: str, chat_id: str, context: UniversalAgentContext) -> dict:
    """Execute one full turn against the supplied runtime context."""
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    try:
        return agent.invoke(
            cast(Any, {"messages": messages}),
            config=_master_langfuse_config(context),
            context=context,
        )
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[run_universal_agent_turn] GPT API error detected: {exc}")
        return {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}


async def stream_universal_agent_turn_events(
    user_input: str,
    user_id: str,
    chat_id: str,
    context: UniversalAgentContext,
) -> AsyncIterator[dict]:
    """Stream the coordinator's final answer plus subagent completion for one turn.

    Uses LangGraph/deepagents' typed `version="v3"` streaming protocol
    (`stream.messages` / `stream.subagents`, see
    https://docs.langchain.com/oss/python/deepagents/event-streaming) instead of
    raw `v2` event dicts. `message.text` only ever yields real text deltas, so
    tool-call-planning turns (which stream no text) are skipped by construction
    -- no more inferring "is this the final answer" from raw chunk shape.

    Yields coordinator text deltas, labeled subagent answer deltas, and one
    final `on_chain_end` event with the graph output. The subagent text uses a
    separate event so clients can display it without merging it into the final
    coordinator synthesis.

    Each subagent (`product-agent`/`shipment-agent`/`far-agent`, all registered
    as `CompiledSubAgent`s and auto-named via `lc_agent_name`) gets its own
    `stream.subagents` handle; draining it concurrently with the coordinator's
    text stream appends `subagent_completed`/`subagent_failed` milestones to
    `context.progress_events`. Sub-agent answer tokens are not visible on the
    outer v3 stream (each adapter runs its graph in its own event loop), so they
    arrive through `context.stream_sink`. `subagent_started` (with the delegated task text) is still
    reported by `subagent_adapters.py`, since the task description isn't
    exposed on this handle.
    """
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})

    # GPT server-side failures (rate limit, timeout, connection) can surface either
    # from `astream_events()` itself or while draining `stream.messages`/`stream.output()`
    # below -- both paths are wrapped so callers still get a usable final answer instead
    # of a raw unhandled exception.
    try:
        stream = await cast(Any, agent).astream_events(
            agent_input,
            version="v3",
            config=_master_langfuse_config(context),
            context=context,
        )

        event_queue: asyncio.Queue = asyncio.Queue()
        stream_done = object()
        # Subscribe to both root projections before either consumer can advance
        # the shared graph pump; StreamChannel does not retain pre-subscription items.
        coordinator_messages = stream.messages.__aiter__()
        subagent_handles = stream.subagents.__aiter__()

        loop = asyncio.get_running_loop()

        def _subagent_sink(bot_tag: str, delta: str) -> None:
            # Called from adapter worker threads, each running its own event loop.
            loop.call_soon_threadsafe(event_queue.put_nowait, {
                "event": "on_subagent_chat_model_stream",
                "name": "summarizer",
                "subagent": bot_tag,
                "data": {"chunk": SimpleNamespace(content=delta)},
            })

        context.stream_sink = _subagent_sink

        async def _drain_subagents(handles) -> None:
            try:
                subagent_tasks = []
                async for sub in handles:
                    subagent_tasks.append(asyncio.create_task(_drain_subagent(sub)))
                if subagent_tasks:
                    await asyncio.gather(*subagent_tasks)
            finally:
                await event_queue.put(stream_done)

        async def _drain_subagent(sub) -> None:
            bot_tag = _SUBAGENT_NAME_TO_BOT_TAG.get(sub.name or "", sub.name or "unknown")
            try:
                await sub.output()
            except Exception as exc:
                context.progress_events.append({
                    "subagent": bot_tag,
                    "stage": "subagent_failed",
                    "message": f"{bot_tag} failed: {exc}",
                    "error": str(exc),
                })
            else:
                context.progress_events.append({
                    "subagent": bot_tag,
                    "stage": "subagent_completed",
                    "message": "",
                })

        async def _drain_coordinator(messages) -> None:
            try:
                async for message in messages:
                    async for delta in message.text:
                        if delta:
                            await event_queue.put({
                                "event": "on_chat_model_stream",
                                "name": message.node,
                                "data": {"chunk": SimpleNamespace(content=delta)},
                            })
            finally:
                await event_queue.put(stream_done)

        coordinator_task = asyncio.create_task(_drain_coordinator(coordinator_messages))
        subagents_task = asyncio.create_task(_drain_subagents(subagent_handles))
        try:
            completed_streams = 0
            while completed_streams < 2:
                item = await event_queue.get()
                if item is stream_done:
                    completed_streams += 1
                    continue
                yield item
            await coordinator_task
            await subagents_task
            output = await stream.output()
        finally:
            context.stream_sink = None
            for task in (coordinator_task, subagents_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(coordinator_task, subagents_task, return_exceptions=True)
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[stream_universal_agent_turn_events] GPT API error detected: {exc}")
        yield {
            "event": "on_chat_model_stream",
            "name": "gpt_error_handler",
            "tags": [],
            "data": {"chunk": SimpleNamespace(content=GPT_ERROR_MESSAGE)},
        }
        yield {
            "event": "on_chain_end",
            "name": "LangGraph",
            "data": {"output": {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}},
        }
        return

    yield {"event": "on_chain_end", "name": "LangGraph", "data": {"output": output}}


def build_full_result(user_input: str, user_id: str, chat_id: str, result: dict, context: UniversalAgentContext) -> dict:
    """Build the final answer payload and persist the turn metadata.

    `deepagents` returns only the final message list, so we recover the per-subagent
    state from the shared `UniversalAgentContext.subagent_results` side channel.
    """
    answer = _get_final_answer(result)
    subagent_results = _extract_subagent_payloads(context)

    intents = _deduplicate_preserve_order(
        [str(entry.get("subagent")) for entry in subagent_results if entry.get("subagent")]
    )
    intent = intents[0] if len(intents) == 1 else ", ".join(intents)
    sql = [
        query
        for entry in subagent_results
        for query in _normalize_nested_list_values(entry.get("sql"))
    ]

    sql_tables: list[str] = []
    for entry in subagent_results:
        sql_tables.extend(_normalize_nested_list_values(entry.get("sql_tables")))
    sql_tables = _deduplicate_preserve_order(sql_tables)

    reasoning_parts: list[str] = []
    for entry in subagent_results:
        sql_reasoning = str(entry.get("sql_reasoning") or "").strip()
        if sql_reasoning:
            reasoning_parts.append(sql_reasoning)
            continue

        general_statement = str(entry.get("general_statement") or "").strip()
        if general_statement:
            reasoning_parts.append(general_statement)

    reasoning = "\n".join(reasoning_parts)
    sql_data_source = _normalize_sql_data_source_keys(subagent_results)

    save_turn(
        user_id,
        chat_id,
        user_input,
        answer,
        sql=sql,
        intent=intent,
        reasoning=reasoning,
        sql_tables=sql_tables,
        sql_data_source=sql_data_source,
    )

    return {
        "model_output": answer,
        "sql": sql,
        "sql_tables": sql_tables,
        "intent": intent,
        "reasoning": reasoning,
        "sql_data_source": sql_data_source,
        "execution_trace": list(context.execution_trace),
    }
