import json
import traceback
import os
from pathlib import Path
import httpx
import yaml
import boto3
import litellm
from langchain_openai import ChatOpenAI
from langchain_community.chat_models import ChatLiteLLM
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler
from dotenv import load_dotenv
import base64

CONFIG_DIR = Path(__file__).resolve().parent
load_dotenv(CONFIG_DIR / ".env")

with (CONFIG_DIR / "global_config.json").open("r", encoding="utf-8") as f:
    config = json.load(f)

with (CONFIG_DIR / "app_config_v2.yaml").open("r", encoding="utf-8") as f:
    app_config = yaml.safe_load(f)


class configData(object):

    def __init__(self):
        try:
            self.langfuse_enabled = os.getenv("LANGFUSE_ENABLED", "true").strip().lower() in ("1", "true", "yes", "on")
            self.langfuse_client = None
            self.langfuse_handler = None
            usecase_config = app_config["usecase"]
            common_config = app_config["common"]
            # cert_path = r"configs\cert\ca-bundle.crt"
            token = f'{os.getenv("token")}'
            headers = {'Authorization': f"Bearer {token}", }

            # ENV type
            self.env = os.getenv("ENV") or "dev"  # Default to 'dev' if ENV is not set

            # LLM Configurations
            self.gpt4ifx_base_url = config['gpt4ifx_config']['gpt4ifx_base_url']
            self.service_user_name = os.getenv("SERVICE_USER_NAME")
            self.service_password = os.getenv("SERVICE_PASSWORD")
            self.model = config['gpt4ifx_config']['llm_model']
            self.response_model = config['gpt4ifx_config']['response_llm_model']
            self.chat_llm_model = config['gpt4ifx_config']['chat_llm_model']
            self.litellm_url = config['gpt4ifx_config']['litellm_url']
            self.litellm_api_key = os.getenv("LITELLM_API_KEY", "sk-xfu1Ted0CNKSIH-TueJp0A")
            self.max_tokens = config['gpt4ifx_config'].get('max_tokens', 800)
            self.max_tokens_answer = config['gpt4ifx_config'].get('max_tokens_answer', 1500)
            self.max_tokens_chat = config['gpt4ifx_config'].get('max_tokens_chat', 500)
            self.temperature = config['gpt4ifx_config']['temperature']
            print(os.getcwd())
            CERT_PATH = os.environ.get("SSL_CERT_FILE", "configs\cert\ca-bundle.crt")
            os.environ.setdefault("SSL_CERT_FILE", CERT_PATH)
            # ---- LiteLLM SSL Configuration ----
            litellm.ssl_verify = CERT_PATH  # Use cert path for verification

            # ---- Model Initialization ----
            # Default LLM for general use
            self.llm = ChatLiteLLM(
                model=self.model,
                api_key=os.environ.get("LITELLM_API_KEY", "sk-xfu1Ted0CNKSIH-TueJp0A"),
                api_base=self.litellm_url,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                max_retries=0,
            )
            self.memory_llm = ChatLiteLLM(
                model=self.model,
                api_key=os.environ.get("LITELLM_API_KEY", "sk-xfu1Ted0CNKSIH-TueJp0A"),
                api_base=self.litellm_url,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                max_retries=0,
            )

            self.response_llm = ChatOpenAI(
                model=self.response_model,
                api_key=self.litellm_api_key,
                base_url=self.litellm_url,
                max_completion_tokens=self.max_tokens_answer,
                temperature=self.temperature,
                streaming=True,
                http_client=httpx.Client(verify=False)
            )

            self.chat_llm = ChatOpenAI(
                model=self.chat_llm_model,
                api_key=self.litellm_api_key,
                base_url=self.litellm_url,
                max_completion_tokens=self.max_tokens_chat,
                http_client=httpx.Client(verify=False)
            )

            # deepagents orchestrator model: ChatOpenAI (not ChatLiteLLM) because the
            # installed litellm SDK's `client.acreate` now resolves to vector-store
            # creation instead of chat completion, breaking langchain_community's
            # deprecated ChatLiteLLM wrapper for tool-calling agent loops.
            self.universal_agent_llm = ChatOpenAI(
                model=self.response_model,
                api_key=self.litellm_api_key,
                base_url=self.litellm_url,
                max_completion_tokens=self.max_tokens_answer,
                http_client=httpx.Client(verify=False)
            )

            # Embedding model
            self.embedding_model = config['gpt4ifx_config']['embedding_model']
            self.reranker_model = config['gpt4ifx_config'].get('reranker_model', os.getenv('RERANKER_MODEL', 'bge-reranker-v2-m3'))

            # ELK Configurations
            self.es_host = config['es_config']['es_host']
            self.es_username = config['es_config']['es_username']
            self.es_password = f'{os.getenv("ES_PASSWORD")}'

            self.chat_table = config["user_information"]["chat_history"]
            self.session_table = config["user_information"]["session_data"]
            self.prodMgmt_chat_history_table = config["user_information"]["prodMgmt_chat_history"]
            self.prompt_table = config["user_information"]["prompt"]
            self.file_details = config["user_information"]["file_details"]

            self.dive_host = config['dive_config']['host']
            self.dive_port = config['dive_config']['port']
            self.dive_service_name = config['dive_config']['service_name']
            self.dive_username = f'{os.getenv("dive_username")}'#os.getenv("SERVICE_USER_NAME")#
            self.dive_password = f'{os.getenv("dive_password")}'#os.getenv("SERVICE_USER_PASSWORD")#

            denodo_mcp_cfg = config.get('denodo_mcp_config', {})
            self.denodo_mcp_url = denodo_mcp_cfg.get('url', '')
            self.denodo_mcp_auth_scheme = denodo_mcp_cfg.get('auth_scheme', 'Basic')
            #self.denodo_mcp_api_key = os.getenv("DENODO_MCP_API_KEY")
            self.denodo_mcp_api_key = base64.b64encode(f"{self.dive_username}:{self.dive_password}".encode("ascii")).decode("ascii")

            self.qualitics_host = config['qualitics_db_config']['host']
            self.qualitics_port = config['qualitics_db_config']['port']
            self.qualitics_domain = config['qualitics_db_config']['domain']
            self.qualitics_far_database = config['qualitics_db_config']['far_database']
            self.qualitics_far_username = os.getenv("qualitics_far_username")
            self.qualitics_far_password = os.getenv("qualitics_far_password")
            self.qualitics_quai_database = config['qualitics_db_config']['user_database']
            self.qualitics_quai_username = os.getenv("qualitics_quai_username")
            self.qualitics_quai_password = os.getenv("qualitics_quai_password")

            plm_cfg = config.get('plm_config', {})
            self.plm_token_url = plm_cfg.get('token_url', "https://ilogin.infineon.com/as/token.oauth2")
            self.plm_client_id = plm_cfg.get("client_id", "PLM ROPC")
            self.plm_client_secret = os.getenv("PLM_CLIENT_SECRET")
            self.plm_username = os.getenv("qualitics_quai_username")
            self.plm_password = os.getenv("qualitics_quai_password")
            self.plm_api_key = os.getenv("PLM_API_KEY")
            self.plm_api_base = plm_cfg.get('api_base', "https://gravitee-gw-plm.intra.infineon.com/plm/dms/oauth/servlet/odata/v7")

            self.topics = config['topics']
            self.row_limit = common_config.get('row_limit', 300)
            self.data_source_row_limit = common_config.get('data_source_row_limit', 1000)



            self.product_table = usecase_config['product_bot'].get('product_table_name_dev', '') if self.env == 'dev' else usecase_config['product_bot'].get('product_table_name_uat', '')
            self.bom_table = usecase_config['product_bot'].get('bom_table_name_dev', '') if self.env == 'dev' else usecase_config['product_bot'].get('bom_table_name_uat', '')
            self.far_table = usecase_config['far_bot'].get('table_name_dev', '') if self.env == 'dev' else usecase_config['far_bot'].get('table_name_uat', '')
            self.qmr_table = usecase_config['far_bot'].get('qmr_table_name_dev', '') if self.env == 'dev' else usecase_config['far_bot'].get('qmr_table_name_uat', '')
            self.sc_table = usecase_config['far_bot'].get('sc_table_name_dev', '') if self.env == 'dev' else usecase_config['far_bot'].get('sc_table_name_uat', '')
            self.rma_table = usecase_config['far_bot'].get('rma_table_name_dev', '') if self.env == 'dev' else usecase_config['far_bot'].get('rma_table_name_uat', '')
            self.shipment_table = usecase_config['shipment_bot'].get('table_name', 'vdb_bl_md_product.bl_mdprd_mp_dset_qualytics_tma_shipment') 

            self._table_placeholder_map = {
                '{PRODUCT_TABLE}': self.product_table,
                '{BOM_TABLE}': self.bom_table,
                '{FAR_TABLE}': self.far_table,
                '{QMR_TABLE}': self.qmr_table,
                '{SC_TABLE}': self.sc_table,
                '{RMA_TABLE}': self.rma_table,
                '{SHIPMENT_TABLE}': self.shipment_table,
            }

            self.product_data_fields = usecase_config['product_bot'].get('data_fields', '')
            self.shipment_data_fields = usecase_config['shipment_bot'].get('data_fields', '')
            self.far_data_fields = usecase_config['far_bot'].get('data_fields', '')

            self.validated_fields = usecase_config['product_bot'].get('validated_fields', [])
            self.product_info_key_attributes = usecase_config['product_bot'].get('product_info_key_attributes', [])
            self.bom_key_attributes = usecase_config['product_bot'].get('bom_key_attributes', [])
            self.product_data_category = usecase_config['product_bot'].get('product_data_category', '')
            self.bom_data_category = usecase_config['product_bot'].get('bom_data_category', '')

            self.question_cls_system_prompt = common_config['question_classifier']['system_prompt']
            self.question_cls_instruction = common_config['question_classifier'].get('instruction_base',"")
            self.question_cls_domain_signals_far = common_config['question_classifier'].get('domain_signals_far', '')
            self.question_cls_domain_signals_shipment = common_config['question_classifier'].get('domain_signals_shipment', '')
            self.question_cls_domain_signals_product = common_config['question_classifier'].get('domain_signals_product', '')
            self.question_cls_domain_signals_default = common_config['question_classifier'].get('domain_signals_default', '')
            self.question_cls_instruction_far = common_config['question_classifier'].get('instruction_far_priority', '')
            self.question_cls_instruction_shipment = common_config['question_classifier'].get('instruction_shipment_priority', '')
            self.question_cls_instruction_product = common_config['question_classifier'].get('instruction_product_priority', '')
            self.question_cls_instruction_default = common_config['question_classifier'].get('instruction_default_priority', '')
            self.question_cls_example = common_config['question_classifier']['examples']

            self.memory_system_prompt = common_config['memory_service']['system_prompt']

            self.summarizer_system_prompt = common_config['summarizer']['system_prompt']
            self.summarizer_instruction = common_config['summarizer']['instruction']
            self.summarizer_enquiry = common_config['summarizer']['enquiry']
            self.product_special_rule = common_config["summarizer"].get("product_special_rule", "")
            self.far_special_rule = common_config["summarizer"].get("far_special_rule", "")
            self.shipment_special_rule = common_config["summarizer"].get("shipment_special_rule", "")
            self.product_multiple_attributes_rule = common_config["summarizer"].get("product_multiple_attributes_rule", "")

            self.result_unidentified_system_prompt = common_config['result_unidentified']['system_prompt']
            self.result_unidentified_user_prompt = common_config['result_unidentified']['user_prompt']
            self.result_unidentified_instruction = common_config['result_unidentified']['instruction']
            self.result_unidentified_instruction_far = common_config['result_unidentified']['far_specific_instruction']

            self.result_unidentified_product_identifier = usecase_config['product_bot']['result_unidentified_identifier']
            self.result_unidentified_far_identifier = usecase_config['far_bot']['result_unidentified_identifier']
            self.result_unidentified_shipment_identifier = usecase_config['shipment_bot']['result_unidentified_identifier']

            self.incomplete_handler_system_prompt = common_config['incomplete_handler']['system_prompt']
            self.incomplete_handler_user_prompt = common_config['incomplete_handler']['user_prompt']
            self.incomplete_handler_instruction = common_config['incomplete_handler']['instruction']

            self.small_talk_system_prompt = common_config['small_talk_agent']['system_prompt']
            self.small_talk_product_prompt = common_config['small_talk_agent']['product_prompt']
            self.small_talk_shipment_prompt = common_config['small_talk_agent']['shipment_prompt']
            self.small_talk_far_prompt = common_config['small_talk_agent']['far_prompt']
            self.small_talk_greeting_prompt = common_config['small_talk_agent']['greeting_prompt']
            self.small_talk_irrelevant_prompt = common_config['small_talk_agent']['irrelevant_prompt']
            self.small_talk_instruction = common_config['small_talk_agent']['instruction']

            self.text_to_sql_functions_allowed = common_config.get('text_to_sql_functions_allowed', '')
            # NOTE: table placeholders (e.g. {PRODUCT_TABLE}) are resolved here, eagerly, so that
            # every downstream consumer (LLM prompts, DDL table-name extraction, question classifier)
            # always sees real table names instead of leaking unresolved "{...}" tokens into prompts.
            self.product_system_prompt = self.replace_table_placeholders(usecase_config["product_bot"]["text_to_sql"]["system_prompt"])
            self.product_ddl = self.replace_table_placeholders(usecase_config["product_bot"]["text_to_sql"]["ddl"])
            self.product_instruction = self.replace_table_placeholders(usecase_config["product_bot"]["text_to_sql"]["instruction"])
            self.product_example = self.replace_table_placeholders(usecase_config["product_bot"]["text_to_sql"]["example"])
            self.product_identifier = usecase_config["product_bot"]["identifier"]
            self.bom_identifier = usecase_config["product_bot"]["bom_identifier"]
            self.product_table_name = usecase_config["product_bot"].get("product_table_name", self.product_table)
            self.bom_table_name = usecase_config["product_bot"].get("bom_table_name", self.bom_table)

            self.mulprod_system_prompt = self.replace_table_placeholders(usecase_config["multiple_product_request"]["text_to_sql"]["system_prompt"])
            self.mulprod_ddl = self.product_ddl
            self.mulprod_header_columns = usecase_config["multiple_product_request"]["text_to_sql"]["column_list"]
            self.mulprod_instruction = self.replace_table_placeholders(usecase_config["multiple_product_request"]["text_to_sql"]["instruction"])

            self.shipment_system_prompt = self.replace_table_placeholders(usecase_config["shipment_bot"]["text_to_sql"]["system_prompt"])
            self.shipment_ddl = self.replace_table_placeholders(usecase_config["shipment_bot"]["text_to_sql"]["ddl"])
            self.shipment_instruction = self.replace_table_placeholders(usecase_config["shipment_bot"]["text_to_sql"]["instruction"])
            self.shipment_example = self.replace_table_placeholders(usecase_config["shipment_bot"]["text_to_sql"]["example"])
            self.shipment_identifier = usecase_config["shipment_bot"]["identifier"]
            self.shipment_key_attributes = usecase_config["shipment_bot"]["shipment_key_attributes"]
            self.shipment_data_category = usecase_config["shipment_bot"]["data_category"]
            self.shipment_table_name = usecase_config["shipment_bot"].get("table_name", self.shipment_table)

            self.far_system_prompt = self.replace_table_placeholders(usecase_config["far_bot"]["text_to_sql"]["system_prompt"])
            self.far_ddl = self.replace_table_placeholders(usecase_config["far_bot"]["text_to_sql"]["ddl"])
            self.far_instruction = self.replace_table_placeholders(usecase_config["far_bot"]["text_to_sql"]["instruction"])
            self.far_example = self.replace_table_placeholders(usecase_config["far_bot"]["text_to_sql"]["example"])
            self.far_identifier = usecase_config["far_bot"]["identifier"]
            self.far_key_attributes = usecase_config["far_bot"]["far_key_attributes"]
            self.far_data_category = usecase_config["far_bot"]["data_category"]
            self.far_table_name = usecase_config["far_bot"].get("table_name", self.far_table)
            self.qmr_key_attributes = usecase_config["far_bot"].get("qmr_key_attributes", [])
            self.qmr_table_name = usecase_config["far_bot"].get("qmr_table_name", self.qmr_table)
            self.sc_key_attributes = usecase_config["far_bot"].get("sc_key_attributes", [])
            self.sc_table_name = usecase_config["far_bot"].get("sc_table_name", self.sc_table)
            self.rma_key_attributes = usecase_config["far_bot"].get("rma_key_attributes", [])
            self.rma_table_name = usecase_config["far_bot"].get("rma_table_name", self.rma_table)

            # Customer audit
            # self.template_index = app_config['customer_audit']['template_index']
            self.check_list_index = app_config['customer_audit']['check_list_index']
            self.windchill_templates_index = app_config['customer_audit']['windchill_templates_index']
            self.check_list_config_index = app_config['customer_audit']['check_list_config_index']
            self.s3_endpoint = app_config['customer_audit']['s3_endpoint']
            self.s3_bucket_name = app_config['customer_audit']['s3_bucket_name']
            self.s3_upload_folder = app_config['customer_audit']['s3_upload_folder']
            self.s3_download_folder = app_config['customer_audit']['s3_download_folder']
            self.audit_upload_sessions_table = app_config['customer_audit']['audit_upload_sessions_table']
            self.audit_jobs_table = app_config['customer_audit']['audit_jobs_table']
            self.s3_access_key = os.getenv("s3_access_key","")
            self.s3_secret_key = os.getenv("s3_secret_key","")
            self.s3_client = boto3.client(
                "s3",
                endpoint_url=self.s3_endpoint,
                aws_access_key_id=self.s3_access_key,
                aws_secret_access_key=self.s3_secret_key,
                verify=False
                )
            self.similarity_threshold = app_config['customer_audit']['similarity_threshold']
            self.top_k = app_config['customer_audit']['top_k']
            self.match_conditions = app_config['customer_audit']['match_conditions']
            self.model_path = app_config['customer_audit'].get('model_path', 'Tokenizer_Model')
            self.chunk_size = app_config['customer_audit'].get('chunk_size', 512)
            self.chunk_overlap = app_config['customer_audit'].get('chunk_overlap', 50)
            self.max_workers = app_config['customer_audit'].get('max_workers', 4)

            # File extractor
            self.file_extractor_chunk_size = app_config['file_extractor']['chunk_size']
            self.overlap_size = app_config['file_extractor']['overlap_size']

            # Production management
            self.doc_management_memory_prompt = app_config['production_management']['memory_service']['system_prompt']
            self.doc_management_retrieval_prompt = app_config['production_management']['doc_retrieval']['system_prompt']
            self.doc_management_answer_generator_prompt = app_config['production_management']['answer_generator']['system_prompt']
            self.production_management_index = app_config['production_management']['production_management_index']
            self.production_management_meta_db = app_config['production_management'].get('production_management_meta_db', '[dbo].[QUAI_PRODCT_METADATA_v1]')
            self.retrieved_top_k = app_config['production_management']['retrieved_top_k']
            self.reranker_top_n = app_config['production_management'].get('reranker_top_n', 10)

            self.environment = f'{os.getenv("ENVIRONMENT")}'
            if self.langfuse_enabled:
                try:
                    self.langfuse_client = Langfuse(
                        secret_key=os.getenv("LANGFUSE_SECRET_KEY",""),
                        public_key=os.getenv("LANGFUSE_PUBLIC_KEY",""),
                        host=os.getenv("LANGFUSE_HOST",""),
                        httpx_client=httpx.Client(verify=False)
                    )
                    self.langfuse_handler = CallbackHandler()
                except Exception:
                    self.langfuse_enabled = False
                    self.langfuse_client = None
                    self.langfuse_handler = None
                    print(f'Error in Lanfuse Initializer {traceback.print_exc()}')

        except Exception:
            print(f'Error in configData {traceback.print_exc()}')

    def replace_table_placeholders(self, text):
        """Replace generic table placeholders used in bot prompts with the active env-specific values."""
        if not isinstance(text, str) or not text:
            return text
        result = text
        for placeholder, table_name in self._table_placeholder_map.items():
            if table_name:
                result = result.replace(placeholder, table_name)
        return result

    def get_langfuse_config(self, *tags):
        if not self.langfuse_enabled or self.langfuse_handler is None:
            return {}
        return {
            "callbacks": [self.langfuse_handler],
            "metadata": {"langfuse_tags": [self.environment, *tags]},
        }






