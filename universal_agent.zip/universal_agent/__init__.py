# `update_agent` supports both skill mode and the original sub-agent mode (see
# `is_skill_invocation` / UNIVERSAL_AGENT_MODE). `agent.py` is kept unchanged as the
# sub-agent-only reference implementation.
from .update_agent import (
    build_universal_agent,
    build_full_result,
    get_universal_agent,
    invoke_universal_agent,
    invoke_universal_agent_full,
    run_universal_agent_turn,
    stream_universal_agent_turn_events,
)
from .context import UniversalAgentContext

__all__ = [
    "build_universal_agent",
    "build_full_result",
    "get_universal_agent",
    "invoke_universal_agent",
    "invoke_universal_agent_full",
    "run_universal_agent_turn",
    "stream_universal_agent_turn_events",
    "UniversalAgentContext",
]
