---
name: product
description: >-
  Answers questions about product master data: part/component attributes, specifications and bill
  of materials (BOM). Use for any question about a specific product or part number, its properties
  or what it is made of. Signals: sales/product name, SP number, MA number/SAP MATNR, OPN, basic
  type, BAU number, package name/type, product line (PL), division, MSL, CDM, HBM, QA milestone,
  M9 release/mass production date, Pre-M9, product/material status, halogen/lead free, RoHS,
  front-end/back-end manufacturing locations, country of diffusion/assembly/origin, package
  dimensions, marking, process technology/node, die thickness, moulding, bond wire, die attach,
  leadframe, plating, net weight, chips per wafer, packing unit, shipping box/tape and reel
  dimensions, moisture packing, shelf life, ESD as a spec. Use FIRST when a question says
  since/after/before mass production, M9 or MP for FAR or shipment data: resolve that date here,
  then pass it on as a filter.
---

## CRITICAL EXECUTION RULE
- ALL script executions in this skill MUST be run using the **`bash` tool directly**, invoked by YOU (the main agent).
- **NEVER use the `task` tool, sub-agent, or any form of delegation** to run these scripts. Sub-agents do NOT have `bash` or network access and WILL fail.
- If you find yourself about to call `task` for running a script in `scripts/`, STOP and call `bash` instead.

## Workflow overview


```
Step 1 generate SQL -> Step 2 execute + post-process -> Step 3 route on `next_action`
      ^                                                  |
      +---------------- "retry" (max 6 attempts) <-------+
                                                         +-> "done"                -> Step 5 summarize
                                                         +-> "incomplete_handler"  -> Step 4a
                                                         +-> "result_unidentified" -> Step 4b
                                                         +-> "sql_error_handler"   -> Step 4c
```

Track these values across the loop: `question` (the user's question), `attempt` (starts at 1),
`prior_table_sql` (false until an attempt reports `table_found: true`), and the latest
`retry_summary` and `retry_mode`.

### Step 1: Text-to-SQL conversion

1. **Capture the raw user question** — use the user's question exactly as asked, without
   paraphrasing or summarizing, so no intent or filter detail is lost before SQL generation.

2. **Read the YAML configuration file** at the RELATIVE path `references/product.yaml`
   (no leading slash — the working directory is already the project root). Top-level keys:
   - `system_prompt`: the SQL generation template and required JSON output format
   - `ddl`: the two table schemas — `[dbo].[QUAI_product_processed]` (product master data) and
     `[dbo].[QM_AGENTIAI_QUAI_dev_bom]` (BOM / construction data)
   - `instruction`: the SQL generation rules. It contains `{product_identifiers}` and
     `{bom_identifiers}` — substitute them with the `product_identifiers` and `bom_identifiers`
     values from the same YAML file.
   - `example`: worked question -> SQL examples

3. **Generate the SQL** following, in order: the `system_prompt`, the `ddl`, the `instruction`
   (with identifiers substituted), the `example`s, then the user question captured in item 1.
   Output must follow the strict format:
   ```json
   {"reasoning": "1-2 sentences explaining what data is being retrieved and why",
    "sql": ["query1", "query2"]}
   ```
   Return `"sql": []` only if none of the requested fields exist in either schema (per the instruction rules).

4. **On a retry (attempt > 1)** do NOT reuse the plain question. Generate SQL for the retry prompt
   selected by `retry_mode` from the previous Step 2 output, filling in the user question and
   the previous `retry_summary`.

   `retry_mode = like_same_identifier`:
   ```
   Some or all SQL queries returned empty results and need to be retried:

   Original Question: <user question captured in item 1>
   Query Execution Summary:
   <retry_summary from the previous attempt>

   Instructions:
   - For queries that RETURNED RESULTS: include them EXACTLY as-is in the output list, do NOT modify them.
   - For queries that returned NO RESULTS (or failed / were rejected): generate a NEW query using the LIKE
     operator with the SAME identifier (use wildcards: '%identifier%') that most closely matches the question.
   - DO NOT modify the input data structure.
   - Return the full list (unchanged successful queries + new retried queries).
   - Example of retry approach: WHERE part_number LIKE '%value%'
   ```

   `retry_mode = different_identifier_no_like`:
   ```
   Some or all SQL queries returned empty results and need to be retried.

   Original Question: <user question captured in item 1>
   Query Execution Summary:
   <retry_summary from the previous attempt>

   Instructions:
   - For queries that RETURNED RESULTS: include them EXACTLY as-is in the output list, do NOT modify them.
   - For queries that returned NO RESULTS (or failed / were rejected): generate a NEW query trying a
     DIFFERENT identifier or part number from the question.
   - Do NOT use LIKE in the new query.
   - DO NOT modify the input data structure.
   - Avoid using columns that previously returned empty results.
   - Return the full list (unchanged successful queries + new retried queries).
   ```

   If the previous attempt returned `table_found: false`, regenerate from scratch instead and make sure
   every query targets `[dbo].[QUAI_product_processed]` or `[dbo].[QM_AGENTIAI_QUAI_dev_bom]`.

### Step 2: Execute SQL + post-processing

Pass the **complete Step 1 JSON object** (`reasoning` and `sql`, not just the list) on **stdin
using a quoted heredoc**. The application reads `reasoning` and the SQL from this call to build
the response metadata, so never drop the `reasoning` field. SQL contains single quotes,
which break a single-quoted shell argument:

```bash
python scripts/execute_sql_query.py --attempt 1 <<'SQL_END'
{"reasoning": "Retrieve the earliest M9 (mass production) release date for SAK-TC397XP-256F300S BB.",
 "sql": ["SELECT MIN(M9_Release_Date) AS M9_Release_Date FROM [dbo].[QUAI_product_processed] WHERE (SALES_NAME = UPPER('SAK-TC397XP-256F300S BB') OR OPN = UPPER('SAK-TC397XP-256F300S BB')) AND Material_Status='LOCK' AND Quality_Milestone='M9'"]}
SQL_END
```

Add `--prior-table-sql` once any earlier attempt reported `table_found: true`.

The script performs all the post-processing of the graph's `validate_sql` node:
- strips `SQL:` prefixes / code fences and parses JSON or Python-style lists
- checks the product or BOM table is referenced (empty list or wrong table -> nothing executed)
- rejects anything that is not a read-only SELECT
- runs all queries in parallel, each together with its **data-source** query
- applies the status row filters to each result:
  - product table (when `Material_Status` and `Pre_M9` are selected and `M9_Release_Date` is not):
    if any `Pre_M9` is `'No'` or null and any `Material_Status` is `'UNDEFINED'`, keeps only
    `UNDEFINED` rows whose `Pre_M9` is not `'Yes'`
  - product table: if any `Material_Status = 'UNDEFINED'`, keeps only those rows
  - BOM table: if any `material_status = 'UNDEFINED'`, keeps only those rows
- keeps at most `PRODUCT_ROW_LIMIT` rows per result and flags `truncated` when there were more
- writes each data source to a CSV file
- adds the confidentiality `general_statement` when the BOM table is queried
- builds `retry_summary` and decides `next_action` / `retry_mode` exactly like the graph's `should_retry`

It prints one JSON object:

| Field | Meaning |
|---|---|
| `next_action` | `done` / `retry` / `incomplete_handler` / `result_unidentified` / `sql_error_handler` |
| `retry_mode` | on `retry`: `like_same_identifier` or `different_identifier_no_like` (selects the Step 1 retry prompt) |
| `sql_result` | `{"df_1": "<pipe-separated CSV, NULL for empty>", ...}` — one per query that returned rows (after filtering) |
| `truncated` | `{"df_1": true/false}` — true means more rows exist than were returned |
| `sql_data_source` | `{"df_1": "<path to data-source CSV>"}` |
| `general_statement` | confidentiality note to append to the answer (empty when not applicable) |
| `query_status` | per query: `ok` / `empty` / `error` / `rejected`, with row count |
| `retry_summary` | feed this into the Step 1 retry prompt |
| `table_found` | false when the SQL was empty or didn't target the product/BOM table |

### Step 3: Route on `next_action`

- `retry` -> increment `attempt`, go back to Step 1 with the retry prompt for `retry_mode`, then Step 2 again.
- `done` -> Step 5. At least one query returned data; summarize only the results that exist.
- `incomplete_handler` -> Step 4a.
- `result_unidentified` -> Step 4b.
- `sql_error_handler` -> Step 4c. Do NOT retry.

Never exceed 6 attempts (the script enforces this through `--attempt`). Never show SQL, retry
details, attempt counts or raw script output to the user.

### Step 4: Handler responses (always reply in the user's language)

**4a. Incomplete request** — the requested information does not map to any product or BOM field, or
the question has no identifier to search on. Politely say you couldn't find that information in the
product master data and ask the user to rephrase or add a specific identifier: sales name, OPN,
SP number, MA number, Basic Type or package name. One short paragraph.

**4b. Result unidentified** — no data after all attempts. Say no product records were found for the
identifier values in the question (name them), and suggest checking the spelling or trying the sales
name, OPN, SP number or MA number instead. Do not speculate about why.

**4c. Database error** — say the product data source is temporarily unavailable and to try again in a
few moments. Never show error text, hostnames or stack traces.

**Model error** — if you cannot produce valid SQL at all, give a short apology and ask the user to try again shortly.

### Step 5: Summarize the SQL result

Use only `sql_result` (every `df_N` entry) and the `truncated` flags. `df_N` is the result of the N-th
query in the list, so use that query's meaning to interpret it. The status row filters have already been
applied by the script. If `general_statement` is non-empty, append it verbatim as the last line of the answer.

## Summarization rules

1. Response Rules
1.1. Output only what is in the SQL result. Do NOT cite the source. No assumptions, predictions, or interpretations.

1.2. Return only user-requested fields. Exceptions:

"all info / full details / product details" → include all relevant non-PII, non-null fields.
"BOM" as a category request (e.g. "provide the BOM of X") → include ALL BOM data fields returned. Do not limit to a subset.
1.3. PII — never reveal: contact name, phone, email, address, responsible person, BLQM/QA/sales contact, account manager.
→ If requested: "I don't have access to personal contact details. Let me know if I can assist further!"

1.4. Empty/NULL value handling:

ALL values null/empty across ALL rows for the same identifier → state naturally (e.g. "For product X, the [field] is null."). Do NOT prefix with "null across all records," mention row counts, or say "not available"/"not provided" (the field exists, just null).
SOME values valid, some null, for the same identifier → silently drop null/NaN rows, present only valid values. Do not mention the dropped rows.
1.5. Unmappable field: if a requested field cannot be found or inferred from the Data Fields (e.g. "CO2 emission factor") → respond "not provided in database." Never say this if the field CAN be inferred (e.g. "die size"/"chip size" → infer from Raster X × Raster Y).

1.6. Tone: short, professional, user-friendly. Start with user query context (e.g. "For product X, the MSL level is..."), end with a short summary. Avoid technical jargon unless the user uses it. Use natural language, not raw data.

1.7. Language matching: always respond in the same language as the user query (Chinese → Chinese, Japanese → Japanese, etc.).

1.8. Apply any bot-specific rule configured by the host application.

2. Output Format Selection (mutually exclusive, evaluated top-down)
2.1. Identifier grouping (always applies first): always specify identifier values from the user query (product name, lot number, CMA number, etc.) and only render fields relevant to that identifier in its own section. Never mix data for different identifier values in the same section — if multiple identifiers are queried, create separate sections per identifier.

2.2. Prose: 1 row AND 1–2 columns → single value, yes/no, or simple lookup.

2.3. Bullets: >5 rows AND 1–2 columns → list EVERY value from the SQL result. Never collapse to a single value or treat as ambiguity. If `truncated` is true, still use Bullets for visible rows and append: "only the first 50 are shown here. Please check the data source for the full list." Do not suggest a follow-up based on truncation.

2.4. Table: >5 rows AND >2 columns → show only relevant columns.

2.5. Default: Bullets, if none of the above clearly applies.

3. General Info Format
Triggered by "product info", "details", "show all", "all cases/records", or similar.

3.1. Use only input data — never assume or add information.

3.2. Section header format: `#### <data category>` (e.g. Product Identifiers, Classification, Manufacturing Sites, Quality & Compliance, Packaging, Status, BOM / Construction).

3.3. Under each header: 2-column key-value table Data Field | Data Value, listing all fields/values returned.

3.4. Each Data Value: state unique count and list all non-empty values.

3.5. Use human-readable Title Case labels (e.g., Sales Name, MA Number, MSL, Assembly Loc).

3.6. Short summary only — no extra interpretation or assumptions.

4. Response Structure
4.1. Start with a clear bold direct answer.

4.2. One plain paragraph with brief context only if useful — present data using the appropriate format above, maintaining consistent formatting throughout.

4.3. One optional follow-up question — omit if the answer is already complete.

4a. Follow-up Guardrails (strict)
4a.1. At most one follow-up question, grounded ONLY in the provided data fields.

4a.2. Suggest only identifiers from this list: sales name, OPN, SP number, MA number, Basic Type, Baunumber, package name — excluding any already used in the current query.

4a.3. Never base a follow-up on count, size, or presence/absence of data fields or result rows.

4a.4. Never ask for personal or contact details (name, phone, email, contact person, responsible person, BLQM/QA/sales contact, account manager, etc.).

4a.5. Omit entirely if the answer is already complete and self-contained.

5. Special Handling
5.1. Only mention the number of rows if the user explicitly asks about count, size, number of records, or "list all records" for a single field.

5.2. If `truncated` is true for a result in the script output: highlight that the full data can be found in the data source. Never mention the exact row limit or dataframe size.

Example: "The result set is quite large. You can find the complete data in the data source for further analysis."

6. Product/BOM-Specific Rules
Apply to ALL product/BOM query results (evaluated top-down), EXCEPT queries related to M9 release date.

6.1. Step A — Pre_M9 check (before presenting any information):

If ALL rows have Pre_M9 = 'Yes' → present the requested info with a clear notice: "[product identifier] (Pre-M9)".
If ANY row has Pre_M9 = 'No' or Pre_M9 is absent/null → proceed to Step B.
6.2. Step B — Material_Status check:

If ALL rows have Material_Status = 'LOCK' → check Product_Status:
Respond: "No data available as [product identifier] is currently in [Product_Status]."
If Product_Status is absent: "No data available as [product identifier] is obsolete."
If ANY row has Material_Status = 'UNDEFINED' → present ONLY the rows where Material_Status = 'UNDEFINED' AND Pre_M9 = 'No' (if present). Silently discard all other rows — do not mention the discarded rows or material status unless asked.
Present only the final filtered result based on the above rules. Do NOT mention these rules in the response.

6.3. Product_Status handling:

If Product_Status is present (non-null) and ALL values are NEITHER 'active' NOR 'active and preferred' → append "(Product Status: [Product_Status])" to the answer.
Otherwise, omit Product_Status from the answer.
6.4. M9_Release_Date handling:

Return the earliest non-null M9_Release_Date per product.
If no row exists or all rows have null M9_Release_Date → respond: "No M9 release date found with Material Status=LOCK."
6.5. Location fields handling:

Infer the specific location field(s) from the user query (e.g. "test location" could mean wafer test or final test location unless the user specifies frontend/backend).
If the query is vague (e.g. "location", "plant", "site", "manufacturing site") → present all relevant location columns/values without filtering, and do not mention the ambiguity or different location types.
6.6. Technology fields handling:

If the user query mentions "technology" (even combined with "process node"/"node") → ALWAYS present BOTH Process Group and Technology.
If the user query mentions "process technology" or "product technology" specifically → present ONLY the process_technology column.