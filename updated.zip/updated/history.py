"""Chat-history persistence for the universal agent.

Mirrors `state_user_input.stateProdManagement`/`stateUserInput`: the rest of this
app is stateless per-request (no in-process/checkpointer memory), so every bot
reloads its own conversation history from the shared chat-history table on each
call. This module does the same for the universal agent — it reconstructs the
last few turns as Human/AI message pairs so the deep agent's orchestrator sees
the full conversation and can resolve follow-up questions ("what about the other
one?", "and its shipments?") that are not standalone on their own, then persists
each new turn so the next request can see it.
"""

import json
import logging
import sys
import traceback
import uuid
from pathlib import Path
from typing import List

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage

sys.path.append(str(Path(__file__).resolve().parent.parent))
from configs.config_data import configData
from sql_services import sqlServices

logger = logging.getLogger(__name__)

config = configData()
sql_serv = sqlServices()

TOPIC_ID = "universal_agent"
HISTORY_TURNS = 3


def load_history_messages(user_id: str, chat_id: str, limit: int = HISTORY_TURNS) -> List[BaseMessage]:
    """Load the last `limit` turns for this (user_id, chat_id) as Human/AI message
    pairs, oldest first, ready to prepend to the current turn's messages list."""
    messages: List[BaseMessage] = []
    if not chat_id:
        return messages
    query = (
        f"SELECT TOP {limit} * FROM dbo.{config.chat_table} "
        "WHERE user_id = :user_id AND chat_id = :chat_id AND topic_id = :topic_id "
        "ORDER BY created_time DESC"
    )
    try:
        records = sql_serv.select_user_info(
            query, {"user_id": user_id, "chat_id": chat_id, "topic_id": TOPIC_ID}
        )
        for record in reversed(list(records)):
            user_input = json.loads(record["message"]).get("user_input", "")
            model_output = json.loads(record["response"]).get("model_output", "")
            if user_input:
                messages.append(HumanMessage(content=user_input))
            if model_output:
                messages.append(AIMessage(content=model_output))
    except Exception:
        logger.error(f"[load_history_messages] Error loading history: {traceback.format_exc()}")
    return messages


def save_turn(
    user_id: str,
    chat_id: str,
    user_input: str,
    final_answer: str,
    sql: list[str] | None = None,
    intent: list[str] | None = None,
    reasoning: str = "",
    sql_tables: list[str] | None = None,
    sql_data_source: dict | None = None,
) -> None:
    """Persist one completed turn so it can be reloaded as history later."""
    if not chat_id:
        return
    try:
        payload = {
            "model_output": final_answer,
            "sql": json.dumps(sql or [], ensure_ascii=False),
            "intent": intent or "",
            "reasoning": reasoning,
        }
        message_table_data = {
            "message_id": str(uuid.uuid4()),
            "chat_id": chat_id,
            "user_id": user_id,
            "input_message": json.dumps({"user_input": user_input, "formatted_input": user_input}),
            "model_response": json.dumps(payload),
            "vote": "",
            "feedback": "",
            "latency": 0,
            "topic_id": TOPIC_ID,
            "meta_data": "{}",
        }
        sql_serv.insert_chat_history(message_table_data)
    except Exception:
        logger.error(f"[save_turn] Error saving turn: {traceback.format_exc()}")
