"""Adapters that expose the existing product/shipment/far sub-agent LangGraph
graphs as `deepagents` `CompiledSubAgent`s.

The existing sub-agent graphs (`productSubAgent.product_app`, `shipmentSubAgent.
shipment_app`, `farSubAgent.far_app`) use a custom `AgentState` schema (topic_id,
user_id, memory, sql, ...) with no `messages` key, while `deepagents` requires a
`CompiledSubAgent.runnable` whose state schema includes a `messages` key so it can
report results back to the main agent.

Each `_build_adapter_graph` below wraps one existing sub-agent behind a tiny
LangGraph graph that only exposes `messages`: it pulls the task out of the last
`HumanMessage`, builds the full state dict the underlying sub-agent expects, invokes
it with the same callback/metadata envelope used elsewhere in the app, and returns the answer as
an `AIMessage`.
"""

import asyncio
import logging
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Annotated, Optional, TypedDict

from deepagents.middleware.subagents import CompiledSubAgent
from langchain_core.callbacks import AsyncCallbackManager
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.runtime import get_runtime

sys.path.append(str(Path(__file__).resolve().parent.parent))
from configs.config_data import configData
from nodes.common_nodes import GPT_ERROR_MESSAGE

from .context import UniversalAgentContext
from .prompts import (
    FAR_AGENT_DESCRIPTION,
    PRODUCT_AGENT_DESCRIPTION,
    SHIPMENT_AGENT_DESCRIPTION,
)

logger = logging.getLogger(__name__)

config = configData()


class SubAgentAdapterState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


def _emit_progress(
    context: Optional[UniversalAgentContext],
    *,
    bot_tag: str,
    hop_number: int,
    stage: str,
    message: str,
    **payload,
) -> None:
    if context is None:
        return
    context.progress_events.append({
        "subagent": bot_tag,
        "hop_number": hop_number,
        "stage": stage,
        "message": message,
        **payload,
    })


def _subagent_langfuse_config(
    bot_tag: str,
    context: Optional[UniversalAgentContext],
    parent_run_id,
) -> dict:
    """Tracing config for one sub-agent run; nests under the master run when a parent id is known."""
    handler = context.langfuse_handler if context is not None else None
    langfuse_config = config.get_langfuse_config(
        "universal_agent",
        bot_tag,
        user_id=context.user_id if context is not None else None,
        session_id=context.chat_id if context is not None else None,
        run_name=bot_tag,
        handler=handler,
    )
    if handler is not None and parent_run_id is not None and "callbacks" in langfuse_config:
        langfuse_config["callbacks"] = AsyncCallbackManager(
            handlers=[handler],
            inheritable_handlers=[handler],
            parent_run_id=parent_run_id,
        )
    return langfuse_config


async def _invoke_subagent_with_events(
    sub_app,
    seed_state: dict,
    *,
    bot_tag: str,
    hop_number: int,
    task: str,
    context: Optional[UniversalAgentContext],
    parent_run_id=None,
) -> dict:
    _emit_progress(
        context,
        bot_tag=bot_tag,
        hop_number=hop_number,
        stage="subagent_started",
        message=f"Calling {bot_tag}",
        task=task,
    )

    final_result = None
    async for event in sub_app.astream_events(
        seed_state,
        config=_subagent_langfuse_config(bot_tag, context, parent_run_id),
        version="v2",
    ):
        evt = event.get("event")
        name = event.get("name")
        data = event.get("data") or {}
        output = data.get("output") or {}

        if evt == "on_chat_model_stream" and "final_response" in (event.get("tags") or []):
            sink = context.stream_sink if context is not None else None
            delta = getattr(data.get("chunk"), "content", "")
            if sink is not None and isinstance(delta, str) and delta:
                sink(bot_tag, delta)
            continue

        if evt != "on_chain_end":
            continue

        if name == "sql_generator":
            _emit_progress(
                context,
                bot_tag=bot_tag,
                hop_number=hop_number,
                stage="sql_generated",
                message=f"{bot_tag} generated SQL",
                sql=output.get("sql"),
                sql_reasoning=output.get("sql_reasoning", ""),
            )
            continue

        if name == "validator":
            # Validation bookkeeping is intentionally not surfaced to the UI contract.
            # Keep it in the underlying sub-agent state, but do not push it into the
            # shared progress stream used by the bot UI.
            continue

        if name in {
            "summarizer",
            "result_unidentified",
            "incomplete_handler",
            "timeout_handler",
            "sql_error_handler",
            "gpt_error_handler",
        }:
            answer = output.get("final_answer") or output.get("responses") or ""
            _emit_progress(
                context,
                bot_tag=bot_tag,
                hop_number=hop_number,
                stage="subagent_response",
                message=f"{bot_tag} produced a response",
                final_answer=answer,
            )
            continue

        if name in ("LangGraph", bot_tag):
            final_result = output

    return final_result or seed_state


def _resolve_runtime_context() -> Optional[UniversalAgentContext]:
    """Best-effort lookup of the deep agent's runtime context. The same instance
    flows through to every subagent invocation in a turn, so adapters can also use
    it as a mutable side-channel to report data back to the top-level caller."""
    try:
        return get_runtime(UniversalAgentContext).context
    except Exception:
        logger.debug("[universal_agent] No runtime context available, using defaults", exc_info=True)
        return None


def _extract_task(state: "SubAgentAdapterState") -> str:
    for message in reversed(state.get("messages", [])):
        if isinstance(message, HumanMessage):
            content = message.content
            return content if isinstance(content, str) else str(content)
    return ""


def _seed_state(task: str, intent: str, user_id: str, chat_id: Optional[str], topic_id: str) -> dict:
    """Build the full state dict expected by the product/shipment/far sub-agent graphs."""
    return {
        "topic_id": topic_id,
        "user_id": user_id,
        "chat_id": chat_id,
        "user_input": task,
        "user_translated_input": task,
        "intent": intent,
        "memory": [task],
        "sql": None,
        "sql_reasoning": None,
        "sql_result": {},
        "sql_data_source": {},
        "sql_tables": [],
        "error": None,
        "retry_query": None,
        "valid": None,
        "stop_iteration": False,
        "timeout": False,
        "retry_count": 0,
        "final_answer": None,
        "responses": "",
        "prev_response": {},
        "general_statement": "",
        "date_range_note": "",
        "gpt_error": False,
        "sql_error": False,
    }


def _build_adapter_graph(sub_app, intent: str, bot_tag: str):
    def run(state: SubAgentAdapterState, config: RunnableConfig) -> dict:
        task = _extract_task(state)
        context = _resolve_runtime_context()
        parent_run_id = getattr(config.get("callbacks"), "parent_run_id", None)
        if context is not None and context.hop_count >= context.max_hops:
            limit_message = (
                f"Maximum subagent hops ({context.max_hops}) reached for this query. "
                "Stop delegating and answer with the results already gathered."
            )
            logger.warning("[universal_agent] Max hops reached before invoking %s", bot_tag)
            context.subagent_results.append({
                "subagent": bot_tag,
                "task": task,
                "error": "max_hops_reached",
                "final_answer": limit_message,
            })
            return {"messages": [AIMessage(content=limit_message)]}

        user_id = (context.user_id if context else None) or "universal_agent"
        chat_id = context.chat_id if context else None
        seed_state = _seed_state(task, intent, user_id, chat_id, bot_tag)
        hop_number = (context.hop_count + 1) if context is not None else 1
        if context is not None:
            context.hop_count += 1
        start_time = time.perf_counter()
        trace_entry = None
        if context is not None:
            trace_entry = {
                "subagent": bot_tag,
                "hop_number": hop_number,
                "task": task,
                "started_at": datetime.now().strftime("%y-%m-%d %H:%M:%S"),
                "finished_at": None,
                "elapsed_seconds": None,
                "status": "running",
            }
            context.execution_trace.append(trace_entry)
        print(f"[universal_agent] Hop {hop_number}: starting {bot_tag} — task: {task[:200]}")
        try:
            result = asyncio.run(
                _invoke_subagent_with_events(
                    sub_app,
                    seed_state,
                    bot_tag=bot_tag,
                    hop_number=hop_number,
                    task=task,
                    context=context,
                    parent_run_id=parent_run_id,
                )
            )
        except Exception as exc:
            elapsed_seconds = time.perf_counter() - start_time
            if trace_entry is not None:
                trace_entry.update({
                    "finished_at": datetime.now().strftime("%y-%m-%d %H:%M:%S"),
                    "elapsed_seconds": elapsed_seconds,
                    "status": "failed",
                })
            print(f"[universal_agent] Hop {hop_number}: {bot_tag} failed after {elapsed_seconds:.2f}s: {exc}")
            logger.error(f"[universal_agent] Error invoking {bot_tag}: {exc}")
            if context is not None:
                _emit_progress(
                    context,
                    bot_tag=bot_tag,
                    hop_number=hop_number,
                    stage="subagent_failed",
                    message=f"{bot_tag} failed after {elapsed_seconds:.2f}s: {exc}",
                    error=str(exc),
                )
                context.subagent_results.append({"subagent": bot_tag, "task": task, "error": str(exc)})
            return {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}
        elapsed_seconds = time.perf_counter() - start_time
        if trace_entry is not None:
            trace_entry.update({
                "finished_at": datetime.now().strftime("%y-%m-%d %H:%M:%S"),
                "elapsed_seconds": elapsed_seconds,
                "status": "completed",
            })
        print(
            f"[universal_agent] Hop {hop_number}: {bot_tag} finished in {elapsed_seconds:.2f}s "
            f"(retry_count={result.get('retry_count')}, sql_error={result.get('sql_error')}, "
            f"timeout={result.get('timeout')})"
        )
        answer = result.get("final_answer") or result.get("responses") or "No answer was produced."
        if context is not None:
            # Keep the progress stream focused on user-visible status. Validation and
            # completion bookkeeping are intentionally excluded so the UI remains
            # consistent with the product/FAR bots, which surface only the delegated
            # task, SQL reasoning, and final sub-agent response.
            # Raw sub-agent state (sql/sql_data_source/...) is discarded by the
            # `messages`-only adapter state, so stash it on the shared context here —
            # this is what lets the top-level caller (bot_controller) recover the SQL
            # and result tables each delegated sub-agent produced this turn.
            context.subagent_results.append({
                "subagent": bot_tag,
                "task": task,
                "sql": result.get("sql"),
                "sql_reasoning": result.get("sql_reasoning", ""),
                "sql_data_source": result.get("sql_data_source") or result.get("sql_result") or {},
                "sql_tables": result.get("sql_tables") or [],
                "general_statement": result.get("general_statement", ""),
                "final_answer": answer,
            })
        return {"messages": [AIMessage(content=answer)]}

    graph = StateGraph(SubAgentAdapterState)
    graph.add_node("run", run)
    graph.set_entry_point("run")
    graph.add_edge("run", END)
    return graph.compile()


def build_product_subagent(product_app) -> CompiledSubAgent:
    return {
        "name": "product-agent",
        "description": PRODUCT_AGENT_DESCRIPTION,
        "runnable": _build_adapter_graph(product_app, "product", "product_bot"),
    }


def build_shipment_subagent(shipment_app) -> CompiledSubAgent:
    return {
        "name": "shipment-agent",
        "description": SHIPMENT_AGENT_DESCRIPTION,
        "runnable": _build_adapter_graph(shipment_app, "shipment", "shipment_bot"),
    }


def build_far_subagent(far_app) -> CompiledSubAgent:
    return {
        "name": "far-agent",
        "description": FAR_AGENT_DESCRIPTION,
        "runnable": _build_adapter_graph(far_app, "far", "far_bot"),
    }
