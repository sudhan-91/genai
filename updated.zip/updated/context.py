from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

MAX_HOPS = 5

@dataclass
class UniversalAgentContext:
    """Runtime context for the universal agent.

    Pass an instance of this at invoke time, e.g.:
        agent.invoke(
            {"messages": [...]},
            context=UniversalAgentContext(user_id="u123", chat_id="c456"),
        )

    `deepagents` automatically propagates this context to sub-agent invocations,
    so the product/shipment/far adapters can read it back via
    `langgraph.runtime.get_runtime(UniversalAgentContext)`.
    """

    user_id: str = "universal_agent"
    chat_id: Optional[str] = None
    max_hops: int = MAX_HOPS
    hop_count: int = 0
    # Mutable side-channel: since the same context instance flows through to every
    # subagent invocation within one turn, each adapter appends its raw sub-agent
    # result here (sql, sql_data_source, ...) so the caller can recover it after
    # `agent.invoke()` returns only the final `messages` list.
    subagent_results: List[dict] = field(default_factory=list)
    # Wall-clock execution intervals for proving whether delegated calls overlap.
    execution_trace: List[dict] = field(default_factory=list)
    # Ordered progress feed for streaming callers. Each adapter appends milestones
    # like subagent start, SQL generation, retries, and subagent response here.
    progress_events: List[dict] = field(default_factory=list)
    # Thread-safe callback `(bot_tag, text_delta)` set by the streaming caller; adapters
    # invoke it from worker threads for each sub-agent answer token.
    stream_sink: Optional[Callable[[str, str], None]] = None
    # Per-turn Langfuse handler shared by the master run and its sub-agents so they nest in one trace.
    langfuse_handler: Optional[Any] = None
    # Skill mode only: open skill runs keyed by (skill, task) -> index into
    # `subagent_results`. A run is one hop (attempt 1 .. final attempt) of one skill,
    # the skill-mode equivalent of one sub-agent call. Managed by `skill_runtime.py`.
    skill_runs: Dict[Tuple[str, str], dict] = field(default_factory=dict)
