"""Skill-mode runtime for the universal agent.

In skill mode the deep agent runs the product / shipment / FAR pipelines itself by
following each skill's SKILL.md and calling that skill's scripts. This module gives it
what the sub-agent adapters (`subagent_adapters.py`) used to provide:

* `bash` -- the only way the agent can run a skill script. It runs
  `python scripts/<name>.py ...` inside the chosen skill's folder (so the commands in
  SKILL.md work as written on Windows and Linux), turns a heredoc into stdin, uses the
  current interpreter (no hard-coded venv path) and refuses any other command.
* Result capture -- every `execute_sql_query.py` run is recorded on the shared
  `UniversalAgentContext`, in exactly the shape the adapters produced:
  `subagent_results` (sql, sql_reasoning, sql_data_source as CSV text, sql_tables,
  general_statement), `progress_events` (subagent_started / sql_generated /
  subagent_completed / subagent_failed) and `execution_trace`. `build_full_result()`
  and the streaming UI therefore keep working unchanged.
* `SkillModeMiddleware` -- hides the tools the agent must not use in skill mode
  (`task`, `execute`, `write_file`, `edit_file`, `delete`), blocks them if called anyway, and
  emits a `skill_loaded` progress event when a SKILL.md is read.

A "run" is one hop: attempt 1 through the final attempt of one skill for one task. It
is the skill-mode equivalent of one sub-agent call and counts against `max_hops`.
"""

from __future__ import annotations

import ast
import json
import logging
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Optional

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage
from langchain_core.tools import tool

try:  # langchain >= 1.0
    from langchain.tools import ToolRuntime
except ImportError:  # pragma: no cover - older layouts
    from langgraph.prebuilt import ToolRuntime  # type: ignore

from .context import UniversalAgentContext

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent
SKILLS_DIR = BASE_DIR / "skills"

SkillName = Literal["product", "shipment", "far"]

# Same labels the sub-agent adapters used, so UI / history / intent stay identical.
SKILL_BOT_TAGS = {
    "product": "product_bot",
    "shipment": "shipment_bot",
    "far": "far_bot",
}

SQL_SCRIPT = "execute_sql_query.py"
# Interpreter for skill scripts: the one running this app (its venv), unless overridden.
SKILL_PYTHON = os.getenv("SKILL_PYTHON") or sys.executable
# Must exceed the scripts' own query timeouts (shipment: 120 s per query, run sequentially).
SKILL_SCRIPT_TIMEOUT = int(os.getenv("SKILL_SCRIPT_TIMEOUT", "300"))
# Per-run scratch folders for data-source CSVs; read into the context, then deleted.
SKILL_OUTPUT_ROOT = Path(os.getenv("SKILL_OUTPUT_ROOT") or Path(tempfile.gettempdir()) / "universal_agent_skill_outputs")
MAX_STDERR_CHARS = 2000

# next_action values that end a run. "retry" keeps it open.
FAILED_ACTIONS = {"sql_error_handler", "timeout_handler"}
# Tools the agent must not use in skill mode.
# (`delete` only exists in newer deepagents; filtering an absent name is harmless.)
HIDDEN_TOOLS = frozenset({"task", "execute", "write_file", "edit_file", "delete"})

_HEREDOC = re.compile(r"<<-?\s*['\"]?(\w+)['\"]?[ \t]*\r?\n(.*?)\r?\n[ \t]*\1[ \t]*$", re.S)
_CD_PREFIX = re.compile(r"^\s*cd\s+\S+\s*(&&|;)\s*")
_SKILL_MD = re.compile(r"(?:^|/)skills/([a-z0-9-]+)/SKILL\.md$", re.I)
_TABLE_REF = re.compile(r"\b(?:FROM|JOIN)\s+((?:\[[^\]]+\]|[\w$]+)(?:\.(?:\[[^\]]+\]|[\w$]+))*)", re.I)

_lock = threading.RLock()


# --------------------------------------------------------------------------- helpers
def _now() -> str:
    return datetime.now().strftime("%y-%m-%d %H:%M:%S")


def _get_context(runtime: Any) -> Optional[UniversalAgentContext]:
    context = getattr(runtime, "context", None)
    return context if isinstance(context, UniversalAgentContext) else None


def _emit(context: Optional[UniversalAgentContext], **event: Any) -> None:
    if context is not None:
        with _lock:
            context.progress_events.append(event)


def _parse_json_output(stdout: str) -> Optional[dict]:
    """The scripts print one JSON object; tolerate stray lines printed before it."""
    stdout = (stdout or "").strip()
    if not stdout:
        return None
    try:
        parsed = json.loads(stdout)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        pass
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                parsed = json.loads(line)
                return parsed if isinstance(parsed, dict) else None
            except json.JSONDecodeError:
                continue
    return None


def _parse_sql_payload(raw: Optional[str]) -> tuple[list[str], str]:
    """Return (queries, reasoning) from the stdin the agent sent to execute_sql_query.py.

    Accepts a JSON / Python list of queries or the full {"reasoning": ..., "sql": [...]} object.
    """
    if not raw:
        return [], ""
    text = raw.strip()
    for old in ("SQL:", "sql:"):
        text = text.replace(old, "")
    text = re.sub(r"^```(?:json|sql|python)?\s*|\s*```$", "", text.strip()).strip()
    parsed: Any = None
    for loader in (json.loads, ast.literal_eval):
        try:
            parsed = loader(text)
            break
        except Exception:
            continue
    reasoning = ""
    if isinstance(parsed, dict):
        reasoning = str(parsed.get("reasoning") or "")
        parsed = parsed.get("sql", [])
    if isinstance(parsed, str):
        parsed = [parsed]
    if not isinstance(parsed, list):
        return [], reasoning
    return [str(q).strip() for q in parsed if str(q).strip()], reasoning


def _extract_tables(queries: list[str]) -> list[str]:
    tables: list[str] = []
    for query in queries:
        for match in _TABLE_REF.finditer(query):
            name = match.group(1)
            if name.upper() not in {"SELECT", "("} and name not in tables:
                tables.append(name)
    return tables


def _read_data_sources(sql_data_source: Any, cwd: Path) -> dict[str, str]:
    """Turn {"df_1": "<csv path>"} into {"df_1": "<csv text>"} (the adapters' shape)."""
    out: dict[str, str] = {}
    if not isinstance(sql_data_source, dict):
        return out
    for key, value in sql_data_source.items():
        path = Path(str(value))
        if not path.is_absolute():
            path = cwd / path
        try:
            out[key] = path.read_text(encoding="utf-8")
        except Exception:
            logger.warning("[skill_runtime] could not read data source %s", path, exc_info=True)
    return out


def _split_command(command: str, skill: str) -> tuple[list[str], Optional[str]]:
    """Validate a `python scripts/<name>.py ...` command and return (argv, stdin).

    Raises ValueError with a message meant for the model when the command is not allowed.
    """
    stdin_data = None
    match = _HEREDOC.search(command)
    if match:
        stdin_data = match.group(2) + "\n"
        command = command[: match.start()].rstrip()

    command = _CD_PREFIX.sub("", command.strip())
    try:
        argv = shlex.split(command, posix=True)
    except ValueError as exc:
        raise ValueError(f"Could not parse the command: {exc}. Pass SQL on stdin with a <<'SQL_END' heredoc.") from exc
    # No shell is involved (shell=False), so these would only reach the script as junk arguments.
    if any(arg in {"|", "||", "&&", ";", ">", ">>", "<", "&"} for arg in argv):
        raise ValueError(
            "Only a single `python scripts/<name>.py ...` command is allowed (optionally with a "
            "<<'SQL_END' heredoc for stdin). Pipes, redirects and chained commands are not supported."
        )
    if len(argv) < 2 or Path(argv[0]).name.lower() not in {"python", "python3", "python.exe", "py"}:
        raise ValueError("Commands must start with `python scripts/<name>.py`.")

    scripts_dir = (SKILLS_DIR / skill / "scripts").resolve()
    script_arg = argv[1].replace("\\", "/")
    # Accept the virtual paths the skills list shows (/skills/<skill>/scripts/x.py) as well as scripts/x.py.
    script_arg = re.sub(rf"^/?(?:skills/{re.escape(skill)}/)?", "", script_arg)
    script_path = (SKILLS_DIR / skill / script_arg).resolve()
    if script_path.parent != scripts_dir or script_path.suffix != ".py" or not script_path.is_file():
        available = ", ".join(sorted(p.name for p in scripts_dir.glob("*.py"))) or "none"
        raise ValueError(f"Unknown script `{argv[1]}` for skill '{skill}'. Available scripts: {available}.")
    return [SKILL_PYTHON, str(script_path), *argv[2:]], stdin_data


def _attempt_from_argv(argv: list[str]) -> int:
    for index, arg in enumerate(argv):
        if arg == "--attempt" and index + 1 < len(argv):
            try:
                return int(argv[index + 1])
            except ValueError:
                return 1
        if arg.startswith("--attempt="):
            try:
                return int(arg.split("=", 1)[1])
            except ValueError:
                return 1
    return 1


# --------------------------------------------------------------------------- run tracking
def _open_run(context: UniversalAgentContext, skill: str, task: str, attempt: int) -> tuple[Optional[dict], str]:
    """Return the open run for (skill, task), starting a new hop when needed.

    Returns (run, "") or (None, message) when the hop limit is reached.
    """
    bot_tag = SKILL_BOT_TAGS[skill]
    key = (skill, task.strip())
    with _lock:
        run = context.skill_runs.get(key)
        if run is not None and attempt > 1:
            return run, ""
        if run is not None:  # attempt 1 again for the same task: close the old run first
            _close_run(context, key, run, status="superseded", next_action="superseded")

        if context.hop_count >= context.max_hops:
            message = (
                f"Maximum skill runs ({context.max_hops}) reached for this query. "
                "Do not run more skill scripts; answer with the results already gathered."
            )
            context.subagent_results.append({
                "subagent": bot_tag, "task": task, "error": "max_hops_reached", "final_answer": message,
            })
            logger.warning("[skill_runtime] max hops reached before running %s", bot_tag)
            return None, message

        context.hop_count += 1
        hop_number = context.hop_count
        entry = {
            "subagent": bot_tag,
            "task": task,
            "sql": [],
            "sql_reasoning": "",
            "sql_data_source": {},
            "sql_tables": [],
            "general_statement": "",
            "final_answer": "",
        }
        context.subagent_results.append(entry)
        trace = {
            "subagent": bot_tag,
            "hop_number": hop_number,
            "task": task,
            "started_at": _now(),
            "finished_at": None,
            "elapsed_seconds": None,
            "status": "running",
        }
        context.execution_trace.append(trace)
        run = {
            "skill": skill,
            "bot_tag": bot_tag,
            "hop_number": hop_number,
            "entry": entry,
            "trace": trace,
            "started": time.perf_counter(),
        }
        context.skill_runs[key] = run
    _emit(context, subagent=bot_tag, hop_number=hop_number, stage="subagent_started",
          message=f"Calling {bot_tag}", task=task)
    print(f"[universal_agent] Hop {hop_number}: starting {bot_tag} (skill) — task: {task[:200]}")
    return run, ""


def _close_run(context: UniversalAgentContext, key: tuple, run: dict, *, status: str, next_action: str,
               error: str = "") -> None:
    with _lock:
        context.skill_runs.pop(key, None)
        elapsed = time.perf_counter() - run["started"]
        run["trace"].update(finished_at=_now(), elapsed_seconds=elapsed, status=status)
    bot_tag, hop = run["bot_tag"], run["hop_number"]
    if status == "failed":
        _emit(context, subagent=bot_tag, hop_number=hop, stage="subagent_failed",
              message=f"{bot_tag} failed after {elapsed:.2f}s: {error or next_action}", error=error or next_action)
    elif status in ("completed", "abandoned"):
        _emit(context, subagent=bot_tag, hop_number=hop, stage="subagent_completed", message="",
              next_action=next_action)
    print(f"[universal_agent] Hop {hop}: {bot_tag} (skill) {status} in {elapsed:.2f}s ({next_action})")


def _record_attempt(context: UniversalAgentContext, run: dict, task: str, queries: list[str], reasoning: str,
                    result: Optional[dict], data_sources: dict[str, str], error: str = "") -> None:
    entry, bot_tag, hop = run["entry"], run["bot_tag"], run["hop_number"]
    with _lock:
        # Latest attempt wins, exactly like the sub-agent graph state after its retry loop.
        entry["sql"] = queries
        entry["sql_reasoning"] = reasoning
        entry["sql_tables"] = _extract_tables(queries)
        entry["sql_data_source"] = data_sources
        if result is not None:
            entry["general_statement"] = str(result.get("general_statement") or "")
            entry["next_action"] = result.get("next_action")
        if error:
            entry["error"] = error
    if queries:
        _emit(context, subagent=bot_tag, hop_number=hop, stage="sql_generated",
              message=f"{bot_tag} generated SQL", sql=queries, sql_reasoning=reasoning)

    if result is None:
        return  # script crashed: keep the run open, the agent may retry
    next_action = str(result.get("next_action") or "")
    if next_action == "retry":
        return
    key = (run["skill"], task.strip())
    if next_action in FAILED_ACTIONS:
        _close_run(context, key, run, status="failed", next_action=next_action,
                   error=str(result.get("error") or next_action))
    else:
        _close_run(context, key, run, status="completed", next_action=next_action)


def finalize_open_skill_runs(context: Optional[UniversalAgentContext]) -> None:
    """Close runs the agent abandoned mid-retry so the trace never shows them as running."""
    if context is None:
        return
    with _lock:
        open_runs = list(context.skill_runs.items())
    for key, run in open_runs:
        _close_run(context, key, run, status="abandoned", next_action="abandoned")


# --------------------------------------------------------------------------- the tool
@tool
def bash(command: str, skill: SkillName, runtime: ToolRuntime[UniversalAgentContext], task: str = "") -> str:
    """Run one script of a skill, e.g. `python scripts/execute_sql_query.py --attempt 1 <<'SQL_END' ... SQL_END`.

    Args:
        command: The command exactly as written in the skill's SKILL.md: `python scripts/<name>.py [args]`,
            optionally followed by a quoted heredoc (<<'SQL_END' ... SQL_END) that is passed as stdin.
            It runs inside the skill's own folder. Pipes, redirects and other commands are not allowed.
        skill: The skill whose script is run: "product", "shipment" or "far".
        task: The self-contained English question this skill run answers. Required on attempt 1 of
            execute_sql_query.py; repeat the same text on every retry of that run.
    """
    context = _get_context(runtime)
    skill = str(skill).strip().lower()
    if skill not in SKILL_BOT_TAGS:
        return f"Error: unknown skill '{skill}'. Use one of: {', '.join(SKILL_BOT_TAGS)}."
    try:
        argv, stdin_data = _split_command(command, skill)
    except ValueError as exc:
        return f"Error: {exc}"

    is_sql_run = Path(argv[1]).name == SQL_SCRIPT
    attempt = _attempt_from_argv(argv) if is_sql_run else 0
    task = (task or "").strip()

    run = None
    if is_sql_run and context is not None:
        run, limit_message = _open_run(context, skill, task, attempt)
        if run is None:
            return limit_message

    skill_dir = SKILLS_DIR / skill
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    run_dir: Optional[Path] = None
    if is_sql_run:
        # A private output folder per call: concurrent users/turns never overwrite each other's CSVs.
        SKILL_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
        run_dir = Path(tempfile.mkdtemp(prefix=f"{skill}_", dir=SKILL_OUTPUT_ROOT))
        env[f"{skill.upper()}_OUTPUT_DIR"] = str(run_dir)

    try:
        try:
            proc = subprocess.run(
                argv,
                input=stdin_data,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=SKILL_SCRIPT_TIMEOUT,
                cwd=str(skill_dir),
                env=env,
            )
        except subprocess.TimeoutExpired:
            error = f"script timed out after {SKILL_SCRIPT_TIMEOUT}s"
            if run is not None and context is not None:
                queries, reasoning = _parse_sql_payload(stdin_data)
                _record_attempt(context, run, task, queries, reasoning,
                                {"next_action": "timeout_handler", "error": error}, {}, error)
            return json.dumps({"next_action": "timeout_handler", "error": error})
        except Exception as exc:
            logger.exception("[skill_runtime] failed to start %s", argv[1])
            return f"Error executing command: {exc}"

        stdout = (proc.stdout or "").strip()
        stderr = (proc.stderr or "").strip()
        parsed = _parse_json_output(stdout) if is_sql_run else None

        if run is not None and context is not None:
            queries, reasoning = _parse_sql_payload(stdin_data)
            data_sources = _read_data_sources((parsed or {}).get("sql_data_source"), skill_dir)
            error = "" if parsed is not None else (stderr[-MAX_STDERR_CHARS:] or "script produced no JSON output")
            _record_attempt(context, run, task, queries, reasoning, parsed, data_sources, error)

        if parsed is not None:
            # The CSV files are captured above and their folder is removed below; the model only needs
            # `sql_result`, so don't hand it file paths that will no longer exist.
            if isinstance(parsed.get("sql_data_source"), dict):
                parsed["sql_data_source"] = {k: "captured" for k in parsed["sql_data_source"]}
            output = json.dumps(parsed, default=str, ensure_ascii=False)
        else:
            output = stdout
        if proc.returncode != 0 and stderr:
            output += f"\n[STDERR]\n{stderr[-MAX_STDERR_CHARS:]}"
        return output or "(no output)"
    finally:
        if run_dir is not None:
            shutil.rmtree(run_dir, ignore_errors=True)


# --------------------------------------------------------------------------- middleware
def _tool_name(tool_obj: Any) -> Optional[str]:
    if isinstance(tool_obj, dict):
        return tool_obj.get("name") or (tool_obj.get("function") or {}).get("name")
    return getattr(tool_obj, "name", None)


class SkillModeMiddleware(AgentMiddleware):
    """Hide/block tools that don't belong in skill mode and report skill loads."""

    def __init__(self, hidden_tools: frozenset[str] = HIDDEN_TOOLS) -> None:
        super().__init__()
        self.hidden_tools = frozenset(hidden_tools)

    # -- model calls: don't offer hidden tools
    def _filter(self, request):
        tools = [t for t in (request.tools or []) if _tool_name(t) not in self.hidden_tools]
        return request.override(tools=tools)

    def wrap_model_call(self, request, handler):
        return handler(self._filter(request))

    async def awrap_model_call(self, request, handler):
        return await handler(self._filter(request))

    # -- tool calls: block hidden tools, emit skill_loaded
    def _before_tool(self, request) -> Optional[ToolMessage]:
        call = request.tool_call
        name = call.get("name")
        if name in self.hidden_tools:
            return ToolMessage(
                content=(f"Error: the `{name}` tool is not available. Run skill scripts yourself with "
                         "the `bash` tool and read files with `read_file`."),
                tool_call_id=call.get("id"),
                name=name,
                status="error",
            )
        if name == "read_file":
            path = str((call.get("args") or {}).get("file_path") or "").replace("\\", "/")
            match = _SKILL_MD.search(path)
            if match and match.group(1).lower() in SKILL_BOT_TAGS:
                bot_tag = SKILL_BOT_TAGS[match.group(1).lower()]
                _emit(_get_context(request.runtime), subagent=bot_tag, stage="skill_loaded",
                      message=f"Loading {bot_tag} skill")
        return None

    def wrap_tool_call(self, request, handler):
        blocked = self._before_tool(request)
        return blocked if blocked is not None else handler(request)

    async def awrap_tool_call(self, request, handler):
        blocked = self._before_tool(request)
        return blocked if blocked is not None else await handler(request)
