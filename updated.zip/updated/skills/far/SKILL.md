---
name: far
description: >
  Query customer complaint data: FAR (Failure Analysis Report), CMA cases, and PSI returned
  items. Use whenever the user asks about complaints, customer returns, field failures, or
  failure analysis cases, even if they never say "FAR". Covers: case counts by product,
  customer, product line (PL), business group, region, or period; root cause breakdown
  (EOS/ESD/EIPD, MOS, TOS, NTF; combined, level 1, level 2); customer-caused vs Infineon
  (IFX)-caused share; cause owner (site, dept, subcon); PSI failure description, keyword,
  and quantity; corrective actions; TAT; user status; start, completion, and registration
  dates. Look-ups by CMA/case number, MA number, sales name, package, product process, BE
  lot number, datecode, or complainer name/country. Do NOT use for sales, pricing,
  shipments, orders, inventory/WIP, test yield or parametric data, BOM/design data, product
  specs, or qualification/reliability stress tests unrelated to a complaint. Post-shipment
  complaint and return data only.
---

## CRITICAL EXECUTION RULE
- Run every script in this skill YOURSELF with the `bash` tool, passing `skill="far"`. The command
  runs inside this skill's folder, so use the commands exactly as written below (`python scripts/...`).
- On attempt 1 also pass `task`: the self-contained English question this run answers. Pass the SAME
  `task` text on every retry of that run.
- NEVER delegate (no `task` tool, no sub-agent). Only `python scripts/<name>.py ...` commands are allowed.
- In a turn where you call a tool, do not write any text to the user. Write text only in your final answer.

## Workflow overview

This skill reproduces the FAR LangGraph pipeline (`far_graph.py`) step by step:

```
Step 1 generate SQL -> Step 2 execute + post-process -> Step 3 route on `next_action`
      ^                                                  |
      +---------------- "retry" (max 4 attempts) <-------+
                                                         +-> "done"                -> Step 5 summarize
                                                         +-> "incomplete_handler"  -> Step 4a
                                                         +-> "result_unidentified" -> Step 4b
                                                         +-> "sql_error_handler"   -> Step 4c
```

Track these values across the loop: `question` (the user's question), `attempt` (starts at 1),
`prior_far_sql` (false until an attempt reports `far_table_found: true`), and the latest `retry_summary`.

### Step 1: Text-to-SQL conversion

1. **Capture the raw user question** — use the user's question exactly as asked, without
   paraphrasing or summarizing, so no intent or filter detail is lost before SQL generation.

2. **Read the YAML configuration file** with `read_file(file_path="/skills/far/references/far.yaml", limit=2000)`. Under `system_prompt.text_to_sql`:
   - `system_prompt`: the SQL generation template (substitute `{today}` with today's date, YYYY-MM-DD)
   - `ddl`: the table schema the query must be validated against
   - `instruction`: the SQL generation rules (identifier inference, SELECT/WHERE construction, disambiguation, edge cases)
   - `example`: worked question -> SQL examples
3. **Generate the SQL** following, in order: the `system_prompt`, the `ddl`, the `instruction`, the
   `example`s, then the user question captured in item 1. Output must follow the strict format:
   ```json
   {"reasoning": "1-2 sentences explaining what data is being retrieved and why",
    "sql": ["query1", "query2"]}
   ```
   Return `"sql": []` if none of the requested fields exist in the schema (per the instruction rules).
4. **On a retry (attempt > 1)** do NOT reuse the plain question. Generate SQL for this retry prompt,
   filling in the user question and the `retry_summary` from the previous Step 2 output:
   ```
   Some or all SQL queries returned empty results and need to be retried:

   Original Question: <user question captured in item 1>
   Query Execution Summary:
   <retry_summary from the previous attempt>

   Instructions:
   - For queries that RETURNED RESULTS: include them EXACTLY as-is in the output list, do NOT modify them.
   - For queries that returned NO RESULTS (or failed / were rejected): generate a NEW query using the LIKE
     operator with a different identifier (use wildcards: '%identifier%') that most closely matches the question.
   - Do not use the same identifier used in the failed SQL query.
   - DO NOT drop any identifier value from the original question.
   - Return the full list (unchanged successful queries + new retried queries).
   - Example of retry approach: WHERE part_number LIKE '%value%'
   ```
   If the previous attempt returned `far_table_found: false`, regenerate from scratch instead and make
   sure every query targets `[dbo].[QUAI_DRV_DC_FAR]`.

### Step 2: Execute SQL + post-processing

Pass the query list on **stdin using a quoted heredoc**. SQL contains single quotes (`'%ICE3A2065Z%'`),
which break a single-quoted shell argument:

```bash
python scripts/execute_sql_query.py --attempt 1 <<'SQL_END'
["SELECT COUNT(DISTINCT NN_NOTIF_NR_UNIQUE) AS TotalFARCount FROM [dbo].[QUAI_DRV_DC_FAR] WHERE UPPER(PROD_MATERIAL_NR_DESCR) LIKE UPPER('%ICE3A2065Z%') AND NN_COMPLAINT_KEY = 'CAR' AND PROD_PL != '57'",
 "SELECT * FROM [dbo].[QUAI_DRV_DC_FAR] WHERE UPPER(PROD_MATERIAL_NR_DESCR) LIKE UPPER('%ICE3A2065Z%') AND NN_COMPLAINT_KEY = 'CAR' AND PROD_PL != '57'"]
SQL_END
```

Add `--prior-far-sql` once any earlier attempt reported `far_table_found: true`.

The script performs all the post-processing of the graph's `validate_sql` node:
- strips `SQL:` prefixes / code fences and parses JSON or Python-style lists
- checks the FAR table is referenced (empty list or wrong table -> nothing executed)
- rejects anything that is not a read-only SELECT
- runs each query and its record-level **data-source** query in parallel
- keeps at most `FAR_ROW_LIMIT` rows per result and flags `truncated` when there were more
- drops `NN_NOTIF_NR_UNIQUE` from the data source and writes it to a CSV file
- builds `retry_summary` (which queries returned results / no results / errors)
- decides `next_action` exactly like the graph's `should_retry`

It prints one JSON object:

| Field | Meaning |
|---|---|
| `next_action` | `done` / `retry` / `incomplete_handler` / `result_unidentified` / `sql_error_handler` |
| `sql_result` | `{"df_1": "<pipe-separated CSV, NULL for empty>", ...}` — one per query that returned rows |
| `truncated` | `{"df_1": true/false}` — true means more rows exist than were returned |
| `sql_data_source` | `{"df_1": "<path to record-level CSV>"}` |
| `query_status` | per query: `ok` / `empty` / `error` / `rejected`, with row count |
| `retry_summary` | feed this into the Step 1 retry prompt |
| `far_table_found` | false when the SQL was empty or didn't target the FAR table |

### Step 3: Route on `next_action`

- `retry` -> increment `attempt`, go back to Step 1 with the retry prompt, then Step 2 again.
- `done` -> Step 5. If some queries were still empty after the last attempt, summarize only the results that exist.
- `incomplete_handler` -> Step 4a.
- `result_unidentified` -> Step 4b.
- `sql_error_handler` -> Step 4c. Do NOT retry.

Never exceed 4 attempts (the script enforces this through `--attempt`). Never show SQL, retry
details, attempt counts or raw script output to the user.

### Step 4: Handler responses (always reply in the user's language)

**4a. Incomplete request** — the requested information does not map to any FAR field, or the question
has no identifier to search on. Politely say you couldn't find that information in the FAR complaint
data and ask the user to rephrase or add a specific identifier: product/sales name, CMA/case number,
MA number, product line, lot number, customer, or time period. One short paragraph.

**4b. Result unidentified** — no data after all attempts. Say no FAR records were found for the
identifier values in the question (name them), and suggest checking the spelling or trying a
product/sales name, CMA/case number or MA number instead. Do not speculate about why.

**4c. Database error** — say the FAR data source is temporarily unavailable and to try again in a
few moments. Never show error text, hostnames or stack traces.

**Model error** — if you cannot produce valid SQL at all, give a short apology and ask the user to try again shortly.

### Step 5: Summarize the SQL result

Use only `sql_result` (every `df_N` entry) and the `truncated` flags. `df_N` is the result of the N-th
query in the list, so use that query's meaning (count vs. record list, which identifier) to interpret it.

## 1. Response Rules
1.1. Output only what is in the SQL result. Do NOT cite the source. No assumptions, predictions, or interpretations.
1.2. Return only user-requested fields. Exception: "all info / full details / case details / FAR history" → include all relevant non-PII, non-null fields.
1.3. **PII — never reveal**: contact name, phone, email, address, responsible person, BLQM/QA/sales contact, account manager.
   → If requested: *"I don't have access to personal contact details. Let me know if I can assist further!"*
1.4. **Empty/NULL value handling**:
   - ALL values null/empty across ALL rows for the same case/identifier → state naturally (e.g. "For CMA case X, the [field] is null."). Do NOT prefix with "null across all records," mention row counts, or say "not available"/"not provided."
   - SOME values valid, some null, for the same identifier → silently drop null/NaN rows, present only valid values. Do not mention the dropped rows.
1.5. **Unmappable field**: if a requested field cannot be found or inferred from the Data Fields → respond "not provided in database."
1.6. Tone: short, professional, user-friendly. Start with user query context (e.g. "For CMA case 800205055010, the root cause is..."), end with a short summary. Avoid technical jargon unless the user uses it.
1.7. Language matching: always respond in the same language as the user query.
1.8. Apply `any bot-specific rule configured by the host application` if provided.

## 2. Output Format Selection (mutually exclusive, evaluated top-down)
2.1. **Identifier grouping (always applies first)**: always specify identifier values from the user query (CMA/case number, product, lot number, customer, etc.) and only render fields relevant to that identifier in its own section. Never mix data for different identifiers in the same section — if multiple identifiers are queried, create separate sections per identifier.
2.2. **Prose**: 1 row AND 1–2 columns → single value, yes/no, count, or simple lookup (e.g. "How many FAR cases for X?").
2.3. **Bullets**: >5 rows AND 1–2 columns → list EVERY value from the SQL result. Never collapse to a single value. If `truncated` is true, still use Bullets for visible rows and append: *"only the first 50 are shown here. Please check the data source for the full list."* Do not suggest a follow-up based on truncation.
2.4. **Table**: >5 rows AND >2 columns → show only relevant columns (e.g. multi-case breakdown by root cause, cause owner, customer).
2.5. **Default**: Bullets, if none of the above clearly applies.

## 3. General Info Format
Triggered by "case info", "case details", "FAR history/overview", "show all cases", or similar.
3.1. Use only input data — never assume or add information.
3.2. Section header format: `#### {data_category}` (e.g. Complaint Identifiers, Root Cause, Cause Owner, Complaint Traceability).
3.3. Under each header: 2-column key-value table `Data Field | Data Value`, listing all fields/values returned.
3.4. Each Data Value: state unique count and list all non-empty values.
3.5. Use human-readable Title Case labels (e.g., CMA Number, Root Cause Level 1, Cause Owner, TAT, Caused By).
3.6. Short summary only — no extra interpretation.

## 4. Response Structure
4.1. Start with a clear **bold direct answer**. If the SQL filtered on a relative period (e.g. "last 3 months", "this quarter"), prepend one line stating the concrete date range it resolved to, based on today's date.
4.2. One plain paragraph with brief context only if useful — present data using the appropriate format above, maintaining consistent formatting.
4.3. One optional follow-up question — omit if the answer is already complete.

### 4a. Follow-up Guardrails (strict)
4a.1. At most one follow-up question, grounded ONLY in the provided data fields.
4a.2. Suggest only identifiers from this list: product/sales name, product line, CMA Number, MA Number, lot number, root cause, PSI failure description, Datecode, caused by, excluding any already used in the current query.
4a.3. Never base a follow-up on count, size, or presence/absence of data fields or result rows.
4a.4. Never ask for personal or contact details.
4a.5. Omit entirely if the answer is already complete and self-contained.

## 5. Special Handling
5.1. Only mention the number of rows if the user explicitly asks about count, size, number of cases, or "list all records" for a single field.
5.2. If `truncated` is true for a result in the script output: highlight that the full data can be found in the data source. Never mention the exact row limit or dataframe size.
   > Example: *"The result set is quite large. You can find the complete data in the data source for further analysis."*

## 6. FAR-Specific Rules

6.1. **Case counting handling**:
   - Always present case counts as derived from `NN_NOTIF_NR_UNIQUE` (unique CMA cases), never raw row counts. If the SQL result already reflects a `COUNT(DISTINCT NN_NOTIF_NR_UNIQUE)`, present it directly as "X FAR/CMA case(s)" — do not re-derive or second-guess the number.
   - If multiple entries exist for the same case (same first 9 characters of `NN_NOTIF_NR`), treat them as ONE case in the narrative, even if the SQL result shows multiple rows for context (e.g. per-entry root cause detail).

6.2. **Root cause terminology normalization**:
   - When presenting `ROOT_CAUSE_COMBINED`, `ROOT_CAUSE_Level1`, or `ROOT_CAUSE_Level2`, treat EOS, ESD and EIPD as the same category (present as "EOS/ESD/EIPD"), expand MOS as "mechanical overstress (MOS)", TOS as "thermal overstress (TOS)", and NTF as "No Trouble Found (NTF)".
   - Do not merge or rename any other root cause values — present them exactly as returned.

6.3. **Caused by**: present `CAUSED_BY = 'IFX'` as "Infineon (IFX)" and `'Customer'` as "Customer".

6.4. **TAT**: present TAT in days, rounded to 2 decimals (e.g. "6.57 days").

6.5. **Data source**: when a result is truncated, or the user asks for the full list, say the complete records are available in the data source. Never reveal file paths, SQL, or table names.
