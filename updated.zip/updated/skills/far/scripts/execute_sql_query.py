"""
FAR skill - SQL execution + post-processing.

Port of the deterministic parts of far_graph.py:
  * validate_sql      -> clean "SQL:" prefixes, parse the query list, check the FAR table
                         is referenced, run each query + its data-source query in parallel,
                         cap rows, drop NN_NOTIF_NR_UNIQUE from the data source, serialise
                         results as pipe-separated CSV with NULL, build the retry summary.
  * should_retry      -> compute the routing decision (next_action) for the agent.

Usage (preferred - heredoc on stdin avoids shell-quoting problems with SQL quotes):
    python scripts/execute_sql_query.py --attempt 1 <<'EOF'
    ["SELECT ... FROM [dbo].[QUAI_DRV_DC_FAR] WHERE ..."]
    EOF

Also accepted:  python scripts/execute_sql_query.py --attempt 1 --file queries.json
                python scripts/execute_sql_query.py --attempt 1 '<json list>'

Always prints exactly ONE JSON object on stdout.

Connection settings are read from environment variables (never hard-code credentials):
    FAR_DB_HOST, FAR_DB_PORT (1433), FAR_DB_NAME, FAR_DB_USER, FAR_DB_PASSWORD, FAR_DB_DOMAIN (optional)
Tunables:
    FAR_ROW_LIMIT (50)              rows returned to the agent per query (config.row_limit)
    FAR_DATA_SOURCE_ROW_LIMIT (5000) rows written to the data-source file (config.data_source_row_limit)
    FAR_MAX_RETRY (4)               total attempts before giving up (MAX_RETRY)
    FAR_OUTPUT_DIR (outputs/far)    where data-source CSV files are written
"""
import argparse
import ast
import concurrent.futures
import json
import os
import re
import sys
import traceback
from pathlib import Path
from dotenv import load_dotenv
import pandas as pd

CONFIG_DIR = Path(__file__).resolve().parent.parent.parent
load_dotenv(CONFIG_DIR / ".env")

SKILL_DIR = Path(__file__).resolve().parent.parent
YAML_PATH = SKILL_DIR / "references" / "far.yaml"

ROW_LIMIT = int(os.getenv("FAR_ROW_LIMIT", "50"))
DATA_SOURCE_ROW_LIMIT = int(os.getenv("FAR_DATA_SOURCE_ROW_LIMIT", "5000"))
MAX_RETRY = int(os.getenv("FAR_MAX_RETRY", "4"))
OUTPUT_DIR = Path(os.getenv("FAR_OUTPUT_DIR", "outputs/far"))

DEFAULT_TABLE = "QUAI_DRV_DC_FAR"
DEFAULT_KEY_ATTRIBUTES = [
    "PSI_ITEM_KEYWORD", "PSI_QUANTITY_ITEM", "PROD_MATERIAL_NR_DESCR", "PROD_MA_NUMBER", "PROD_PL",
    "PROD_PROCESS", "NN_NOTIF_NR", "NN_COMPLAINT_KEY", "CAUSE_OWNER_DESC_1", "CAUSED_BY",
    "N0_COMPLAINER_COUNTRY_DESCR", "PSI_FAILURE_DESC", "PSI_PRINT_DC_ORIGIN", "N0_COMPLAINER_NAME",
    "ROOT_CAUSE_COMBINED", "ROOT_CAUSE_Level1", "ROOT_CAUSE_Level2", "DVPS_LOT_NUMBER", "USER_STATUS",
    "TAT", "REGION", "BUSINESS_GROUP", "ADM_START_DATE", "ADM_COMPLETION_DATE", "NN_NOTIF_NR_UNIQUE",
]
FORBIDDEN = re.compile(r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|TRUNCATE|EXEC|EXECUTE|GRANT|REVOKE)\b",
                       re.IGNORECASE)


# --------------------------------------------------------------------------- config
def load_config():
    """Read table name and key attributes from references/far.yaml (falls back to defaults)."""
    table, key_attrs = DEFAULT_TABLE, list(DEFAULT_KEY_ATTRIBUTES)
    try:
        import yaml
        with open(YAML_PATH, encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)["system_prompt"]
        key_attrs = cfg.get("far_key_attributes") or key_attrs
        # equivalent of extract_table_names_from_ddl(config.far_ddl)[0], else config.far_table
        ddl = cfg.get("text_to_sql", {}).get("ddl", "")
        m = re.search(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:\[?\w+\]?\.)?\[?(\w+)\]?", ddl, re.I)
        table = m.group(1) if m else cfg.get("table_name", table)
    except Exception:
        pass
    return table.upper(), key_attrs


# --------------------------------------------------------------------------- input parsing
def clean_sql_text(raw: str) -> str:
    """validate_sql: strip 'SQL:' / 'sql:' prefixes and markdown fences."""
    for old in ("SQL:", "sql:"):
        raw = raw.replace(old, "")
    raw = re.sub(r"^```(?:json|sql|python)?\s*|\s*```$", "", raw.strip())
    return raw.strip()


def parse_query_list(raw: str):
    """Accept a JSON list, a Python-literal list (what str(list) in the graph produced),
    or the full {"reasoning":..., "sql":[...]} object."""
    raw = clean_sql_text(raw)
    parsed = None
    for loader in (json.loads, ast.literal_eval):
        try:
            parsed = loader(raw)
            break
        except Exception:
            continue
    if parsed is None:
        raise ValueError("Could not parse the SQL query list (expected a JSON list of strings).")
    if isinstance(parsed, dict):
        parsed = parsed.get("sql", [])
    if isinstance(parsed, str):
        parsed = [parsed]
    if not isinstance(parsed, list):
        raise ValueError("SQL input must be a list of query strings.")
    return [str(q).strip() for q in parsed if str(q).strip()]


# --------------------------------------------------------------------------- data_formater
def _find_top_level(sql: str, keyword_regex: str, start: int = 0):
    """Index of the first match of keyword_regex at parenthesis depth 0, outside string literals."""
    depth, in_str, i = 0, False, start
    pattern = re.compile(keyword_regex, re.I)
    while i < len(sql):
        ch = sql[i]
        if ch == "'":
            if in_str and i + 1 < len(sql) and sql[i + 1] == "'":
                i += 2
                continue
            in_str = not in_str
        elif not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif depth == 0:
                m = pattern.match(sql, i)
                if m and (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == "_")):
                    return i, m.end()
        i += 1
    return -1, -1


def _fallback_data_formater(query: str, key_attrs, for_source: bool = False) -> str:
    """Stand-in for utils.data_utils.data_formater when it is not importable.
    Result query: returned unchanged (minus trailing ';').
    Source query: the same FROM/WHERE clause, but selecting the FAR key attributes as raw rows,
                  so aggregate answers (COUNT, %, GROUP BY) still have a record-level data source."""
    query = query.strip().rstrip(";")
    if not for_source:
        return query
    from_idx, _ = _find_top_level(query, r"FROM\b")
    if from_idx < 0:
        return query
    tail = query[from_idx:]
    cut_points = [p for p in (_find_top_level(tail, r"GROUP\s+BY\b")[0],
                              _find_top_level(tail, r"HAVING\b")[0],
                              _find_top_level(tail, r"ORDER\s+BY\b")[0],
                              _find_top_level(tail, r"UNION\b")[0]) if p > 0]
    if cut_points:
        tail = tail[:min(cut_points)]
    cols = ", ".join(key_attrs)
    return f"SELECT DISTINCT TOP {DATA_SOURCE_ROW_LIMIT} {cols} {tail.strip()}"


def get_data_formater(key_attrs):
    """Prefer the project's real data_formater (same behaviour as the graph); otherwise fallback."""
    try:
        project_root = os.getenv("FAR_PROJECT_ROOT")
        if project_root:
            sys.path.append(project_root)
        from utils.data_utils import data_formater  # type: ignore
        return data_formater, "utils.data_utils"
    except Exception:
        return (lambda q, for_source=False: _fallback_data_formater(q, key_attrs, for_source)), "fallback"


# --------------------------------------------------------------------------- database
class SQLServerError(Exception):
    """Connection / server-side failure -> routed to sql_error_handler (not retried)."""


_ENGINE = None


def get_engine():
    global _ENGINE
    if _ENGINE is not None:
        return _ENGINE
    import sqlalchemy
    from sqlalchemy.engine import URL
    missing = [v for v in ("FAR_DB_HOST", "FAR_DB_NAME", "FAR_DB_USER", "FAR_DB_PASSWORD") if not os.getenv(v)]
    if missing:
        raise SQLServerError(f"Missing database environment variables: {', '.join(missing)}")
    user = os.environ["FAR_DB_USER"]
    if os.getenv("FAR_DB_DOMAIN"):
        user = f"{os.environ['FAR_DB_DOMAIN']}\\{user}"
    url = URL.create(  # URL.create escapes special characters in the password safely
        "mssql+pymssql",
        username=user,
        password=os.environ["FAR_DB_PASSWORD"],
        host=os.environ["FAR_DB_HOST"],
        port=int(os.getenv("FAR_DB_PORT", "1433")),
        database=os.environ["FAR_DB_NAME"],
    )
    _ENGINE = sqlalchemy.create_engine(url, pool_pre_ping=True)
    return _ENGINE


def run_query(query: str, limit: int) -> pd.DataFrame:
    """Equivalent of sql_service.select_qualitics_db(query).head(limit), without loading every row."""
    from sqlalchemy import text
    from sqlalchemy.exc import OperationalError, InterfaceError, DBAPIError
    try:
        engine = get_engine()
        with engine.connect() as conn:
            chunks = pd.read_sql(text(query), conn, chunksize=limit)
            try:
                return next(iter(chunks))
            except StopIteration:
                return pd.DataFrame()
    except (OperationalError, InterfaceError) as exc:
        raise SQLServerError(str(exc).splitlines()[0]) from exc
    except DBAPIError as exc:
        if getattr(exc, "connection_invalidated", False):
            raise SQLServerError(str(exc).splitlines()[0]) from exc
        raise


# --------------------------------------------------------------------------- main logic
def execute(query_list, attempt, prior_far_sql, key_attrs, far_table, formatter):
    result = {
        "attempt": attempt,
        "max_attempts": MAX_RETRY,
        "valid": True,
        "sql_result": {},
        "sql_data_source": {},
        "truncated": {},
        "row_counts": {},
        "query_status": [],
        "retry_summary": "",
        "next_action": None,
        "message": "",
    }

    # validate_sql: no FAR table referenced (includes empty list [] = unmappable request)
    joined = " ".join(query_list).upper()
    if not query_list or far_table not in joined:
        result["valid"] = False
        result["far_table_found"] = False
        if prior_far_sql:
            result["next_action"] = "retry" if attempt < MAX_RETRY else "result_unidentified"
        else:
            result["next_action"] = "incomplete_handler" if attempt < MAX_RETRY else "result_unidentified"
        result["message"] = "Generated SQL does not query the FAR table (or is empty)."
        return result
    result["far_table_found"] = True

    summary_lines = []
    for index, original_query in enumerate(query_list):
        df_key = f"df_{index + 1}"
        status = {"key": df_key, "query": original_query}

        if FORBIDDEN.search(original_query) or not re.match(r"^\s*(WITH|SELECT)\b", original_query, re.I):
            result["valid"] = False
            status.update(rows=0, status="rejected", error="Only read-only SELECT queries are allowed.")
            summary_lines.append(f"{original_query} was rejected (not a read-only SELECT)")
            result["query_status"].append(status)
            continue

        query = formatter(original_query)
        source_query = formatter(original_query, for_source=True)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
                f_res = ex.submit(run_query, query, ROW_LIMIT + 1)
                f_src = ex.submit(run_query, source_query, DATA_SOURCE_ROW_LIMIT)
                result_df = f_res.result()
                try:
                    source_df = f_src.result()
                except SQLServerError:
                    raise
                except Exception:
                    source_df = result_df.copy()  # data-source query failed; fall back to the result
        except SQLServerError:
            raise
        except Exception as exc:  # bad SQL (invalid column, syntax) -> treat as failed query, retry
            result["valid"] = False
            err = str(exc).splitlines()[0][:300]
            status.update(rows=0, status="error", error=err)
            summary_lines.append(f"{original_query} failed with error: {err}")
            result["query_status"].append(status)
            continue

        if "NN_NOTIF_NR_UNIQUE" in source_df.columns:
            source_df = source_df.drop(columns=["NN_NOTIF_NR_UNIQUE"])

        n_rows = int(result_df.shape[0])
        if n_rows > 0:
            truncated = n_rows > ROW_LIMIT
            shown = result_df.head(ROW_LIMIT)
            result["sql_result"][df_key] = shown.to_csv(index=False, sep="|", na_rep="NULL")
            result["truncated"][df_key] = truncated
            result["row_counts"][df_key] = int(shown.shape[0])
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            src_path = OUTPUT_DIR / f"far_data_source_{df_key}.csv"
            source_df.to_csv(src_path, index=False, na_rep="NULL")
            result["sql_data_source"][df_key] = str(src_path)
            status.update(rows=int(shown.shape[0]), status="ok", truncated=truncated)
            summary_lines.append(f"{original_query} returned some results")
        else:
            result["valid"] = False
            status.update(rows=0, status="empty")
            summary_lines.append(f"{original_query} returned no results")
        result["query_status"].append(status)

    result["retry_summary"] = "\n".join(summary_lines)

    # should_retry
    if result["valid"]:
        result["next_action"] = "done"
    elif attempt < MAX_RETRY:
        result["next_action"] = "retry"
    elif result["sql_result"]:
        result["next_action"] = "done"          # at least one query returned data
    else:
        result["next_action"] = "result_unidentified"
    return result


def main():
    ap = argparse.ArgumentParser(description="Execute FAR SQL queries with post-processing.")
    ap.add_argument("queries", nargs="?", help="JSON list of SQL queries (optional; stdin used otherwise)")
    ap.add_argument("--file", help="Path to a file containing the JSON list")
    ap.add_argument("--attempt", type=int, default=1, help="1-based attempt number (1..FAR_MAX_RETRY)")
    ap.add_argument("--prior-far-sql", action="store_true",
                    help="Set when an earlier attempt already produced SQL against the FAR table")
    args = ap.parse_args()

    out = {"attempt": args.attempt}
    try:
        if args.file:
            raw = Path(args.file).read_text(encoding="utf-8")
        elif args.queries:
            raw = args.queries
        else:
            raw = sys.stdin.read()
        far_table, key_attrs = load_config()
        formatter, formatter_src = get_data_formater(key_attrs)
        try:
            query_list = parse_query_list(raw)
        except ValueError as exc:
            # unparseable output is a validation failure -> retry (as in the graph)
            out.update(valid=False, error=str(exc),
                       next_action="retry" if args.attempt < MAX_RETRY else "result_unidentified")
            print(json.dumps(out))
            return
        out = execute(query_list, args.attempt, args.prior_far_sql, key_attrs, far_table, formatter)
        out["data_formater"] = formatter_src
    except SQLServerError as exc:
        out.update(valid=False, sql_error=True, next_action="sql_error_handler", error=str(exc))
    except Exception:
        out.update(valid=False, next_action="retry" if args.attempt < MAX_RETRY else "result_unidentified",
                   error=traceback.format_exc(limit=2))
    print(json.dumps(out, default=str))


if __name__ == "__main__":
    main()
