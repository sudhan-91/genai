"""
Product skill - SQL execution + post-processing.

Port of the deterministic parts of product_graph.py:
  * validate_sql  -> clean "SQL:" prefixes, parse the query list, check the product or BOM
                     table is referenced, run all queries in parallel (each with its data-source
                     query), apply the Pre_M9 / Material_Status row filters, cap rows, serialise
                     results as pipe-separated CSV with NULL, build the retry summary, and add the
                     confidentiality statement when the BOM table is used.
  * should_retry  -> compute the routing decision (next_action) and which retry prompt to use.

Usage (preferred - heredoc on stdin avoids shell-quoting problems with SQL quotes):
    python scripts/execute_sql_query.py --attempt 1 <<'SQL_END'
    ["SELECT ... FROM [dbo].[QUAI_product_processed] WHERE ..."]
    SQL_END

Also accepted:  python scripts/execute_sql_query.py --attempt 1 --file queries.json
                python scripts/execute_sql_query.py --attempt 1 '<json list>'

Always prints exactly ONE JSON object on stdout.

Connection settings come from environment variables (never hard-code credentials):
    PRODUCT_DB_HOST, PRODUCT_DB_PORT (1433), PRODUCT_DB_NAME, PRODUCT_DB_USER,
    PRODUCT_DB_PASSWORD, PRODUCT_DB_DOMAIN (optional)
Tunables:
    PRODUCT_ROW_LIMIT (50)               rows returned to the agent per query (config.row_limit)
    PRODUCT_DATA_SOURCE_ROW_LIMIT (5000) rows written to the data-source file (config.data_source_row_limit)
    PRODUCT_MAX_RETRY (6)                total attempts before giving up (MAX_RETRY)
    PRODUCT_OUTPUT_DIR (outputs/product) where data-source CSV files are written
    PRODUCT_PROJECT_ROOT                 optional: original project root, so the real
                                         utils.data_utils.data_formater is used
"""
import argparse
import ast
import concurrent.futures
import json
import os
import re
import sys
import traceback
from pathlib import Path

from dotenv import load_dotenv
import pandas as pd

CONFIG_DIR = Path(__file__).resolve().parent.parent.parent
load_dotenv(CONFIG_DIR / ".env")

SKILL_DIR = Path(__file__).resolve().parent.parent
YAML_PATH = SKILL_DIR / "references" / "product.yaml"

ROW_LIMIT = int(os.getenv("PRODUCT_ROW_LIMIT", "50"))
DATA_SOURCE_ROW_LIMIT = int(os.getenv("PRODUCT_DATA_SOURCE_ROW_LIMIT", "5000"))
MAX_RETRY = int(os.getenv("PRODUCT_MAX_RETRY", "6"))
OUTPUT_DIR = Path(os.getenv("PRODUCT_OUTPUT_DIR", "outputs/product"))

DEFAULT_PRODUCT_TABLE = "QUAI_product_processed"
DEFAULT_BOM_TABLE = "QM_AGENTIAI_QUAI_bom"
CONFIDENTIALITY_STATEMENT = ("Refer [Confidentiality Guidelines](https://intranet-content.infineon.com/) "
                             "to confirm the right confidentiality categories for product attributes.")
FORBIDDEN = re.compile(r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|TRUNCATE|EXEC|EXECUTE|GRANT|REVOKE)\b",
                       re.IGNORECASE)

# --------------------------------------------------------------------------- config
def load_tables():
    """extract_table_names_from_ddl(config.product_ddl): [0] = product table, [1] = BOM table."""
    product, bom = DEFAULT_PRODUCT_TABLE, DEFAULT_BOM_TABLE
    try:
        text = YAML_PATH.read_text(encoding="utf-8")
        names = re.findall(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:\[?\w+\]?\.)?\[?(\w+)\]?", text, re.I)
        if len(names) > 0:
            product = names[0]
        if len(names) > 1:
            bom = names[1]
    except Exception:
        pass
    return product, bom


# --------------------------------------------------------------------------- input parsing
def clean_sql_text(raw: str) -> str:
    """validate_sql: strip 'SQL:' / 'sql:' prefixes and markdown fences."""
    for old in ("SQL:", "sql:"):
        raw = raw.replace(old, "")
    raw = re.sub(r"^```(?:json|sql|python)?\s*|\s*```$", "", raw.strip())
    return raw.strip()


def parse_query_list(raw: str):
    """Accept a JSON list, a Python-literal list, or the full {"reasoning":..., "sql":[...]} object."""
    raw = clean_sql_text(raw)
    parsed = None
    for loader in (json.loads, ast.literal_eval):
        try:
            parsed = loader(raw)
            break
        except Exception:
            continue
    if parsed is None:
        raise ValueError("Could not parse the SQL query list (expected a JSON list of strings).")
    if isinstance(parsed, dict):
        parsed = parsed.get("sql", [])
    if isinstance(parsed, str):
        parsed = [parsed]
    if not isinstance(parsed, list):
        raise ValueError("SQL input must be a list of query strings.")
    return [str(q).strip() for q in parsed if str(q).strip()]


def tables_in(query_list, product_table, bom_table):
    """Equivalent of com_nodes.extract_table_names restricted to the two known tables."""
    joined = " ".join(query_list).upper()
    return sorted({t for t in (product_table, bom_table) if t.upper() in joined})


# --------------------------------------------------------------------------- data_formater
def get_data_formater():
    """Prefer the project's real data_formater (same behaviour as the graph); otherwise a
    fallback that returns the query unchanged (the data source is then the same query,
    capped at DATA_SOURCE_ROW_LIMIT rows instead of ROW_LIMIT)."""
    try:
        root = os.getenv("PRODUCT_PROJECT_ROOT")
        if root:
            sys.path.append(root)
        from utils.data_utils import data_formater  # type: ignore
        return data_formater, "utils.data_utils"
    except Exception:
        return (lambda q, for_source=False: q.strip().rstrip(";")), "fallback"


# --------------------------------------------------------------------------- database
class SQLServerError(Exception):
    """Connection / server-side failure -> routed to sql_error_handler (not retried)."""


_ENGINE = None


def get_engine():
    global _ENGINE
    if _ENGINE is not None:
        return _ENGINE
    import sqlalchemy
    from sqlalchemy.engine import URL
    need = ("PRODUCT_DB_HOST", "PRODUCT_DB_NAME", "PRODUCT_DB_USER", "PRODUCT_DB_PASSWORD")
    missing = [v for v in need if not os.getenv(v)]
    if missing:
        raise SQLServerError(f"Missing database environment variables: {', '.join(missing)}")
    user = os.environ["PRODUCT_DB_USER"]
    if os.getenv("PRODUCT_DB_DOMAIN"):
        user = f"{os.environ['PRODUCT_DB_DOMAIN']}\\{user}"
    url = URL.create(  # URL.create escapes special characters in the password safely
        "mssql+pymssql",
        username=user,
        password=os.environ["PRODUCT_DB_PASSWORD"],
        host=os.environ["PRODUCT_DB_HOST"],
        port=int(os.getenv("PRODUCT_DB_PORT", "1433")),
        database=os.environ["PRODUCT_DB_NAME"],
    )
    _ENGINE = sqlalchemy.create_engine(url, pool_pre_ping=True)
    return _ENGINE


def run_query(query: str, limit: int) -> pd.DataFrame:
    """Equivalent of sql_service.select_product_db(query).head(limit), without loading every row."""
    from sqlalchemy import text
    from sqlalchemy.exc import OperationalError, InterfaceError, DBAPIError
    try:
        with get_engine().connect() as conn:
            chunks = pd.read_sql(text(query), conn, chunksize=limit)
            try:
                return next(iter(chunks))
            except StopIteration:
                return pd.DataFrame()
    except (OperationalError, InterfaceError) as exc:
        raise SQLServerError(str(exc).splitlines()[0]) from exc
    except DBAPIError as exc:
        if getattr(exc, "connection_invalidated", False):
            raise SQLServerError(str(exc).splitlines()[0]) from exc
        raise


# --------------------------------------------------------------------------- post-processing
def apply_status_filters(df: pd.DataFrame) -> pd.DataFrame:
    """Row filters from validate_sql.process_query, in the same order."""
    # Product table: Pre_M9 check (skipped for M9 release-date results)
    if "Material_Status" in df.columns and "Pre_M9" in df.columns and "M9_Release_Date" not in df.columns:
        has_no_pre_m9 = (df["Pre_M9"] == "No").any()
        has_null_pre_m9 = df["Pre_M9"].isnull().any() or (df["Pre_M9"] == "").any()
        if has_no_pre_m9 or has_null_pre_m9:
            if (df["Material_Status"] == "UNDEFINED").any():
                df = df.loc[(df["Material_Status"] == "UNDEFINED") & (df["Pre_M9"] != "Yes")].reset_index(drop=True)
    # Product table: keep only UNDEFINED rows when any exist
    if "Material_Status" in df.columns and (df["Material_Status"] == "UNDEFINED").any():
        df = df.loc[df["Material_Status"] == "UNDEFINED"].reset_index(drop=True)
    # BOM table: same rule on the lower-case column
    if "material_status" in df.columns and (df["material_status"] == "UNDEFINED").any():
        df = df.loc[df["material_status"] == "UNDEFINED"].reset_index(drop=True)
    return df


def process_query(index, original_query, formatter):
    df_key = f"df_{index + 1}"
    status = {"key": df_key, "query": original_query}

    if FORBIDDEN.search(original_query) or not re.match(r"^\s*(WITH|SELECT)\b", original_query, re.I):
        status.update(rows=0, status="rejected", error="Only read-only SELECT queries are allowed.")
        return status, None, None, f"{original_query} was rejected (not a read-only SELECT)"

    query = formatter(original_query)
    source_query = formatter(original_query, for_source=True)
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
            f_res = ex.submit(run_query, query, ROW_LIMIT + 1)
            f_src = ex.submit(run_query, source_query, DATA_SOURCE_ROW_LIMIT)
            result_df = f_res.result()
            try:
                source_df = f_src.result()
            except SQLServerError:
                raise
            except Exception:
                source_df = result_df.copy()
    except SQLServerError:
        raise
    except Exception as exc:  # bad SQL (invalid column, syntax) -> counts as no result, retried
        err = str(exc).splitlines()[0][:300]
        status.update(rows=0, status="error", error=err)
        return status, None, None, f"{original_query} failed with error: {err}"

    result_df = apply_status_filters(result_df)

    if result_df.shape[0] > 0:
        truncated = result_df.shape[0] > ROW_LIMIT
        shown = result_df.head(ROW_LIMIT)
        status.update(rows=int(shown.shape[0]), status="ok", truncated=truncated)
        return status, shown, source_df, f"{original_query} returned some results"
    status.update(rows=0, status="empty")
    return status, None, None, f"{original_query} returned no results"


def execute(query_list, attempt, prior_table_sql, product_table, bom_table, formatter):
    result = {
        "attempt": attempt,
        "max_attempts": MAX_RETRY,
        "valid": False,
        "sql_tables": [],
        "sql_result": {},
        "sql_data_source": {},
        "truncated": {},
        "row_counts": {},
        "query_status": [],
        "retry_summary": "",
        "general_statement": "",
        "next_action": None,
        "retry_mode": None,
    }

    sql_tables = tables_in(query_list, product_table, bom_table)
    result["sql_tables"] = sql_tables
    if not query_list or not sql_tables:  # empty [] or wrong table -> stop_iteration
        result["table_found"] = False
        if attempt >= MAX_RETRY:
            result["next_action"] = "result_unidentified"
        elif prior_table_sql:
            result["next_action"] = "retry"
        else:
            result["next_action"] = "incomplete_handler"
        result["message"] = "Generated SQL does not query the product or BOM table (or is empty)."
    else:
        result["table_found"] = True
        if bom_table in sql_tables:
            result["general_statement"] = CONFIDENTIALITY_STATEMENT

        with concurrent.futures.ThreadPoolExecutor() as ex:
            outcomes = list(ex.map(lambda iq: process_query(iq[0], iq[1], formatter), enumerate(query_list)))

        summary = []
        for status, shown, source_df, line in outcomes:
            result["query_status"].append(status)
            summary.append(line)
            if shown is not None:
                key = status["key"]
                result["sql_result"][key] = shown.to_csv(index=False, sep="|", na_rep="NULL")
                result["truncated"][key] = status["truncated"]
                result["row_counts"][key] = status["rows"]
                OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
                path = OUTPUT_DIR / f"product_data_source_{key}.csv"
                source_df.to_csv(path, index=False, na_rep="NULL")
                result["sql_data_source"][key] = str(path)
        result["retry_summary"] = "\n".join(summary)
        result["valid"] = bool(result["sql_result"])  # graph: valid = any(query returned rows)

        if result["valid"]:
            result["next_action"] = "done"
        elif attempt < MAX_RETRY:
            result["next_action"] = "retry"
        else:
            result["next_action"] = "result_unidentified"

    # Graph: retry_count (== attempts completed) odd -> LIKE with the SAME identifier,
    #        even -> a DIFFERENT identifier without LIKE.
    if result["next_action"] == "retry":
        result["retry_mode"] = "like_same_identifier" if attempt % 2 == 1 else "different_identifier_no_like"
    return result


def main():
    ap = argparse.ArgumentParser(description="Execute product/BOM SQL queries with post-processing.")
    ap.add_argument("queries", nargs="?", help="JSON list of SQL queries (optional; stdin used otherwise)")
    ap.add_argument("--file", help="Path to a file containing the JSON list")
    ap.add_argument("--attempt", type=int, default=1, help="1-based attempt number (1..PRODUCT_MAX_RETRY)")
    ap.add_argument("--prior-table-sql", action="store_true",
                    help="Set when an earlier attempt already produced SQL against the product/BOM table")
    args = ap.parse_args()

    out = {"attempt": args.attempt}
    try:
        if args.file:
            raw = Path(args.file).read_text(encoding="utf-8")
        elif args.queries:
            raw = args.queries
        else:
            raw = sys.stdin.read()
        product_table, bom_table = load_tables()
        formatter, formatter_src = get_data_formater()
        try:
            query_list = parse_query_list(raw)
        except ValueError as exc:
            nxt = "retry" if args.attempt < MAX_RETRY else "result_unidentified"
            out.update(valid=False, error=str(exc), next_action=nxt,
                       retry_mode=("like_same_identifier" if args.attempt % 2 == 1
                                   else "different_identifier_no_like") if nxt == "retry" else None)
            print(json.dumps(out))
            return
        out = execute(query_list, args.attempt, args.prior_table_sql, product_table, bom_table, formatter)
        out["data_formater"] = formatter_src
    except SQLServerError as exc:
        out.update(valid=False, sql_error=True, next_action="sql_error_handler", error=str(exc))
    except Exception:
        nxt = "retry" if args.attempt < MAX_RETRY else "result_unidentified"
        out.update(valid=False, next_action=nxt, error=traceback.format_exc(limit=2))
    print(json.dumps(out, default=str))


if __name__ == "__main__":
    main()
