---
name: shipment
description: >
  Query shipment and delivery records: which product and lot was shipped, how many units,
  to whom, from where, and when. Use whenever the user asks about shipments, deliveries,
  shipped quantities, tracking, or who the customers of a product are, even if they never
  say "shipment". Covers: shipped quantity and lot counts by product, customer, country, or
  period; lot number and lot datecode (YYWW) traceability; ship-from location; delivery
  date; AWB tracking number; dispatch/delivery note number; sold-to customer (name, number,
  country: the order owner) and ship-to recipient (name, city, country: may differ from
  sold-to, e.g. EMS or drop-ship). Look-ups by sales name, SP or MA number, package,
  division, PL, lot, datecode, AWB, dispatch note, or customer name. Do NOT use for product
  specs, BOM, or manufacturing sites (product skill); complaints, returns, or root cause
  (far skill); pricing, revenue, or order data; test or yield data; inventory or stock,
  even when a lot or customer is named.
---

## CRITICAL EXECUTION RULE
- Run every script in this skill YOURSELF with the `bash` tool, passing `skill="shipment"`. The command
  runs inside this skill's folder, so use the commands exactly as written below (`python scripts/...`).
- On attempt 1 also pass `task`: the self-contained English question this run answers. Pass the SAME
  `task` text on every retry of that run.
- NEVER delegate (no `task` tool, no sub-agent). Only `python scripts/<name>.py ...` commands are allowed.
- In a turn where you call a tool, do not write any text to the user. Write text only in your final answer.

## Workflow overview

This skill reproduces the shipment LangGraph pipeline (`shipment_graph.py`) step by step:

```
Step 1 generate SQL (+ resolve_date_range) -> Step 2 execute + post-process -> Step 3 route on `next_action`
      ^                                                                        |
      +---------------------- "retry" (max 6 attempts) <-----------------------+
                                                                               +-> "done"                -> Step 5 summarize
                                                                               +-> "incomplete_handler"  -> Step 4a
                                                                               +-> "result_unidentified" -> Step 4b
                                                                               +-> "timeout_handler"     -> Step 4c
                                                                               +-> "sql_error_handler"   -> Step 4d
```

Track these values across the loop: `question` (the user's question), `attempt` (starts at 1),
`prior_table_sql` (false until an attempt reports `table_found: true`), `date_range_note`
(empty until resolved), and the latest `retry_summary` and `retry_mode`.

### Step 1: Text-to-SQL conversion

1. **Capture the raw user question** — use the user's question exactly as asked, without
   paraphrasing or summarizing, so no intent or filter detail is lost before SQL generation.

2. **Read the YAML configuration file** with `read_file(file_path="/skills/shipment/references/shipment.yaml", limit=2000)`. Under `system_prompt`:
   - `identifier`: the identifier list — substitute it for `{identifiers}` in `instruction`
   - `text_to_sql.system_prompt`: the SQL generation template (substitute `{today}` with today's date,
     YYYY-MM-DD; `{{` and `}}` are literal braces)
   - `text_to_sql.ddl`: the table schema the query must be validated against
   - `text_to_sql.instruction`: the SQL generation rules (identifier inference, SELECT/WHERE construction,
     datecode rules, sold-to vs ship-to disambiguation, edge cases)
   - `text_to_sql.example`: worked question -> SQL examples

3. **Resolve time periods (the `resolve_date_range` tool).** Follow the DATE-RANGE / DATE-CODE rules in
   `instruction`: only when the question filters by a TIME PERIOD (e.g. "last 3 months", "this year",
   "in 2024", "since 2020", "between May and June") — never when "date code" is a column to display, and
   never when the user gives a datecode value. Run:
   ```bash
   python scripts/resolve_date_range.py --period-type since_year --year 20
   ```
   | Phrase | Arguments |
   |---|---|
   | since 2020 | `--period-type since_year --year 20` |
   | in 2024 | `--period-type specific_year --year 24` |
   | this year | `--period-type this_year` |
   | last N years / months / weeks | `--period-type last_n_years` / `last_n_months` / `last_n_weeks` `--n N` |
   | this month / last month | `--period-type this_month` / `last_month` |
   | this quarter / last quarter | `--period-type this_quarter` / `last_quarter` |
   | Q3 2025 | `--period-type specific_quarter --year 25 --quarter 3` |
   | between May and June 2025 | `--period-type month_range --year 25 --start-month 5 --end-month 6` |
   | from 2025-01-15 to 2025-03-31 | `--period-type date_range --start-date 2025-01-15 --end-date 2025-03-31` |

   It prints `{"start": 2000, "end": 2612, "date_range_note": "..."}`. Use
   `fdla_datecode BETWEEN '<start>' AND '<end>'` in the WHERE clause and keep `date_range_note`.
   Never compute YYWW values yourself.

4. **Generate the SQL** following, in order: the `system_prompt`, the `ddl`, the `instruction`
   (with `{identifiers}` substituted), the `example`s, then the user question captured in item 1.
   Output must follow the strict format:
   ```json
   {"reasoning": "1-2 sentences explaining what data is being retrieved and why",
    "sql": ["query1", "query2"]}
   ```

5. **On a retry (attempt > 1)** do NOT reuse the plain question. Generate SQL for the retry prompt
   selected by `retry_mode` from the previous Step 2 output, filling in the user question and the
   previous `retry_summary`. If `date_range_note` is set, append the date-range hint shown below.

   `retry_mode = like_trailing_wildcard`:
   ```
   Some SQL queries returned empty results and need to be retried. Others already returned results and must be kept unchanged.

   Original Question: <user question captured in item 1>
   Query Execution Summary:
   <retry_summary from the previous attempt>

   Instructions:
   - For queries that RETURNED RESULTS: include them EXACTLY as-is in the output list, do NOT modify them.
   - For queries that returned NO RESULTS (or failed validation): generate a NEW query using LIKE with a
     trailing percentage pattern only (e.g., 'TLAEVA%').
   - DO NOT modify the input data or identifiers.
   - Replace exact match conditions (=) with trailing wildcard (e.g. fdla_lot LIKE UPPER('value%')) where
     appropriate for failed queries only. NEVER use a leading wildcard (LIKE UPPER('%value')).
   - Return the full list (unchanged successful queries + new retried queries).
   Example retry transformation:
   - Original: WHERE code = 'TLAEVA'
   - Updated: WHERE code LIKE 'TLAEVA%'
   ```

   `retry_mode = different_identifier_no_like`:
   ```
   Some or all SQL queries returned empty results and need to be retried.

   Original Question: <user question captured in item 1>
   Query Execution Summary:
   <retry_summary from the previous attempt>

   Instructions:
   - For queries that RETURNED RESULTS: include them EXACTLY as-is in the output list, do NOT modify them.
   - For queries that returned NO RESULTS (or failed validation): generate a NEW query trying a DIFFERENT
     identifier that most closely matches the question.
   - Do NOT use LIKE in the new query.
   - DO NOT modify the input data structure.
   - Avoid using columns that previously returned empty results.
   - Return the full list (unchanged successful queries + new retried queries).
   ```

   Date-range hint (append to either prompt when `date_range_note` is set):
   ```
   IMPORTANT: A date range was already resolved for this query: <date_range_note>.
   You MUST keep the same fdla_datecode BETWEEN clause from the previous SQL in your new query.
   Do NOT call resolve_date_range again — reuse the existing date filter as-is.
   ```

   If the previous attempt returned `table_found: false`, regenerate from scratch instead and make sure
   every query targets `vdb_bl_md_product.bl_mdprd_mp_dset_qualytics_tma_shipment`.

### Step 2: Execute SQL + post-processing

Pass the query list on **stdin using a quoted heredoc**. SQL contains single quotes (`UPPER('TLE9250VLE')`),
which break a single-quoted shell argument:

```bash
python scripts/execute_sql_query.py --attempt 1 <<'SQL_END'
["SELECT DISTINCT shipto_name FROM vdb_bl_md_product.bl_mdprd_mp_dset_qualytics_tma_shipment WHERE dpro_sales_name = UPPER('TLE9250VLE') AND shipto_name IS NOT NULL ORDER BY shipto_name"]
SQL_END
```

Add `--prior-table-sql` once any earlier attempt reported `table_found: true`.

The script performs all the post-processing of the graph's `validate_sql` node:
- strips `SQL:` prefixes / code fences and parses JSON or Python-style lists
- checks the shipment table is referenced (empty list or wrong table -> nothing executed)
- rejects anything that is not a read-only SELECT
- validates each query with the Denodo VQL validator when the project code is available
  (`SHIPMENT_PROJECT_ROOT`); a failed validation is recorded and retried, a validator connection
  problem routes to the SQL error handler
- runs the queries **one by one** against Denodo, and stops immediately on a DB error or timeout
- fetches the record-level **data source** only for queries that returned rows, and writes it to a CSV file
- keeps at most `SHIPMENT_ROW_LIMIT` rows per result and flags `truncated` when there were more
- builds `retry_summary` and decides `next_action` / `retry_mode` exactly like the graph's `should_retry`

It prints one JSON object:

| Field | Meaning |
|---|---|
| `next_action` | `done` / `retry` / `incomplete_handler` / `result_unidentified` / `timeout_handler` / `sql_error_handler` |
| `retry_mode` | on `retry`: `like_trailing_wildcard` or `different_identifier_no_like` (selects the Step 1 retry prompt) |
| `sql_result` | `{"df_1": "<pipe-separated CSV, NULL for empty>", ...}` — one per query that returned rows |
| `truncated` | `{"df_1": true/false}` — true means more rows exist than were returned |
| `sql_data_source` | `{"df_1": "<path to record-level CSV>"}` |
| `query_status` | per query: `ok` / `empty` / `failed_validation` / `timeout` / `db_error`, with row count |
| `retry_summary` | feed this into the Step 1 retry prompt |
| `table_found` | false when the SQL was empty or didn't target the shipment table |

### Step 3: Route on `next_action`

- `retry` -> increment `attempt`, go back to Step 1 with the retry prompt for `retry_mode`, then Step 2 again.
- `done` -> Step 5. Every query returned data.
- `incomplete_handler` -> Step 4a.
- `result_unidentified` -> Step 4b.
- `timeout_handler` -> Step 4c. Do NOT retry.
- `sql_error_handler` -> Step 4d. Do NOT retry.

Every query must return data for `done`; if any query is still empty after the 6th attempt the result
is `result_unidentified`. Never exceed 6 attempts (the script enforces this through `--attempt`).
Never show SQL, retry details, attempt counts or raw script output to the user.

### Step 4: Handler responses (always reply in the user's language)

**4a. Incomplete request** — the requested information does not map to any shipment field, or the question
has no identifier to search on (including a 1-digit datecode). Politely say you couldn't find that
information in the shipment data and ask the user to rephrase or add a specific identifier: sales name,
MA number, lot number, datecode, AWB tracking number, dispatch note, package name, customer or time period.
One short paragraph.

**4b. Result unidentified** — no data after all attempts. Say no shipment records were found for the
identifier values in the question (name them), and suggest checking the spelling or trying one of: sales
name, MA number, tracking number, package name, customer name, lot number. Do not speculate about why.

**4c. Timeout** — say the query took too long to complete, and suggest narrowing it down, e.g. with a
specific product, lot number, customer or a shorter time period.

**4d. Database error** — say the shipment data source is temporarily unavailable and to try again in a
few moments. Never show error text, hostnames or stack traces.

### Step 5: Summarize the SQL result

Use only `sql_result` (every `df_N` entry), the `truncated` flags and `date_range_note`. `df_N` is the
result of the N-th query in the list, so use that query's meaning (total vs. breakdown, which identifier)
to interpret it.

## Summarization rules

## 1. Response Rules
1.1. Output only what is in the SQL result. Do NOT cite the source. No assumptions, predictions, or interpretations.
1.2. Return only user-requested fields. Exception: "all info / full details / shipment history / shipment details" → include all relevant non-PII, non-null fields.
1.3. **PII — never reveal**: contact name, phone, email, address, responsible person, BLQM/QA/sales contact, account manager.
   → If requested: *"I don't have access to personal contact details. Let me know if I can assist further!"*
1.4. **Empty/NULL value handling**:
   - ALL values null/empty across ALL rows for the same lot/shipment identifier → state naturally (e.g. "For lot X, the [field] is null."). Do NOT prefix with "null across all records," mention row counts, or say "not available"/"not provided."
   - SOME values valid, some null, for the same identifier → silently drop null/NaN rows, present only valid values. Do not mention the dropped rows.
1.5. **Unmappable field**: if a requested field cannot be found or inferred from the Data Fields → respond "not provided in database."
1.6. Tone: short, professional, user-friendly. Start with user query context (e.g. "For lot 2W705452, the shipment quantity is..."), end with a short summary. Avoid technical jargon unless the user uses it.
1.7. Language matching: always respond in the same language as the user query.
1.8. Apply any bot-specific rule configured by the host application.

## 2. Output Format Selection (mutually exclusive, evaluated top-down)
2.1. **Identifier grouping (always applies first)**: always specify identifier values from the user query (product, lot number, customer, dispatch note, AWB tracking number, etc.) and only render fields relevant to that identifier in its own section. Never mix data for different identifiers in the same section — if multiple identifiers are queried (e.g. two products, two lots), create separate sections per identifier.
2.2. **Prose**: 1 row AND 1–2 columns → single value, yes/no, quantity, or simple lookup (e.g. "What is the delivery date for lot X?").
2.3. **Bullets**: >5 rows AND 1–2 columns → list EVERY value from the SQL result. Never collapse to a single value. If `truncated` is true, still use Bullets for visible rows and append: *"only the first 50 are shown here. Please check the data source for the full list."* Do not suggest a follow-up based on truncation.
2.4. **Table**: >5 rows AND >2 columns → show only relevant columns (e.g. multi-lot shipment breakdown by customer, quantity, delivery date).
2.5. **Default**: Bullets, if none of the above clearly applies.

## 3. General Info Format
Triggered by "shipment info", "shipment details", "shipment history/overview", "show all shipments", or similar.
3.1. Use only input data — never assume or add information.
3.2. Section header format: `#### <data category>` (e.g. Tracking/Logistics, Customer/Recipient, Product References, Shipment Records).
3.3. Under each header: 2-column key-value table `Data Field | Data Value`, listing all fields/values returned.
3.4. Each Data Value: state unique count and list all non-empty values.
3.5. Use human-readable Title Case labels (e.g., Lot Number, Datecode, AWB Tracking No, Sold-To Name, Ship-To Country).
3.6. Short summary only — no extra interpretation.

## 4. Response Structure
4.1. Start with a clear **bold direct answer**. If a `date_range_note` was produced in Step 1, prepend one short line stating the datecode range the answer covers (e.g. "Covering datecodes 2000–2612, since 2020:").
4.2. One plain paragraph with brief context only if useful — present data using the appropriate format above, maintaining consistent formatting.
4.3. One optional follow-up question — omit if the answer is already complete.

### 4a. Follow-up Guardrails (strict)
4a.1. At most one follow-up question, grounded ONLY in the provided data fields.
4a.2. Suggest only identifiers from this list: sales name, PL, MA number, location, tracking number, package name, datecode, dispatch note, lot number — excluding any already used in the current query.
4a.3. Never base a follow-up on count, size, or presence/absence of data fields or result rows.
4a.4. Never ask for personal or contact details.
4a.5. Omit entirely if the answer is already complete and self-contained.

## 5. Special Handling
5.1. Only mention the number of rows if the user explicitly asks about count, size, number of shipments/lots, or "list all records" for a single field.
5.2. If `truncated` is true for a result in the script output: highlight that the full data can be found in the data source. Never mention the exact row limit or dataframe size.
   > Example: *"The result set is quite large. You can find the complete data in the data source for further analysis."*

## 6. Shipment-Specific Rules

6.1. **Quantity aggregation handling**:
   - Always present shipment quantity totals as derived from `SUM(fdla_quantity)` when the user asks for "total units/quantity shipped." If the SQL result already reflects an aggregated sum, present it directly (e.g. "6,000 units were shipped...") — do not re-derive or second-guess the number.
   - If the result is broken down per lot/customer/period, present each breakdown clearly without collapsing into a single total unless the user asked for a total.

6.2. **soldto_name vs shipto_name presentation**:
   - If the user's query used "shipped to"/"ship-to" → label the customer field in the response as **"Ship-To"** (not "Customer" or "Sold-To").
   - If the user's query used "sold to"/"customer of" → label the field as **"Sold-To"**.
   - If BOTH `soldto_name` and `shipto_name` are present in the SQL result and DIFFER for the same shipment, explicitly show both (e.g. "Sold-To: LG INNOTEK CO LTD; Ship-To: FLEXTRONICS MANUFACTURING") rather than picking one — this is a valid drop-ship/EMS scenario, not an inconsistency to flag.
