"""
Shipment skill - SQL execution + post-processing (Denodo / DIVE virtual DB).

Port of the deterministic parts of shipment_graph.py:
  * validate_sql  -> clean "SQL:" prefixes, parse the query list, check the shipment table is
                     referenced, validate each query (Denodo VQL validation when available), run the
                     queries ONE BY ONE, stop on a DB error or timeout, fetch the data source only for
                     queries that returned rows, cap rows, serialise results as pipe-separated CSV
                     with NULL, and build the retry summary.
  * should_retry  -> compute the routing decision (next_action) and which retry prompt to use.

Usage (preferred - heredoc on stdin avoids shell-quoting problems with SQL quotes):
    python scripts/execute_sql_query.py --attempt 1 <<'SQL_END'
    ["SELECT ... FROM vdb_bl_md_product.bl_mdprd_mp_dset_qualytics_tma_shipment WHERE ..."]
    SQL_END

Also accepted:  python scripts/execute_sql_query.py --attempt 1 --file queries.json
                python scripts/execute_sql_query.py --attempt 1 '<json list>'

Always prints exactly ONE JSON object on stdout.

Connection settings come from environment variables (never hard-code credentials):
    SHIPMENT_DB_HOST, SHIPMENT_DB_PORT (9996), SHIPMENT_DB_NAME (vdb_std),
    SHIPMENT_DB_USER, SHIPMENT_DB_PASSWORD, SHIPMENT_DB_SSLROOTCERT (optional, e.g. scripts/cert/ca-bundle.crt)
Tunables:
    SHIPMENT_ROW_LIMIT (50)               rows returned to the agent per query (config.row_limit)
    SHIPMENT_DATA_SOURCE_ROW_LIMIT (5000) rows written to the data-source file (config.data_source_row_limit)
    SHIPMENT_MAX_RETRY (6)                total attempts before giving up (MAX_RETRY)
    SHIPMENT_QUERY_TIMEOUT (120)          seconds before a query is cancelled -> timeout_handler
    SHIPMENT_OUTPUT_DIR (outputs/shipment) where data-source CSV files are written
    SHIPMENT_PROJECT_ROOT                 optional: original project root, so the real
                                          utils.data_utils.data_formater and the Denodo MCP
                                          VQL validation (sql_services) are used
"""
import argparse
import ast
import json
import os
import re
import sys
import threading
import traceback
from pathlib import Path
from dotenv import load_dotenv
import pandas as pd

CONFIG_DIR = Path(__file__).resolve().parent.parent.parent
load_dotenv(CONFIG_DIR / ".env")

SKILL_DIR = Path(__file__).resolve().parent.parent
YAML_PATH = SKILL_DIR / "references" / "shipment.yaml"

ROW_LIMIT = int(os.getenv("SHIPMENT_ROW_LIMIT", "50"))
DATA_SOURCE_ROW_LIMIT = int(os.getenv("SHIPMENT_DATA_SOURCE_ROW_LIMIT", "5000"))
MAX_RETRY = int(os.getenv("SHIPMENT_MAX_RETRY", "6"))
QUERY_TIMEOUT = float(os.getenv("SHIPMENT_QUERY_TIMEOUT", "120"))
OUTPUT_DIR = Path(os.getenv("SHIPMENT_OUTPUT_DIR", "outputs/shipment"))

DEFAULT_TABLE = "bl_mdprd_mp_dset_qualytics_tma_shipment"
DEFAULT_KEY_ATTRIBUTES = [
    "div_short_desc", "pl", "dpro_internet_sales_name", "dpro_sales_name", "dpro_sp_sap_matnr",
    "fp_material_no", "fdla_quantity", "shipfrom_location", "awb_trackingno", "soldto_name",
    "shipto_city", "shipto_country", "shipto_name", "dpro_package_name", "fdla_datecode",
    "dispatch_note", "fdla_lot", "soldto_no", "soldto_country", "deliverydate",
]
FORBIDDEN = re.compile(r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|TRUNCATE|EXEC|EXECUTE|GRANT|REVOKE)\b",
                       re.IGNORECASE)
CONNECTION_TOKENS = ("connection", "connect", "refused", "unreachable", "timeout", "timed out", "session", "mcp")


# --------------------------------------------------------------------------- config
def load_config():
    """Table name (extract_table_names_from_ddl(config.shipment_ddl)[0]) and key attributes."""
    table, key_attrs = DEFAULT_TABLE, list(DEFAULT_KEY_ATTRIBUTES)
    try:
        import yaml
        with open(YAML_PATH, encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)["system_prompt"]
        key_attrs = cfg.get("shipment_key_attributes") or key_attrs
        ddl = cfg.get("text_to_sql", {}).get("ddl", "")
        m = re.search(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:\w+\.)?(\w+)", ddl, re.I)
        table = m.group(1) if m else cfg.get("table_name", table)
    except Exception:
        pass
    return table, key_attrs


# --------------------------------------------------------------------------- input parsing
def clean_sql_text(raw: str) -> str:
    """validate_sql: strip 'SQL:' / 'sql:' prefixes and markdown fences."""
    for old in ("SQL:", "sql:"):
        raw = raw.replace(old, "")
    raw = re.sub(r"^```(?:json|sql|python)?\s*|\s*```$", "", raw.strip())
    return raw.strip()


def parse_query_list(raw: str):
    """Accept a JSON list, a Python-literal list, or the full {"reasoning":..., "sql":[...]} object."""
    raw = clean_sql_text(raw)
    parsed = None
    for loader in (json.loads, ast.literal_eval):
        try:
            parsed = loader(raw)
            break
        except Exception:
            continue
    if parsed is None:
        raise ValueError("Could not parse the SQL query list (expected a JSON list of strings).")
    if isinstance(parsed, dict):
        parsed = parsed.get("sql", [])
    if isinstance(parsed, str):
        parsed = [parsed]
    if not isinstance(parsed, list):
        raise ValueError("SQL input must be a list of query strings.")
    return [str(q).strip() for q in parsed if str(q).strip()]


# --------------------------------------------------------------------------- project hooks
def _project_import():
    root = os.getenv("SHIPMENT_PROJECT_ROOT")
    if root and root not in sys.path:
        sys.path.append(root)


def _find_top_level(sql: str, keyword_regex: str):
    """Index of the first keyword match at parenthesis depth 0, outside string literals."""
    depth, in_str, i = 0, False, 0
    pattern = re.compile(keyword_regex, re.I)
    while i < len(sql):
        ch = sql[i]
        if ch == "'":
            if in_str and i + 1 < len(sql) and sql[i + 1] == "'":
                i += 2
                continue
            in_str = not in_str
        elif not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif depth == 0 and pattern.match(sql, i) and (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == "_")):
                return i
        i += 1
    return -1


def _fallback_data_formater(query: str, key_attrs, for_source: bool = False) -> str:
    """Stand-in for utils.data_utils.data_formater when it is not importable.
    Result query: unchanged. Source query: same FROM/WHERE, selecting the shipment key attributes
    as raw rows (so COUNT/SUM answers still have a record-level data source)."""
    query = query.strip().rstrip(";")
    if not for_source:
        return query
    from_idx = _find_top_level(query, r"FROM\b")
    if from_idx < 0:
        return query
    tail = query[from_idx:]
    cuts = [p for p in (_find_top_level(tail, r"GROUP\s+BY\b"), _find_top_level(tail, r"HAVING\b"),
                        _find_top_level(tail, r"ORDER\s+BY\b"), _find_top_level(tail, r"LIMIT\b"),
                        _find_top_level(tail, r"UNION\b")) if p > 0]
    if cuts:
        tail = tail[:min(cuts)]
    return f"SELECT DISTINCT {', '.join(key_attrs)} {tail.strip()} LIMIT {DATA_SOURCE_ROW_LIMIT}"


def get_data_formater(key_attrs):
    try:
        _project_import()
        from utils.data_utils import data_formater  # type: ignore
        return data_formater, "utils.data_utils"
    except Exception:
        return (lambda q, for_source=False: _fallback_data_formater(q, key_attrs, for_source)), "fallback"


def get_vql_validator():
    """sql_service.validate_vql_query_with_denodo_mcp if the project is importable, else None."""
    try:
        _project_import()
        from sql_services import sqlServices  # type: ignore
        return sqlServices().validate_vql_query_with_denodo_mcp, "denodo_mcp"
    except Exception:
        return None, "skipped"


# --------------------------------------------------------------------------- database
class SQLServerError(Exception):
    """Connection / server-side failure -> sql_error_handler (not retried)."""


class QueryTimeout(Exception):
    """Query exceeded SHIPMENT_QUERY_TIMEOUT -> timeout_handler."""


class QueryFailed(Exception):
    """The query itself is invalid (bad column, syntax) -> treated like a failed validation, retried."""


_CONN = None


def get_conn():
    global _CONN
    if _CONN is not None and not _CONN.closed:
        return _CONN
    import psycopg2
    need = ("SHIPMENT_DB_HOST", "SHIPMENT_DB_USER", "SHIPMENT_DB_PASSWORD")
    missing = [v for v in need if not os.getenv(v)]
    if missing:
        raise SQLServerError(f"Missing database environment variables: {', '.join(missing)}")
    kwargs = dict(
        host=os.environ["SHIPMENT_DB_HOST"],
        port=int(os.getenv("SHIPMENT_DB_PORT", "9996")),
        dbname=os.getenv("SHIPMENT_DB_NAME", "vdb_std"),
        user=os.environ["SHIPMENT_DB_USER"],
        password=os.environ["SHIPMENT_DB_PASSWORD"],  # passed as a parameter: special characters are safe
        connect_timeout=30,
    )
    ssl_root_cert = os.getenv("SHIPMENT_DB_SSLROOTCERT")
    if ssl_root_cert:
        cert_path = Path(ssl_root_cert)
        if not cert_path.is_absolute():
            # Relative paths (e.g. "scripts/cert/ca-bundle.crt") resolve against the skill folder,
            # so the setting works regardless of the process working directory or OS.
            cert_path = SKILL_DIR / cert_path
        kwargs.update(sslmode="verify-full", sslrootcert=str(cert_path))
    try:
        _CONN = psycopg2.connect(**kwargs)
        _CONN.autocommit = True
    except psycopg2.Error as exc:
        raise SQLServerError(str(exc).splitlines()[0] if str(exc) else "connection failed") from exc
    return _CONN


def run_query(query: str, limit: int) -> pd.DataFrame:
    """Equivalent of sql_service.select_query_shipment_func(query) -> (df, time_out, sql_error),
    expressed with exceptions. Fetches at most `limit` rows; cancels the query after QUERY_TIMEOUT."""
    import psycopg2
    import psycopg2.extensions
    conn = get_conn()
    timed_out = threading.Event()

    def _cancel():
        timed_out.set()
        try:
            conn.cancel()
        except Exception:
            pass

    timer = threading.Timer(QUERY_TIMEOUT, _cancel)
    timer.start()
    try:
        with conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchmany(limit) if cur.description else []
            cols = [d[0] for d in cur.description] if cur.description else []
        return pd.DataFrame(rows, columns=cols)
    except psycopg2.extensions.QueryCanceledError as exc:
        if timed_out.is_set():
            raise QueryTimeout(f"Query exceeded {QUERY_TIMEOUT:.0f}s") from exc
        raise SQLServerError(str(exc).splitlines()[0]) from exc
    except (psycopg2.OperationalError, psycopg2.InterfaceError) as exc:
        raise SQLServerError(str(exc).splitlines()[0] if str(exc) else "connection error") from exc
    except psycopg2.Error as exc:  # ProgrammingError, DataError, ... -> the query itself is wrong
        raise QueryFailed(str(exc).splitlines()[0][:300] if str(exc) else "query failed") from exc
    finally:
        timer.cancel()


# --------------------------------------------------------------------------- main logic
def next_action_for(result, attempt, prior_table_sql):
    """should_retry (sql_error -> timeout -> incomplete -> retry -> result_unidentified -> done)."""
    if result.get("sql_error"):
        return "sql_error_handler"
    if result.get("timeout"):
        return "timeout_handler"
    if not result["valid"] and attempt < MAX_RETRY and not result["table_found"] and not prior_table_sql:
        return "incomplete_handler"
    if not result["valid"] and attempt < MAX_RETRY:
        return "retry"
    if not result["valid"]:
        return "result_unidentified"
    return "done"


def execute(query_list, attempt, prior_table_sql, table, formatter, validator):
    result = {
        "attempt": attempt,
        "max_attempts": MAX_RETRY,
        "valid": True,
        "table_found": True,
        "sql_error": False,
        "timeout": False,
        "sql_result": {},
        "sql_data_source": {},
        "truncated": {},
        "row_counts": {},
        "query_status": [],
        "retry_summary": "",
    }

    if not query_list or table.lower() not in " ".join(query_list).lower():
        result.update(valid=False, table_found=False,
                      message="Generated SQL does not query the shipment table (or is empty).")
        return result

    summary = []
    for index, original_query in enumerate(query_list):
        df_key = f"df_{index + 1}"
        status = {"key": df_key, "query": original_query}
        result["query_status"].append(status)

        # 1. read-only guard + Denodo VQL validation
        problem = None
        if FORBIDDEN.search(original_query) or not re.match(r"^\s*(WITH|SELECT)\b", original_query, re.I):
            problem = "only read-only SELECT queries are allowed"
        elif validator is not None:
            try:
                ok, msg = validator(original_query)
            except Exception as exc:
                ok, msg = False, f"validation service error: {exc}"
            if not ok:
                problem = str(msg or "validation failed")
                if any(t in problem.lower() for t in CONNECTION_TOKENS):
                    result.update(valid=False, sql_error=True)
                    status.update(rows=0, status="validation_connection_error", error=problem)
                    summary.append(f"{original_query} failed validation: {problem}")
                    break
        if problem:
            result["valid"] = False
            status.update(rows=0, status="failed_validation", error=problem)
            summary.append(f"{original_query} failed validation: {problem}")
            continue

        # 2. execute (sequential; abort remaining queries on DB error / timeout)
        query = formatter(original_query)
        source_query = formatter(query, for_source=True)
        try:
            result_df = run_query(query, ROW_LIMIT + 1)
        except SQLServerError as exc:
            result.update(valid=False, sql_error=True)
            status.update(rows=0, status="db_error", error=str(exc))
            break
        except QueryTimeout as exc:
            result.update(valid=False, timeout=True)
            status.update(rows=0, status="timeout", error=str(exc))
            break
        except QueryFailed as exc:
            result["valid"] = False
            status.update(rows=0, status="failed_validation", error=str(exc))
            summary.append(f"{original_query} failed validation: {exc}")
            continue

        # 3. results + data source (data source fetched only when the query returned rows)
        if result_df.shape[0] > 0:
            try:
                source_df = run_query(source_query, DATA_SOURCE_ROW_LIMIT)
            except Exception:
                source_df = result_df.copy()
            truncated = result_df.shape[0] > ROW_LIMIT
            shown = result_df.head(ROW_LIMIT)
            result["sql_result"][df_key] = shown.to_csv(index=False, sep="|", na_rep="NULL")
            result["truncated"][df_key] = truncated
            result["row_counts"][df_key] = int(shown.shape[0])
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            path = OUTPUT_DIR / f"shipment_data_source_{df_key}.csv"
            source_df.to_csv(path, index=False, na_rep="NULL")
            result["sql_data_source"][df_key] = str(path)
            status.update(rows=int(shown.shape[0]), status="ok", truncated=truncated)
            summary.append(f"{original_query} returned some results")
        else:
            result["valid"] = False
            status.update(rows=0, status="empty")
            summary.append(f"{original_query} returned no results")

    result["retry_summary"] = "\n".join(summary)
    return result


def retry_mode_for(attempt):
    """Graph: retry_count (== attempts completed) odd -> trailing-wildcard LIKE,
    even -> a DIFFERENT identifier without LIKE."""
    return "like_trailing_wildcard" if attempt % 2 == 1 else "different_identifier_no_like"


def main():
    ap = argparse.ArgumentParser(description="Execute shipment SQL queries with post-processing.")
    ap.add_argument("queries", nargs="?", help="JSON list of SQL queries (optional; stdin used otherwise)")
    ap.add_argument("--file", help="Path to a file containing the JSON list")
    ap.add_argument("--attempt", type=int, default=1, help="1-based attempt number (1..SHIPMENT_MAX_RETRY)")
    ap.add_argument("--prior-table-sql", action="store_true",
                    help="Set when an earlier attempt already produced SQL against the shipment table")
    args = ap.parse_args()

    out = {"attempt": args.attempt}
    try:
        if args.file:
            raw = Path(args.file).read_text(encoding="utf-8")
        elif args.queries:
            raw = args.queries
        else:
            raw = sys.stdin.read()
        table, key_attrs = load_config()
        formatter, formatter_src = get_data_formater(key_attrs)
        validator, validator_src = get_vql_validator()
        query_list = parse_query_list(raw)
        out = execute(query_list, args.attempt, args.prior_table_sql, table, formatter, validator)
        out.update(data_formater=formatter_src, vql_validation=validator_src)
    except Exception as exc:
        # graph: any other exception in validate_sql -> valid False (retry, not an error handler)
        out.update(valid=False, table_found=True, sql_error=False, timeout=False,
                   error=str(exc) if isinstance(exc, ValueError) else traceback.format_exc(limit=2))
    out["next_action"] = next_action_for(out, args.attempt, args.prior_table_sql)
    out["retry_mode"] = retry_mode_for(args.attempt) if out["next_action"] == "retry" else None
    print(json.dumps(out, default=str))


if __name__ == "__main__":
    main()
