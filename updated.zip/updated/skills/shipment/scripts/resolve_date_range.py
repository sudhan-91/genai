"""
resolve_date_range - converts a time period into an fdla_datecode (YYWW) range.

Replacement for the `resolve_date_range` tool that shipment_graph.py exposed to the LLM
(text_to_sql.shipment_text_to_sql_with_tools). Output is one JSON object:
    {"start": 2000, "end": 2639, "date_range_note": "..."}
Use it as:  fdla_datecode BETWEEN '<start>' AND '<end>'

Week numbers are ISO-8601 weeks. Whole-year periods start at week 00 (e.g. since 2020 -> 2000),
matching the example in references/shipment.yaml; periods that end today end at today's week.

Usage:
    python scripts/resolve_date_range.py --period-type since_year --year 20
    python scripts/resolve_date_range.py --period-type specific_year --year 2024
    python scripts/resolve_date_range.py --period-type this_year
    python scripts/resolve_date_range.py --period-type last_n_years --n 2
    python scripts/resolve_date_range.py --period-type last_n_months --n 3
    python scripts/resolve_date_range.py --period-type last_n_weeks --n 8
    python scripts/resolve_date_range.py --period-type this_month | last_month
    python scripts/resolve_date_range.py --period-type this_quarter | last_quarter
    python scripts/resolve_date_range.py --period-type specific_quarter --year 2025 --quarter 3
    python scripts/resolve_date_range.py --period-type month_range --year 2025 --start-month 5 --end-month 6
    python scripts/resolve_date_range.py --period-type date_range --start-date 2025-01-15 --end-date 2025-03-31
Optional: --today YYYY-MM-DD (defaults to the current date).
"""
import argparse
import calendar
import json
import sys
from datetime import date, timedelta


def yyww(d: date) -> int:
    """ISO week, kept inside the calendar year of d (Dec 31 -> last week of that year, not week 01
    of the next; Jan 1 -> week 01, not week 52/53 of the previous year)."""
    iso_year, iso_week, _ = d.isocalendar()
    if iso_year > d.year:
        iso_week = date(d.year, 12, 28).isocalendar()[1]
    elif iso_year < d.year:
        iso_week = 1
    return (d.year % 100) * 100 + iso_week


def year_start(y: int) -> int:
    return (y % 100) * 100  # week 00, as in the YAML example (since 2020 -> 2000)


def year_end(y: int) -> int:
    return (y % 100) * 100 + date(y, 12, 28).isocalendar()[1]  # Dec 28 is always in the last ISO week


def full_year(y: int) -> int:
    return y + 2000 if y < 100 else y


def month_last_day(y: int, m: int) -> date:
    return date(y, m, calendar.monthrange(y, m)[1])


def shift_months(d: date, months: int) -> date:
    idx = d.year * 12 + (d.month - 1) + months
    y, m = divmod(idx, 12)
    return date(y, m + 1, min(d.day, calendar.monthrange(y, m + 1)[1]))


def resolve(a, today: date):
    pt = a.period_type
    if pt in ("since_year", "specific_year"):
        if a.year is None:
            raise ValueError(f"{pt} requires --year")
        y = full_year(a.year)
        if pt == "since_year":
            return year_start(y), yyww(today), f"since {y} (to today, {today.isoformat()})"
        end = min(year_end(y), yyww(today)) if y == today.year else year_end(y)
        return year_start(y), end, f"year {y}"
    if pt == "this_year":
        return year_start(today.year), yyww(today), f"year {today.year} to date"
    if pt == "last_n_years":
        start = shift_months(today, -12 * a.n)
        return yyww(start), yyww(today), f"last {a.n} year(s): {start.isoformat()} to {today.isoformat()}"
    if pt == "last_n_months":
        start = shift_months(today, -a.n)
        return yyww(start), yyww(today), f"last {a.n} month(s): {start.isoformat()} to {today.isoformat()}"
    if pt == "last_n_weeks":
        start = today - timedelta(weeks=a.n)
        return yyww(start), yyww(today), f"last {a.n} week(s): {start.isoformat()} to {today.isoformat()}"
    if pt == "this_month":
        start = today.replace(day=1)
        return yyww(start), yyww(today), f"{start:%B %Y} to date"
    if pt == "last_month":
        end = today.replace(day=1) - timedelta(days=1)
        start = end.replace(day=1)
        return yyww(start), yyww(end), f"{start:%B %Y}"
    if pt in ("this_quarter", "last_quarter", "specific_quarter"):
        if pt == "specific_quarter":
            if a.year is None or a.quarter is None:
                raise ValueError("specific_quarter requires --year and --quarter")
            y, q = full_year(a.year), a.quarter
        else:
            y, q = today.year, (today.month - 1) // 3 + 1
            if pt == "last_quarter":
                y, q = (y - 1, 4) if q == 1 else (y, q - 1)
        start = date(y, 3 * q - 2, 1)
        end = month_last_day(y, 3 * q)
        if pt == "this_quarter":
            end = today
        return yyww(start), yyww(end), f"Q{q} {y}: {start.isoformat()} to {end.isoformat()}"
    if pt == "month_range":
        if a.start_month is None:
            raise ValueError("month_range requires --start-month (and optionally --end-month, --year)")
        y = full_year(a.year) if a.year is not None else today.year
        start = date(y, a.start_month, 1)
        end = month_last_day(y, a.end_month or a.start_month)
        return yyww(start), yyww(end), f"{start.isoformat()} to {end.isoformat()}"
    if pt == "date_range":
        if not a.start_date:
            raise ValueError("date_range requires --start-date (and optionally --end-date)")
        start = date.fromisoformat(a.start_date)
        end = date.fromisoformat(a.end_date) if a.end_date else today
        return yyww(start), yyww(end), f"{start.isoformat()} to {end.isoformat()}"
    raise ValueError(f"Unknown period type: {pt}")


def main():
    ap = argparse.ArgumentParser(description="Resolve a time period to an fdla_datecode YYWW range.")
    ap.add_argument("--period-type", required=True,
                    choices=["since_year", "specific_year", "this_year", "last_n_years", "last_n_months",
                             "last_n_weeks", "this_month", "last_month", "this_quarter", "last_quarter",
                             "specific_quarter", "month_range", "date_range"])
    ap.add_argument("--year", type=int, help="2- or 4-digit year")
    ap.add_argument("--n", type=int, default=1, help="N for last_n_* periods")
    ap.add_argument("--quarter", type=int, choices=[1, 2, 3, 4])
    ap.add_argument("--start-month", type=int, choices=range(1, 13))
    ap.add_argument("--end-month", type=int, choices=range(1, 13))
    ap.add_argument("--start-date")
    ap.add_argument("--end-date")
    ap.add_argument("--today", help="Override today's date (YYYY-MM-DD)")
    a = ap.parse_args()
    try:
        today = date.fromisoformat(a.today) if a.today else date.today()
        start, end, desc = resolve(a, today)
        note = f"Datecode range {start:04d}-{end:04d} ({desc})"
        print(json.dumps({"start": start, "end": end, "date_range_note": note}))
    except Exception as exc:
        print(json.dumps({"error": str(exc)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
