# Quality Management Universal Agent

"""
Universal orchestrator for the Quality Management assistant.

Architecture
------------

    ┌─────────────────────────────────────────────────────────────────┐
    │                           GRAPH                                 │
    │                                                                 │
    │  [load history] → deep-agent router → product / shipment / FAR  │
    │                                │                                │
    │                                ├───────────────┬──────────────┤
    │                                │               │              │
    │                           product-agent   shipment-agent   far-agent
    │                                │               │              │
    │                                └───────┬───────┴──────┬───────┘
    │                                        │              │
    │                                  sql + result   sql + result
    │                                        │              │
    │                                        └──────┬───────┘
    │                                               ▼
    │                                     aggregator / summarizer
    │                                               │
    │                                               ▼
    │                                          final response
    └─────────────────────────────────────────────────────────────────┘


This project includes a universal orchestration layer that routes user questions to the product, shipment, and FAR specialist sub-agents and then combines their results into a single answer.

## Purpose

The universal agent is designed to:

- translate and normalize user intent before delegation
- preserve conversation context from prior turns in the same chat
- route each request to the most relevant sub-agent or sub-agents
- collect SQL, table metadata, and reasoning from each delegated hop
- return a consistent payload for the rest of the API layer

## High-level flow

1. The caller sends a user message together with user and chat identifiers.
2. The orchestrator loads recent chat history for that conversation.
3. The deep agent decides whether to route to product, shipment, FAR, or a combination.
4. Each delegated sub-agent runs its own LangGraph flow and writes results into a shared runtime context.
5. The orchestrator aggregates the final answer, SQL queries, tables, and reasoning into one response object.

## Key files

- `universal_agent/agent.py` — main orchestration logic, turn execution, and final payload assembly
- `universal_agent/context.py` — runtime-side context used to share per-turn state among delegated sub-agents
- `universal_agent/subagent_adapters.py` — thin wrappers that adapt the existing graphs into deep-agent-compatible sub-agents
- `universal_agent/history.py` — history loading and persistence for follow-up questions
- `universal_agent/prompts.py` — shared orchestrator and sub-agent descriptions
- `universal_agent/AGENTS.md` — routing and delegation policy for the deep agent
- `universal_agent/__init__.py` — public exports for the package

## Runtime behavior

The universal agent is intentionally stateless between requests. To keep follow-up questions working, it loads recent turns from the chat history table, appends the current message, and then invokes the orchestrator with a fresh `UniversalAgentContext`.

While each delegated sub-agent runs, it records structured metadata such as:

- `subagent`
- `sql`
- `sql_reasoning`
- `sql_tables`
- `sql_data_source`
- `general_statement`
- `final_answer`

That side-channel is later flattened into the final payload returned to the API layer.

## Public entry points

The central public API is exposed from the package root:

- `build_universal_agent()`
- `get_universal_agent()`
- `invoke_universal_agent()`
- `invoke_universal_agent_full()`
- `run_universal_agent_turn()`
- `build_full_result()`
- `UniversalAgentContext`

## Notes

- The agent is cached as a singleton for reuse across turns.
- Delegation is bounded by the configured hop limit in `UniversalAgentContext.max_hops`.
- Result aggregation keeps SQL and table data in a deterministic order while removing duplicates.
- The implementation is designed to match the response shape expected by the main application, especially for streaming and non-streaming bot endpoints.

## Suggested maintenance practices

- Keep routing instructions in `AGENTS.md` and system prompt text in `prompts.py` aligned.
- Avoid repeating adapter logic across sub-agents; the generic wrapper in `subagent_adapters.py` should remain the single place for the standard pattern.
- When adding a new sub-agent, keep the same context and result-shape contract.
- Prefer editing shared business rules and task descriptions in the dedicated files instead of distributing logic across multiple modules.
