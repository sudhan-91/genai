#!/usr/bin/env python3
"""
Generate Denodo MCP API key (Basic auth Base64 token) from SERVICE_USER_NAME and SERVICE_PASSWORD.
Usage: python generate_denodo_mcp_key.py
"""
import base64
import os
from pathlib import Path
from dotenv import load_dotenv

ENV_FILE = Path(__file__).resolve().parent / ".env"
load_dotenv(ENV_FILE)

username = os.getenv("SERVICE_USER_NAME", "").strip()
password = os.getenv("SERVICE_PASSWORD", "").strip()

if not username or not password:
    print("ERROR: SERVICE_USER_NAME and/or SERVICE_PASSWORD not found in .env file")
    exit(1)

credentials = f"{username}:{password}"
api_key = base64.b64encode(credentials.encode("ascii")).decode("ascii")

print("=" * 70)
print("DENODO_MCP_API_KEY (Base64 encoded username:password)")
print("=" * 70)
print(api_key)
print("=" * 70)
print("\nAdd this to .env as:")
print(f'DENODO_MCP_API_KEY = "{api_key}"')
print("=" * 70)
