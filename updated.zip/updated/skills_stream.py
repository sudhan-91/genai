"""Skill-aware streaming for the universal agent in skills mode (`is_skill_invocation = True`).

Place this file at `universal_agent/skills_stream.py` (next to agent.py) and export
`stream_universal_skill_turn_events` from `universal_agent/__init__.py`.

How a skill shows up in the event stream (deepagents SkillsMiddleware + your `bash` tool):
  1. read_file("/skills/<name>/SKILL.md")      -> skill activated
  2. read_file("/skills/<name>/references/..") -> skill reads reference material
  3. bash("python skills/<name>/scripts/x.py <<'EOF' ... EOF") -> skill script runs
  4. a model turn with no tool calls           -> final answer

Unlike sub-agents, skill work and the final answer come from the SAME coordinator model, so
each model run is classified: a run that emits tool calls is intermediate skill work, and a
run that ends without tool calls is the final answer. Text is held back until the run can
be classified; see PENDING_TEXT_LIMIT.

Normalised events yielded (same chunk shape as stream_universal_agent_turn_events):
  on_skill_start              {'skill'}
  on_skill_progress           {'skill', 'kind', 'detail'}   kind: read | tool_start | tool_end | tool_failed
  on_skill_chat_model_stream  {'skill', 'data': {'chunk': SimpleNamespace(content=...)}}
  on_chat_model_stream        {'data': {'chunk': SimpleNamespace(content=...)}}  final answer
  on_chain_end                {'name': 'LangGraph', 'data': {'output': <final state>}}
"""

import logging
import os
import re
from collections.abc import AsyncIterator
from types import SimpleNamespace
from typing import Any, cast

from langchain_core.messages import AIMessage

from nodes.common_nodes import GPT_ERROR_MESSAGE, _is_api_error

from . import agent as _agent
from .context import UniversalAgentContext

logger = logging.getLogger(__name__)

# Tool names, as registered with create_deep_agent (bash) or provided by deepagents (read_file).
FILE_READ_TOOLS = {"read_file"}
SHELL_TOOLS = {"bash", "execute"}

# Patterns accept "/" and "\" because the backend runs on Windows.
SKILL_MD_RE = re.compile(r"(?:^|[\\/])skills[\\/](?P<name>[^\\/]+)[\\/]SKILL\.md$", re.IGNORECASE)
SKILL_PATH_RE = re.compile(r"(?:^|[\s\"'\\/])skills[\\/](?P<name>[^\\/\s\"']+)[\\/]", re.IGNORECASE)
SCRIPT_RE = re.compile(r"(?P<script>[\w.-]+\.(?:py|sh|ps1|bat|cmd))", re.IGNORECASE)

# GPT models usually emit tool-call chunks before any text when they decide to call a tool,
# so a short hold-back is enough. If a run's text passes this many characters with no tool
# call yet, it is treated as the final answer and streamed live from then on. Raise it if
# your model tends to write a long preamble before calling tools.
PENDING_TEXT_LIMIT = 80

COORDINATOR_LABEL = "coordinator"


def _chunk_text(chunk) -> str:
    """Text from a model chunk; content can be a str or a list of content blocks."""
    content = getattr(chunk, "content", "") if chunk is not None else ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content
            if isinstance(block, dict) and block.get("type") in ("text", "text_delta")
        )
    return ""


def _is_nested(event) -> bool:
    """True for events from inside a graph that a tool called (e.g. deepagents' `task`
    sub-agent). Top-level namespaces look like "model:<id>" or "tools:<id>"; nested ones
    have a "|" separator, e.g. "tools:<id>|model:<id>"."""
    ns = (event.get("metadata") or {}).get("langgraph_checkpoint_ns", "") or ""
    return "|" in ns


def _tool_output_text(output) -> str:
    text = getattr(output, "content", output)
    return text if isinstance(text, str) else str(text or "")


def _tool_failed(output) -> bool:
    text = _tool_output_text(output)
    return "[STDERR]" in text or text.startswith("Error")


def _describe_command(command: str) -> str:
    """Short, UI-friendly label for a bash command (heredoc body and arguments dropped)."""
    first_line = command.strip().splitlines()[0] if command.strip() else ""
    match = SCRIPT_RE.search(first_line)
    if match:
        return match.group("script")
    return first_line if len(first_line) <= 80 else first_line[:79] + "…"


def _chunk_event(event_name: str, text: str, skill: str | None = None) -> dict:
    event = {"event": event_name, "data": {"chunk": SimpleNamespace(content=text)}}
    if skill is not None:
        event["skill"] = skill
    return event


async def stream_universal_skill_turn_events(
    user_input: str,
    user_id: str,
    chat_id: str,
    context: UniversalAgentContext,
) -> AsyncIterator[dict]:
    """Stream one skills-mode turn as normalised events (see module docstring)."""
    if not _agent.is_skill_invocation:
        raise RuntimeError(
            "stream_universal_skill_turn_events requires agent.is_skill_invocation = True"
        )

    agent = _agent.get_universal_agent()
    messages = _agent._build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})

    active_skill: str | None = None
    model_runs: dict[str, dict] = {}   # run_id -> {"mode": pending|skill|final, "buf": str}
    tool_runs: dict[str, dict] = {}    # run_id -> {"tool", "skill", "label"}
    final_output = None

    def skill_label() -> str:
        return active_skill or COORDINATOR_LABEL

    try:
        async for ev in cast(Any, agent).astream_events(
            agent_input,
            version="v2",
            config=_agent._master_langfuse_config(context),
            context=context,
        ):
            kind = ev.get("event")
            run_id = ev.get("run_id")
            data = ev.get("data") or {}

            # Root graph finished: this is the final state (root run has no parents).
            if kind == "on_chain_end" and not ev.get("parent_ids"):
                final_output = data.get("output")
                continue

            if _is_nested(ev):
                continue

            # ---- coordinator model text -------------------------------------------------
            if kind == "on_chat_model_start":
                model_runs[run_id] = {"mode": "pending", "buf": ""}

            elif kind == "on_chat_model_stream":
                state = model_runs.setdefault(run_id, {"mode": "pending", "buf": ""})
                chunk = data.get("chunk")
                text = _chunk_text(chunk)
                has_tool_call = bool(getattr(chunk, "tool_call_chunks", None))

                if state["mode"] == "pending" and has_tool_call:
                    state["mode"] = "skill"
                    if state["buf"]:
                        yield _chunk_event("on_skill_chat_model_stream", state["buf"], skill_label())
                        state["buf"] = ""

                if not text:
                    continue
                if state["mode"] == "final":
                    yield _chunk_event("on_chat_model_stream", text)
                elif state["mode"] == "skill":
                    yield _chunk_event("on_skill_chat_model_stream", text, skill_label())
                else:
                    state["buf"] += text
                    if len(state["buf"]) > PENDING_TEXT_LIMIT:
                        state["mode"] = "final"
                        yield _chunk_event("on_chat_model_stream", state["buf"])
                        state["buf"] = ""

            elif kind == "on_chat_model_end":
                state = model_runs.pop(run_id, None)
                if state and state["mode"] == "pending" and state["buf"]:
                    if getattr(data.get("output"), "tool_calls", None):
                        yield _chunk_event("on_skill_chat_model_stream", state["buf"], skill_label())
                    else:
                        yield _chunk_event("on_chat_model_stream", state["buf"])

            # ---- skill activation and skill tool use ------------------------------------
            elif kind == "on_tool_start":
                tool_name = ev.get("name", "")
                tool_input = data.get("input") or {}
                if not isinstance(tool_input, dict):
                    tool_input = {}

                if tool_name in FILE_READ_TOOLS:
                    path = str(tool_input.get("file_path") or tool_input.get("path") or "")
                    skill_md = SKILL_MD_RE.search(path)
                    if skill_md:
                        active_skill = skill_md.group("name")
                        yield {"event": "on_skill_start", "skill": active_skill}
                    elif active_skill and path:
                        yield {"event": "on_skill_progress", "skill": active_skill, "kind": "read",
                               "detail": os.path.basename(path.rstrip("/\\"))}

                elif tool_name in SHELL_TOOLS:
                    command = str(tool_input.get("command") or "")
                    path_skill = SKILL_PATH_RE.search(command)
                    # Skill scripts may run without SKILL.md being re-read this turn.
                    if path_skill and path_skill.group("name") != active_skill:
                        active_skill = path_skill.group("name")
                        yield {"event": "on_skill_start", "skill": active_skill}
                    label = _describe_command(command)
                    tool_runs[run_id] = {"tool": tool_name, "skill": skill_label(), "label": label}
                    yield {"event": "on_skill_progress", "skill": skill_label(), "kind": "tool_start",
                           "detail": label}

            elif kind == "on_tool_end":
                info = tool_runs.pop(run_id, None)
                if info:
                    failed = _tool_failed(data.get("output"))
                    yield {"event": "on_skill_progress", "skill": info["skill"],
                           "kind": "tool_failed" if failed else "tool_end",
                           "detail": info["label"]}

    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[stream_universal_skill_turn_events] GPT API error detected: {exc}")
        yield _chunk_event("on_chat_model_stream", GPT_ERROR_MESSAGE)
        yield {"event": "on_chain_end", "name": "LangGraph",
               "data": {"output": {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}}}
        return

    if final_output is None:
        raise RuntimeError("Skills agent finished without a root on_chain_end event")
    yield {"event": "on_chain_end", "name": "LangGraph", "data": {"output": final_output}}
