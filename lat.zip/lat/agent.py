"""Universal orchestrator agent built on `deepagents`.

Wraps the existing product/shipment/far sub-agent LangGraph graphs as
`CompiledSubAgent`s and lets a `deepagents`-powered main agent select the
appropriate delegated sub-agent(s), run them in sequence/parallel, and synthesize
one final answer.
"""

import ast
import asyncio
import json
import logging
import sys
from collections.abc import AsyncIterator
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast
import re
import os
import subprocess
from langchain_core.tools import tool

from deepagents import create_deep_agent
from deepagents.backends.filesystem import FilesystemBackend
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage

sys.path.append(str(Path(__file__).resolve().parent.parent))

from configs.config_data import configData
from nodes.common_nodes import GPT_ERROR_MESSAGE, _is_api_error
from nodes.far_sub_agent import farSubAgent
from nodes.product_sub_agent import productSubAgent
from nodes.shipment_sub_agent import shipmentSubAgent

from .context import UniversalAgentContext
from .history import load_history_messages, save_turn
from .prompts import SYSTEM_PROMPT, SYSTEM_PROMPT_SKILLS
from .subagent_adapters import (
    build_far_subagent,
    build_product_subagent,
    build_shipment_subagent,
)

logger = logging.getLogger(__name__)

config = configData()

BASE_DIR = Path(__file__).resolve().parent
CURRENT_DATE = datetime.now().strftime("%Y-%m-%d")
_universal_agent = None

is_skill_invocation = True
SKILL_SOURCES = ["/skills/"]
SKILL_MODE_MEMORY = ["/AGENTS_SKILLS.md"]
from .skill_runtime import bash as skill_bash

# `CompiledSubAgent` registered names (used by `stream.subagents`, see
# `subagent_adapters.py`'s `build_*_subagent()`) vs. the `bot_tag` each adapter
# reports through `context.progress_events` -- kept in sync so progress entries
# from both sources use the same `subagent` label.
_SUBAGENT_NAME_TO_BOT_TAG = {
    "product-agent": "product_bot",
    "shipment-agent": "shipment_bot",
    "far-agent": "far_bot",
}

VENV_PYTHON = r"C:\Users\RajaduraiSud\PycharmProjects\PythonProject\.venv1\Scripts\python.exe"
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
HEREDOC = re.compile(r"<<-?\s*['\"]?(\w+)['\"]?[ \t]*\r?\n(.*?)\r?\n[ \t]*\1[ \t]*$", re.S)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
backend = FilesystemBackend(root_dir=SCRIPT_DIR)

def _normalize_nested_list_values(raw_value: Any) -> list[str]:
    """Flatten nested JSON/list payloads into a deduplicated list of strings."""
    if raw_value is None:
        return []

    if isinstance(raw_value, (list, tuple, set)):
        flattened: list[str] = []
        for item in raw_value:
            flattened.extend(_normalize_nested_list_values(item))
        return flattened

    if isinstance(raw_value, str):
        stripped = raw_value.strip()
        if not stripped:
            return []
        if stripped.startswith("["):
            try:
                parsed = json.loads(stripped)
            except json.JSONDecodeError:
                return [raw_value]
            return _normalize_nested_list_values(parsed)
        return [stripped]

    return [str(raw_value)]


def _deduplicate_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def _normalize_sql_data_source_keys(subagent_results: list[dict]) -> dict[str, str]:
    """Rename merged dataframe payloads to sequential df_1..df_n keys."""
    normalized: dict[str, str] = {}
    next_index = 1
    for entry in subagent_results:
        for _df_key, csv_str in (entry.get("sql_data_source") or {}).items():
            normalized[f"df_{next_index}"] = csv_str
            next_index += 1
    return normalized


def _build_turn_messages(user_input: str, user_id: str, chat_id: str) -> list[BaseMessage]:
    """Load recent chat context and append the current user message."""
    history = load_history_messages(user_id, chat_id)
    reminder = "\n\n[Write the final answer in the same language as the message above.]"
    return [*history, HumanMessage(content=user_input + reminder)]


def _master_langfuse_config(context: UniversalAgentContext) -> dict:
    """Master-run tracing config; its handler is stored on the context so sub-agents nest under it."""
    langfuse_config = config.get_langfuse_config(
        "universal_agent",
        "master_agent",
        user_id=context.user_id,
        session_id=context.chat_id,
        run_name="universal_agent",
    )
    callbacks = langfuse_config.get("callbacks")
    context.langfuse_handler = callbacks[0] if callbacks else None
    return langfuse_config


def _extract_subagent_payloads(context: UniversalAgentContext) -> list[dict]:
    """Return the normalized sub-agent metadata collected during the turn."""
    return list(getattr(context, "subagent_results", []) or [])


def _get_final_answer(result: dict) -> str:
    """Safely extract the last agent message as a human-readable answer."""
    messages = result.get("messages") if isinstance(result, dict) else []
    if not messages:
        return ""

    final_message = messages[-1]
    content = getattr(final_message, "content", "") or ""
    if isinstance(content, list):
        text_parts = []
        for part in content:
            if isinstance(part, dict):
                text = part.get("text")
                if text is not None:
                    text_parts.append(str(text))
                    continue
            text_parts.append(str(part))
        joined = "".join(text_parts)
        return joined
    if not isinstance(content, str):
        return str(content)
    return content



@tool
def bash(command: str) -> str:
    """
    Execute a shell command relative to the project root using the project's venv Python.
    Supports heredoc stdin (cmd <<'TAG' ... TAG) on Windows, and fixes virtual-FS style
    leading-slash paths (e.g. /skills/...).
    """
    # cmd.exe has no heredoc: move the heredoc body to stdin
    stdin_data = None
    m = HEREDOC.search(command)
    if m:
        stdin_data = m.group(2) + "\n"
        command = command[:m.start()].rstrip()

    command = re.sub(r'(?<![\w:])/(skills|references|scripts)/', r'\1/', command)
    if command.strip().startswith("python "):
        command = command.replace("python ", f'"{VENV_PYTHON}" ', 1)

    try:
        result = subprocess.run(
            command,
            shell=True,
            input=stdin_data,
            capture_output=True,
            text=True,
            timeout=300,  # must exceed the scripts' own query timeouts (shipment: 120 s)
            cwd=PROJECT_ROOT,
        )
        output = result.stdout.strip()
        if result.returncode != 0:
            output += f"\n[STDERR]\n{result.stderr.strip()}"
        return output if output else "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: command timed out"
    except Exception as e:
        return f"Error executing command: {e}"


def build_universal_agent():
    """Construct the deep-agent orchestrator that delegates to product, shipment,
    and FAR sub-agents."""
    config = configData()

    if is_skill_invocation:
        return create_deep_agent(
            model=config.universal_agent_llm,
            system_prompt=SYSTEM_PROMPT_SKILLS.format(date=CURRENT_DATE),
            tools=[bash],
            skills=["/skills/"],
            backend=backend
        )

    else:
        product_obj = productSubAgent()
        shipment_obj = shipmentSubAgent()
        far_obj = farSubAgent()

        subagents = [
            build_product_subagent(product_obj.product_app),
            build_shipment_subagent(shipment_obj.shipment_app),
            build_far_subagent(far_obj.far_app),
        ]

        return create_deep_agent(
            model=config.universal_agent_llm,
            system_prompt=SYSTEM_PROMPT.format(date=CURRENT_DATE),
            subagents=subagents,
            memory=["./AGENTS.md"],
            backend=FilesystemBackend(root_dir=str(BASE_DIR)),
            context_schema=UniversalAgentContext,
        )


def get_universal_agent():
    """Lazily build and cache the universal agent singleton."""
    global _universal_agent
    if _universal_agent is None:
        _universal_agent = build_universal_agent()
    return _universal_agent


def invoke_universal_agent(user_input: str, user_id: str, chat_id: str) -> str:
    """Run one universal-agent turn and persist the synthesized answer."""
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})
    context = UniversalAgentContext(user_id=user_id, chat_id=chat_id)

    try:
        result = agent.invoke(
            agent_input,
            config=_master_langfuse_config(context),
            context=context,
        )
        answer = _get_final_answer(result)
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[invoke_universal_agent] GPT API error detected: {exc}")
        answer = GPT_ERROR_MESSAGE
    save_turn(user_id, chat_id, user_input, answer)
    return answer


def invoke_universal_agent_full(user_input: str, user_id: str, chat_id: str) -> dict:
    """Run one turn and return top-level payload metadata plus each sub-agent's
    SQL/table payloads in the shape expected by the rest of the application."""
    context = UniversalAgentContext(user_id=user_id, chat_id=chat_id)
    result = run_universal_agent_turn(user_input, user_id, chat_id, context)
    return build_full_result(user_input, user_id, chat_id, result, context)


def run_universal_agent_turn(user_input: str, user_id: str, chat_id: str, context: UniversalAgentContext) -> dict:
    """Execute one full turn against the supplied runtime context."""
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    try:

        result =  agent.invoke(
            cast(Any, {"messages": messages}),
            # config=_master_langfuse_config(context),
            context=context
        )
        for m in result["messages"]:
            kind = m.__class__.__name__
            if kind == "AIMessage" and m.tool_calls:
                for tc in m.tool_calls:
                    print("CALL  :", tc["name"], tc["args"])
            elif kind == "ToolMessage":
                print("RESULT:", m.content)  # the DB error shows up here
        print("FINAL :", result["messages"][-1].content)
        return result
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[run_universal_agent_turn] GPT API error detected: {exc}")
        return {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}


async def stream_universal_agent_turn_events(
    user_input: str,
    user_id: str,
    chat_id: str,
    context: UniversalAgentContext,
) -> AsyncIterator[dict]:
    """Stream the coordinator's final answer plus subagent completion for one turn.

    Uses LangGraph/deepagents' typed `version="v3"` streaming protocol
    (`stream.messages` / `stream.subagents`, see
    https://docs.langchain.com/oss/python/deepagents/event-streaming) instead of
    raw `v2` event dicts. `message.text` only ever yields real text deltas, so
    tool-call-planning turns (which stream no text) are skipped by construction
    -- no more inferring "is this the final answer" from raw chunk shape.

    Yields coordinator text deltas, labeled subagent answer deltas, and one
    final `on_chain_end` event with the graph output. The subagent text uses a
    separate event so clients can display it without merging it into the final
    coordinator synthesis.

    Each subagent (`product-agent`/`shipment-agent`/`far-agent`, all registered
    as `CompiledSubAgent`s and auto-named via `lc_agent_name`) gets its own
    `stream.subagents` handle; draining it concurrently with the coordinator's
    text stream appends `subagent_completed`/`subagent_failed` milestones to
    `context.progress_events`. Sub-agent answer tokens are not visible on the
    outer v3 stream (each adapter runs its graph in its own event loop), so they
    arrive through `context.stream_sink`. `subagent_started` (with the delegated task text) is still
    reported by `subagent_adapters.py`, since the task description isn't
    exposed on this handle.
    """
    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})

    # GPT server-side failures (rate limit, timeout, connection) can surface either
    # from `astream_events()` itself or while draining `stream.messages`/`stream.output()`
    # below -- both paths are wrapped so callers still get a usable final answer instead
    # of a raw unhandled exception.
    try:
        stream = await cast(Any, agent).astream_events(
            agent_input,
            version="v3",
            config=_master_langfuse_config(context),
            context=context,
        )

        event_queue: asyncio.Queue = asyncio.Queue()
        stream_done = object()
        # Subscribe to both root projections before either consumer can advance
        # the shared graph pump; StreamChannel does not retain pre-subscription items.
        coordinator_messages = stream.messages.__aiter__()
        subagent_handles = stream.subagents.__aiter__()

        loop = asyncio.get_running_loop()

        def _subagent_sink(bot_tag: str, delta: str) -> None:
            # Called from adapter worker threads, each running its own event loop.
            loop.call_soon_threadsafe(event_queue.put_nowait, {
                "event": "on_subagent_chat_model_stream",
                "name": "summarizer",
                "subagent": bot_tag,
                "data": {"chunk": SimpleNamespace(content=delta)},
            })

        context.stream_sink = _subagent_sink

        async def _drain_subagents(handles) -> None:
            try:
                subagent_tasks = []
                async for sub in handles:
                    subagent_tasks.append(asyncio.create_task(_drain_subagent(sub)))
                if subagent_tasks:
                    await asyncio.gather(*subagent_tasks)
            finally:
                await event_queue.put(stream_done)

        async def _drain_subagent(sub) -> None:
            bot_tag = _SUBAGENT_NAME_TO_BOT_TAG.get(sub.name or "", sub.name or "unknown")
            try:
                await sub.output()
            except Exception as exc:
                context.progress_events.append({
                    "subagent": bot_tag,
                    "stage": "subagent_failed",
                    "message": f"{bot_tag} failed: {exc}",
                    "error": str(exc),
                })
            else:
                context.progress_events.append({
                    "subagent": bot_tag,
                    "stage": "subagent_completed",
                    "message": "",
                })

        async def _drain_coordinator(messages) -> None:
            try:
                async for message in messages:
                    async for delta in message.text:
                        if delta:
                            await event_queue.put({
                                "event": "on_chat_model_stream",
                                "name": message.node,
                                "data": {"chunk": SimpleNamespace(content=delta)},
                            })
            finally:
                await event_queue.put(stream_done)

        coordinator_task = asyncio.create_task(_drain_coordinator(coordinator_messages))
        subagents_task = asyncio.create_task(_drain_subagents(subagent_handles))
        try:
            completed_streams = 0
            while completed_streams < 2:
                item = await event_queue.get()
                if item is stream_done:
                    completed_streams += 1
                    continue
                yield item
            await coordinator_task
            await subagents_task
            output = await stream.output()
        finally:
            context.stream_sink = None
            for task in (coordinator_task, subagents_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(coordinator_task, subagents_task, return_exceptions=True)
    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[stream_universal_agent_turn_events] GPT API error detected: {exc}")
        yield {
            "event": "on_chat_model_stream",
            "name": "gpt_error_handler",
            "tags": [],
            "data": {"chunk": SimpleNamespace(content=GPT_ERROR_MESSAGE)},
        }
        yield {
            "event": "on_chain_end",
            "name": "LangGraph",
            "data": {"output": {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}},
        }
        return

    yield {"event": "on_chain_end", "name": "LangGraph", "data": {"output": output}}


# =============================================================================================
# Skills-mode streaming (is_skill_invocation = True)
#
# How a skill shows up in the event stream (deepagents SkillsMiddleware + the `bash` tool):
#   1. read_file("/skills/<name>/SKILL.md")      -> skill activated
#   2. read_file("/skills/<name>/references/..") -> skill reads reference material
#   3. bash("python skills/<name>/scripts/x.py ...") -> skill script runs
#   4. a model turn with no tool calls           -> final answer
# Skill work and the final answer come from the SAME coordinator model, so each model run is
# classified: a run that emits tool calls is skill work, a run that ends without them is the
# final answer. Text is held back until the run can be classified (PENDING_TEXT_LIMIT).
# =============================================================================================

# Tool names, as registered with create_deep_agent (bash) or provided by deepagents (read_file).
SKILL_FILE_READ_TOOLS = {"read_file"}
SKILL_SHELL_TOOLS = {"bash", "execute"}

# Patterns accept "/" and "\" because the backend runs on Windows.
SKILL_MD_RE = re.compile(r"(?:^|[\\/])skills[\\/](?P<name>[^\\/]+)[\\/]SKILL\.md$", re.IGNORECASE)
SKILL_PATH_RE = re.compile(r"(?:^|[\s\"'\\/])skills[\\/](?P<name>[^\\/\s\"']+)[\\/]", re.IGNORECASE)
SCRIPT_RE = re.compile(r"(?P<script>[\w.-]+\.(?:py|sh|ps1|bat|cmd))", re.IGNORECASE)

# GPT models usually emit tool-call chunks before any text when they decide to call a tool,
# so a short hold-back is enough. If a run's text passes this many characters with no tool
# call yet, it is treated as the final answer and streamed live from then on. Raise it if
# your model tends to write a long preamble before calling tools.
PENDING_TEXT_LIMIT = 80

COORDINATOR_LABEL = "coordinator"


def _skill_chunk_text(chunk) -> str:
    """Text from a model chunk; content can be a str or a list of content blocks."""
    content = getattr(chunk, "content", "") if chunk is not None else ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content
            if isinstance(block, dict) and block.get("type") in ("text", "text_delta")
        )
    return ""


def _is_nested(event) -> bool:
    """True for events from inside a graph that a tool called (e.g. deepagents' `task`
    sub-agent). Top-level namespaces look like "model:<id>" or "tools:<id>"; nested ones
    have a "|" separator, e.g. "tools:<id>|model:<id>"."""
    ns = (event.get("metadata") or {}).get("langgraph_checkpoint_ns", "") or ""
    return "|" in ns


def _tool_output_text(output) -> str:
    text = getattr(output, "content", output)
    return text if isinstance(text, str) else str(text or "")


def _tool_failed(output) -> bool:
    text = _tool_output_text(output)
    return "[STDERR]" in text or text.startswith("Error")


def _describe_command(command: str) -> str:
    """Short, UI-friendly label for a bash command (heredoc body and arguments dropped)."""
    first_line = command.strip().splitlines()[0] if command.strip() else ""
    match = SCRIPT_RE.search(first_line)
    if match:
        return match.group("script")
    return first_line if len(first_line) <= 80 else first_line[:79] + "…"


# ---- capturing skill SQL results for `response_file` ------------------------------------------
# In sub-agent mode the FAR/product/shipment adapters write their SQL, tables and data source into
# `context.subagent_results`, which `build_full_result` turns into `response_file`. In skills mode
# the same data comes back as the JSON object a skill's `execute_sql_query.py` prints, so each
# finished run of that script is parsed here and recorded in the same shape.
SKILL_SQL_SCRIPT_RE = re.compile(r"execute_sql_query\.py", re.IGNORECASE)
SQL_TABLE_RE = re.compile(r"\b(?:FROM|JOIN)\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?", re.IGNORECASE)
# Skill folder name -> the `subagent` label the sub-agent path uses (drives `intent`).
SKILL_NAME_TO_BOT_TAG = {
    "far": "far_bot",
    "product": "product_bot",
    "shipment": "shipment_bot",
}


def _parse_heredoc_payload(command: str) -> dict:
    """Return {"sql": [...], "reasoning": str} from the heredoc a skill passed to its script."""
    match = HEREDOC.search(command)
    if not match:
        return {"sql": [], "reasoning": ""}
    body = re.sub(r"^```(?:json|sql|python)?\s*|\s*```$", "", match.group(2).strip())
    parsed = None
    for loader in (json.loads, ast.literal_eval):
        try:
            parsed = loader(body)
            break
        except Exception:
            continue
    reasoning = ""
    if isinstance(parsed, dict):
        reasoning = str(parsed.get("reasoning") or "")
        parsed = parsed.get("sql", [])
    if isinstance(parsed, str):
        parsed = [parsed]
    queries = [str(q).strip() for q in parsed or [] if str(q).strip()] if isinstance(parsed, list) else []
    return {"sql": queries, "reasoning": reasoning}


def _parse_script_json(output) -> dict | None:
    """The skill scripts print exactly one JSON object; find it in the tool output."""
    for line in reversed(_tool_output_text(output).splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
    return None


def _load_data_source_csv(path_value: str) -> str | None:
    """Read a data-source CSV the script wrote and return it pipe-separated with NULL for blanks,
    the same format the sub-agent adapters put in `sql_data_source`."""
    import pandas as pd

    path = Path(path_value)
    if not path.is_absolute():
        path = Path(PROJECT_ROOT) / path  # the bash tool runs scripts with cwd=PROJECT_ROOT
    try:
        df = pd.read_csv(path, dtype=str)
    except Exception as exc:
        logger.warning(f"[skills] could not read data source {path}: {exc}")
        return None
    return df.to_csv(index=False, sep="|", na_rep="NULL")


def _build_skill_sql_entry(skill: str, payload: dict, script_out: dict) -> dict | None:
    """Turn one `execute_sql_query.py` run into a `subagent_results` entry, or None if it
    returned no data."""
    statuses = script_out.get("query_status") or []
    ok_queries = [s.get("query") for s in statuses if s.get("status") == "ok" and s.get("query")]
    queries = ok_queries or [s.get("query") for s in statuses if s.get("query")] or payload["sql"]

    data_source: dict[str, str] = {}
    for df_key, path_value in (script_out.get("sql_data_source") or {}).items():
        csv_text = _load_data_source_csv(str(path_value))
        if csv_text:
            data_source[df_key] = csv_text
    if not data_source and not script_out.get("sql_result"):
        return None

    tables = _deduplicate_preserve_order(
        [m.upper() for q in queries for m in SQL_TABLE_RE.findall(q)]
    )
    return {
        "subagent": SKILL_NAME_TO_BOT_TAG.get(skill, skill),
        "sql": queries,
        "sql_tables": tables,
        "sql_data_source": data_source,
        "sql_reasoning": payload["reasoning"],
    }


def _chunk_event(event_name: str, text: str, skill: str | None = None) -> dict:
    event = {"event": event_name, "data": {"chunk": SimpleNamespace(content=text)}}
    if skill is not None:
        event["skill"] = skill
    return event


async def stream_universal_skill_turn_events(
    user_input: str,
    user_id: str,
    chat_id: str,
    context: UniversalAgentContext,
) -> AsyncIterator[dict]:
    """Stream one skills-mode turn as normalised events (see module docstring)."""
    if not is_skill_invocation:
        raise RuntimeError(
            "stream_universal_skill_turn_events requires agent.is_skill_invocation = True"
        )

    agent = get_universal_agent()
    messages = _build_turn_messages(user_input, user_id, chat_id)
    agent_input = cast(Any, {"messages": messages})

    active_skill: str | None = None
    model_runs: dict[str, dict] = {}   # run_id -> {"mode": pending|skill|final, "buf": str}
    tool_runs: dict[str, dict] = {}    # run_id -> {"tool", "skill", "label", "command"}
    skill_sql_results: dict[str, dict] = {}  # skill -> latest execute_sql_query.py entry with data
    final_output = None

    def skill_label() -> str:
        return active_skill or COORDINATOR_LABEL

    try:
        async for ev in cast(Any, agent).astream_events(
            agent_input,
            version="v2",
            config=_master_langfuse_config(context),
            context=context,
        ):
            kind = ev.get("event")
            run_id = ev.get("run_id")
            data = ev.get("data") or {}

            # Root graph finished: this is the final state (root run has no parents).
            if kind == "on_chain_end" and not ev.get("parent_ids"):
                final_output = data.get("output")
                continue

            if _is_nested(ev):
                continue

            # ---- coordinator model text -------------------------------------------------
            if kind == "on_chat_model_start":
                model_runs[run_id] = {"mode": "pending", "buf": ""}

            elif kind == "on_chat_model_stream":
                state = model_runs.setdefault(run_id, {"mode": "pending", "buf": ""})
                chunk = data.get("chunk")
                text = _skill_chunk_text(chunk)
                has_tool_call = bool(getattr(chunk, "tool_call_chunks", None))

                if state["mode"] == "pending" and has_tool_call:
                    state["mode"] = "skill"
                    if state["buf"]:
                        yield _chunk_event("on_skill_chat_model_stream", state["buf"], skill_label())
                        state["buf"] = ""

                if not text:
                    continue
                if state["mode"] == "final":
                    yield _chunk_event("on_chat_model_stream", text)
                elif state["mode"] == "skill":
                    yield _chunk_event("on_skill_chat_model_stream", text, skill_label())
                else:
                    state["buf"] += text
                    if len(state["buf"]) > PENDING_TEXT_LIMIT:
                        state["mode"] = "final"
                        yield _chunk_event("on_chat_model_stream", state["buf"])
                        state["buf"] = ""

            elif kind == "on_chat_model_end":
                state = model_runs.pop(run_id, None)
                if state and state["mode"] == "pending" and state["buf"]:
                    if getattr(data.get("output"), "tool_calls", None):
                        yield _chunk_event("on_skill_chat_model_stream", state["buf"], skill_label())
                    else:
                        yield _chunk_event("on_chat_model_stream", state["buf"])

            # ---- skill activation and skill tool use ------------------------------------
            elif kind == "on_tool_start":
                tool_name = ev.get("name", "")
                tool_input = data.get("input") or {}
                if not isinstance(tool_input, dict):
                    tool_input = {}

                if tool_name in SKILL_FILE_READ_TOOLS:
                    path = str(tool_input.get("file_path") or tool_input.get("path") or "")
                    skill_md = SKILL_MD_RE.search(path)
                    if skill_md:
                        active_skill = skill_md.group("name")
                        yield {"event": "on_skill_start", "skill": active_skill}
                    elif active_skill and path:
                        yield {"event": "on_skill_progress", "skill": active_skill, "kind": "read",
                               "detail": os.path.basename(path.rstrip("/\\"))}

                elif tool_name in SKILL_SHELL_TOOLS:
                    command = str(tool_input.get("command") or "")
                    path_skill = SKILL_PATH_RE.search(command)
                    # Skill scripts may run without SKILL.md being re-read this turn.
                    if path_skill and path_skill.group("name") != active_skill:
                        active_skill = path_skill.group("name")
                        yield {"event": "on_skill_start", "skill": active_skill}
                    label = _describe_command(command)
                    tool_runs[run_id] = {"tool": tool_name, "skill": skill_label(), "label": label,
                                         "command": command}
                    reasoning = ""
                    if SKILL_SQL_SCRIPT_RE.search(command):
                        reasoning = _parse_heredoc_payload(command)["reasoning"]
                    if reasoning:
                        # Same milestone the sub-agent path shows from `sql_generated`.
                        yield {"event": "on_skill_progress", "skill": skill_label(),
                               "kind": "sql_generated", "detail": reasoning}
                    else:
                        yield {"event": "on_skill_progress", "skill": skill_label(),
                               "kind": "tool_start", "detail": label}

            elif kind == "on_tool_end":
                info = tool_runs.pop(run_id, None)
                if info:
                    output = data.get("output")
                    if SKILL_SQL_SCRIPT_RE.search(info["command"]):
                        script_out = _parse_script_json(output)
                        if script_out:
                            entry = _build_skill_sql_entry(
                                info["skill"], _parse_heredoc_payload(info["command"]), script_out
                            )
                            # Retries resend the successful queries, so the latest run with
                            # data is the complete one.
                            if entry:
                                skill_sql_results[info["skill"]] = entry
                    failed = _tool_failed(output)
                    yield {"event": "on_skill_progress", "skill": info["skill"],
                           "kind": "tool_failed" if failed else "tool_end",
                           "detail": info["label"]}

    except Exception as exc:
        if not _is_api_error(exc):
            raise
        logger.error(f"[stream_universal_skill_turn_events] GPT API error detected: {exc}")
        yield _chunk_event("on_chat_model_stream", GPT_ERROR_MESSAGE)
        yield {"event": "on_chain_end", "name": "LangGraph",
               "data": {"output": {"messages": [AIMessage(content=GPT_ERROR_MESSAGE)]}}}
        return

    if final_output is None:
        raise RuntimeError("Skills agent finished without a root on_chain_end event")
    # Hand the captured SQL results to build_full_result the same way the sub-agent adapters do.
    if not isinstance(getattr(context, "subagent_results", None), list):
        context.subagent_results = []
    context.subagent_results.extend(skill_sql_results.values())
    yield {"event": "on_chain_end", "name": "LangGraph", "data": {"output": final_output}}


def build_full_result(user_input: str, user_id: str, chat_id: str, result: dict, context: UniversalAgentContext) -> dict:
    """Build the final answer payload and persist the turn metadata.

    `deepagents` returns only the final message list, so we recover the per-subagent
    state from the shared `UniversalAgentContext.subagent_results` side channel.
    """
    answer = _get_final_answer(result)
    subagent_results = _extract_subagent_payloads(context)

    intents = _deduplicate_preserve_order(
        [str(entry.get("subagent")) for entry in subagent_results if entry.get("subagent")]
    )
    intent = intents[0] if len(intents) == 1 else ", ".join(intents)
    sql = [
        query
        for entry in subagent_results
        for query in _normalize_nested_list_values(entry.get("sql"))
    ]

    sql_tables: list[str] = []
    for entry in subagent_results:
        sql_tables.extend(_normalize_nested_list_values(entry.get("sql_tables")))
    sql_tables = _deduplicate_preserve_order(sql_tables)

    reasoning_parts: list[str] = []
    for entry in subagent_results:
        sql_reasoning = str(entry.get("sql_reasoning") or "").strip()
        if sql_reasoning:
            reasoning_parts.append(sql_reasoning)
            continue

        general_statement = str(entry.get("general_statement") or "").strip()
        if general_statement:
            reasoning_parts.append(general_statement)

    reasoning = "\n".join(reasoning_parts)
    sql_data_source = _normalize_sql_data_source_keys(subagent_results)

    save_turn(
        user_id,
        chat_id,
        user_input,
        answer,
        sql=sql,
        intent=intent,
        reasoning=reasoning,
        sql_tables=sql_tables,
        sql_data_source=sql_data_source,
    )

    return {
        "model_output": answer,
        "sql": sql,
        "sql_tables": sql_tables,
        "intent": intent,
        "reasoning": reasoning,
        "sql_data_source": sql_data_source,
        "execution_trace": list(context.execution_trace),
    }
