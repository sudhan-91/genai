import asyncio
import logging
import uuid
import traceback
import json
import time
import random
import os
import numpy as np
import pandas as pd
from io import StringIO
import io
from openpyxl import load_workbook
from graphs.product_graph import productGraph
from graphs.shipment_graph import shipmentGraph
from graphs.far_graph import farGraph
from graphs.general_graph import generalGraph
# from graphs.audit_graph import auditGraph
from graphs.multiple_product import multipleProduct
# from graphs.prod_management_graph import prodManagementGraph
# from production_management.utils import replace_s3_images_with_base64
from universal_agent import (
    build_full_result,
    invoke_universal_agent_full,
    stream_universal_agent_turn_events,
    UniversalAgentContext,
)
# Imported straight from the module so universal_agent/__init__.py needs no change.
from universal_agent.agent import stream_universal_skill_turn_events

logger = logging.getLogger(__name__)
from configs.config_data import configData
from sql_services import sqlServices
from static_responses import staticResponses
from langfuse import Langfuse, get_client
from langfuse.langchain import CallbackHandler
sql_service = sqlServices()
static_response = staticResponses()
config_data = configData()
import httpx
import shutil
import uuid
from utils.data_utils import classify_and_combine_sql_results_product


def universal_sql_data_source_to_records(sql_result_dict: dict) -> dict:
    """Convert each universal-agent dataframe CSV payload into a records list.

    Unlike `classify_and_combine_sql_results_product`, this preserves every
    prefixed dataframe from every delegated subagent instead of collapsing them
    into product/BOM buckets.
    """
    result = {}
    for df_key, csv_str in (sql_result_dict or {}).items():
        df = pd.read_csv(StringIO(csv_str), sep='|')
        df = df.replace({np.nan: "null"}).fillna("null").astype(str)
        result[df_key] = df.to_dict(orient='records')
    return result


def _render_universal_progress_event(entry: dict) -> str:
    """Map one subagent progress entry to a user-facing reasoning message.

    The universal-agent stream keeps the task-delegation and SQL reasoning steps
    visible for tracing, but intentionally suppresses sub-agent final answers so
    the UI does not render raw subagent responses during the middle of execution.
    Internal validation or bookkeeping stages are ignored.
    """
    stage = entry.get('stage')
    bot_tag = entry.get('subagent', 'unknown')
    display_name = bot_tag.replace('_bot', ' agent')

    if stage == 'subagent_started':
        task_text = (entry.get('task') or '').strip()
        if task_text:
            return f"Delegating to {display_name}: {task_text}"
        return f"Delegating to {display_name}"

    if stage == 'sql_generated':
        return entry.get('sql_reasoning') or ''

    if stage in ('subagent_response', 'subagent_completed', 'subagent_failed'):
        return ''

    return ''


def _render_skill_progress_event(event: dict) -> str:
    """Map one skill milestone to a user-facing reasoning message."""
    skill = event.get('skill', 'unknown')
    display_name = skill.replace('-', ' ').replace('_', ' ')

    if event.get('event') == 'on_skill_start':
        return f"Using {display_name} skill"

    kind = event.get('kind')
    detail = event.get('detail', '')
    if kind == 'sql_generated':
        # SQL reasoning from the skill's query, same as the sub-agent `sql_generated` step.
        return detail
    if kind == 'read':
        return f"Reading {detail}"
    if kind == 'tool_start':
        return f"Running {detail}"
    if kind == 'tool_failed':
        return f"{detail} failed, retrying"
    # 'tool_end' is not shown; the next step or the answer follows immediately.
    return ''


def _format_stream_error_event(exc: Exception, step: int, chat_id, user_id, message_id: str) -> str:
    """Return one SSE error frame with a real traceback payload."""
    traceback_text = traceback.format_exc()
    logger.exception("Streaming endpoint failed", exc_info=exc)
    payload = {
        'type': 'error',
        'message': str(exc) or exc.__class__.__name__,
        'traceback': traceback_text,
        'chat_id': chat_id,
        'step': step,
        'user_id': user_id,
        'message_id': message_id,
    }
    return f"data: {json.dumps(payload, ensure_ascii=False)} \n\n"

class botController(object):
    def __init__(self):
        try:
            self.product_obj = productGraph()
            self.shipment_obj = shipmentGraph()
            self.far_obj = farGraph()
            self.general_obj = generalGraph()
            self.multiple_product_obj = multipleProduct()
            # self.prod_management_obj  = prodManagementGraph()

        except Exception:
            print(f'Error in __init__ {traceback.print_exc()}')

    def sanitize_unicode(self, text):
        try:
            if isinstance(text, str):
                text = static_response._UNICODE_PATTERN.sub(lambda m: static_response.UNICODE_REPLACEMENTS[m.group(0)],
                                                            text)
        except Exception:
            print(f'Error in sanitize_unicode {traceback.print_exc()}')
        return text

    def find(self, d, key='responses'):
        result = ""
        try:
            if isinstance(d, dict):
                if key in d:
                    return d[key]
                for v in d.values():
                    result = self.find(v, key)
                    if result is not None:
                        return result
            elif isinstance(d, list):
                for item in d:
                    result = self.find(item, key)
                    if result is not None:
                        return result
        except Exception:
            pass
        return result

    async def invoke_product_streaming_bot(self, payload):
        output = ""
        accumulated_answer = ""
        formatted_input = ""
        intent = ""
        sql = ""
        reasoning_text = ""
        step = 0
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())
            async for event in self.product_obj.product_app.astream_events(
                payload,
                config={"metadata": {"langfuse_tags": [config_data.environment, "product_bot"]}},
                version="v1",
            ):
                evt = event["event"]
                data = event["data"]
                name = event.get("name")
                tags = event.get("tags", [])

                # ✅ STARTING: Detect when LLM starts in summarizer
                if evt == "on_chat_model_start" and "final_response" in tags:
                    is_streaming = True
                    accumulated_answer = ""

                    # Send start signal
                    start_content = {
                        'content': '',
                        'type': 'stream_start',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id":message_id

                    }
                    yield f"data: {json.dumps(start_content)} \n\n"

                elif evt == "on_chat_model_stream" and "final_response" in tags:
                    chunk = data.get("chunk")
                    if chunk and hasattr(chunk, 'content') and chunk.content:
                        accumulated_answer += chunk.content
                        streaming_content = {
                            'content': chunk.content,
                            'type': 'stream_chunk',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        # Fix: Use json.dumps() properly
                        yield f"data: {json.dumps(streaming_content)} \n\n"

                elif evt == "on_chat_model_end" and "final_response" in tags:
                    # Send end signal
                    end_content = {
                        'content': "",
                        'type': 'stream_end',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id": message_id
                    }
                    yield f"data: {json.dumps(end_content)} \n\n"

                # Node finished:
                if evt == "on_chain_end":
                    print(f'{name} *** {data}')
                    if name == 'question_classifier':
                        step += 1
                        # reasoning will be sent after sql_generator produces it
                    elif name == 'memory_node':
                        step += 1
                        if 'output' in data and 'memory' in data['output'] and data['output']['memory'] != None:
                            formatted_input = data['output']['memory'][0]
                            resp = random.choice(static_response.memory_response).format(data['output']['memory'][0])
                            response_template = {"content": resp, "chat_id": payload['chat_id'], "step": step,
                                                 "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                            yield f"data: {json.dumps(response_template)} \n\n"
                    elif name == 'sql_generator':
                        step += 1
                        # Use generated reasoning from state if available
                        reasoning_text = data.get('output', {}).get('sql_reasoning', None)
                        if not reasoning_text:
                            reasoning_text = random.choice(static_response.retrieving_responses)
                        response_template = {"content": reasoning_text, "chat_id": payload['chat_id'], "step": step,
                                             "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                        yield f"data: {json.dumps(response_template)} \n\n"

                    elif name in ('sql_error_handler', 'gpt_error_handler'):
                        step += 1
                        yield f"data: {json.dumps({'content': '', 'type': 'stream_start', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                        yield f"data: {json.dumps({'content': data['output']['final_answer'], 'type': 'stream_chunk', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                        yield f"data: {json.dumps({'content': '', 'type': 'stream_end', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"

                    elif name == 'LangGraph':
                        sql = "[]"
                        if 'summarizer' in data['output'] and 'sql' in data['output']['summarizer']:
                            sql = data['output']['summarizer']['sql']
                        if 'summarizer' in data['output'] and 'final_answer' in data['output']['summarizer']:
                            sql_result_dict = data['output']['summarizer'].get('sql_data_source', data['output']['summarizer'].get('sql_result', {}))
                            general_statement = data['output']['summarizer'].get('general_statement', "")
                            combined_results, sql_tables = classify_and_combine_sql_results_product(sql_result_dict)  
                            step += 1
                            output = data['output']['summarizer']['final_answer']
                            intent = data['output']['summarizer']['intent']
                            #sql_tables = data['output']['summarizer'].get('sql_tables', [])
                            response_template = {"type": "response_file", "sql": sql,
                                                 "chat_id": payload['chat_id'], "step": step, "message_id": message_id,
                                                 "user_id": payload['user_id'], "result_dataframe": json.dumps(combined_results),
                                                 "general_statement": general_statement, "sql_tables": sql_tables}
                            yield f"data: {json.dumps(response_template, ensure_ascii=False)} \n\n"
                        else:
                            _handler_out = next(
                                (data['output'][k] for k in ('gpt_error_handler', 'sql_error_handler', 'timeout_handler')
                                 if k in data.get('output', {})), None)
                            if _handler_out:
                                output = _handler_out.get('final_answer', '') or self.find(data)
                                intent = _handler_out.get('intent') or intent
                                sql    = _handler_out.get('sql') or '[]'
                            else:
                                output = self.find(data)

            output = self.sanitize_unicode(output)
            final_output = {
                "model_output": output,
                "sql":sql,
                "intent":intent,
                "reasoning": reasoning_text
            }
            execution_time = time.perf_counter() - start_time
            message_table_data = {
                "message_id": message_id, "chat_id": payload['chat_id'], "user_id":payload['user_id'],
                "input_message": json.dumps({
                    "user_input":payload['user_input'],
                    "formatted_input": formatted_input
                }), "model_response": json.dumps(final_output), "vote": "", "feedback": "",
                "latency": int(float(f"{execution_time:.2f}")), "topic_id": "product_bot", "meta_data": "{}"
            }
            sql_service.insert_chat_history(message_table_data)
            sql_service.insert_session_data(message_table_data)

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.get('chat_id'),
                payload['user_id'],
                locals().get('message_id', ''),
            )


    async def invoke_shipment_streaming_bot(self, payload):
        output = ""
        accumulated_answer = ""
        formatted_input = ""
        sql = ""
        intent = ""
        reasoning_text = ""
        step = 0
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())
            async for event in self.shipment_obj.shipment_app.astream_events(
                payload,
                config=config_data.get_langfuse_config("shipment_bot"),
                version="v1",
            ):
                evt = event["event"]
                data = event["data"]
                name = event.get("name")
                tags = event.get("tags", [])

                # ✅ STARTING: Detect when LLM starts in summarizer
                if evt == "on_chat_model_start" and "final_response" in tags:
                    is_streaming = True
                    accumulated_answer = ""

                    # Send start signal
                    start_content = {
                        'content': '',
                        'type': 'stream_start',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id":message_id

                    }
                    yield f"data: {json.dumps(start_content)} \n\n"

                elif evt == "on_chat_model_stream" and "final_response" in tags:
                    chunk = data.get("chunk")
                    if chunk and hasattr(chunk, 'content') and chunk.content:
                        accumulated_answer += chunk.content
                        streaming_content = {
                            'content': chunk.content,
                            'type': 'stream_chunk',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        # Fix: Use json.dumps() properly
                        yield f"data: {json.dumps(streaming_content)} \n\n"

                elif evt == "on_chat_model_end" and "final_response" in tags:
                    # Send end signal
                    end_content = {
                        'content': "",
                        'type': 'stream_end',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id": message_id
                    }
                    yield f"data: {json.dumps(end_content)} \n\n"

                # Node finished:
                if evt == "on_chain_end":
                    print(f'{name} *** {data}')
                    if name == 'question_classifier':
                        step += 1
                        # reasoning will be sent after sql_generator produces it
                    elif name == 'memory_node':
                        step += 1
                        if 'output' in data and 'memory' in data['output'] and data['output']['memory'] != None:
                            formatted_input = data['output']['memory'][0]
                            resp = random.choice(static_response.memory_response).format(data['output']['memory'][0])
                            response_template = {"content": resp, "chat_id": payload['chat_id'], "step": step,
                                                 "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                            yield f"data: {json.dumps(response_template)} \n\n"
                    elif name == 'sql_generator':
                        step += 1
                        # Use generated reasoning from state if available
                        reasoning_text = data.get('output', {}).get('sql_reasoning', None)
                        if not reasoning_text:
                            reasoning_text = random.choice(static_response.retrieving_responses)
                        response_template = {"content": reasoning_text, "chat_id": payload['chat_id'], "step": step,
                                             "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                        yield f"data: {json.dumps(response_template)} \n\n"

                    elif name in ('timeout_handler', 'sql_error_handler', 'gpt_error_handler'):
                        step += 1
                        start_content = {
                            'content': '',
                            'type': 'stream_start',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        yield f"data: {json.dumps(start_content)} \n\n"
                        streaming_content = {
                            'content': data['output']['final_answer'],
                            'type': 'stream_chunk',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        yield f"data: {json.dumps(streaming_content)} \n\n"
                        end_content = {
                            'content': "",
                            'type': 'stream_end',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        yield f"data: {json.dumps(end_content)} \n\n"


                    elif name == 'LangGraph':
                        sql = "[]"
                        if 'summarizer' in data['output'] and 'sql' in data['output']['summarizer']:
                            sql = data['output']['summarizer']['sql']
                        if 'summarizer' in data['output'] and 'final_answer' in data['output']['summarizer']:
                            sql_result_dict = data['output']['summarizer'].get('sql_data_source', data['output']['summarizer'].get('sql_result', {}))
                            # combined_df = pd.DataFrame()
                            combined_results = {}
                            for df_key, csv_str in sql_result_dict.items():
                                df = pd.read_csv(StringIO(csv_str), sep='|')
                                df = df.drop(['variant_descr'], axis=1, errors='ignore')
                                df = df.replace({np.nan:"null"})
                                df = df.fillna("null")
                                df = df.astype(str)
                                # combined_df = pd.concat([combined_df, df], ignore_index=True)
                                records = df.to_dict(orient='records')
                                combined_results[df_key] = records
                            # combined_results['df_1'] = combined_df.to_dict(orient='records')
                            step += 1
                            output = data['output']['summarizer']['final_answer']
                            intent = data['output']['summarizer']['intent']
                            sql_tables = data['output']['summarizer'].get('sql_tables', [])
                            response_template = {"type": "response_file", "sql" : sql,
                                                 "chat_id": payload['chat_id'], "step": step, "message_id":message_id,
                                                 "user_id": payload['user_id'], "result_dataframe":json.dumps(combined_results),
                                                 "sql_tables": sql_tables}
                            yield f"data: {json.dumps(response_template, ensure_ascii=False)} \n\n"
                        else:
                            _handler_out = next(
                                (data['output'][k] for k in ('gpt_error_handler', 'sql_error_handler', 'timeout_handler')
                                 if k in data.get('output', {})), None)
                            if _handler_out:
                                output = _handler_out.get('final_answer', '') or self.find(data)
                                intent = _handler_out.get('intent') or intent
                                sql    = _handler_out.get('sql') or '[]'
                            else:
                                output = self.find(data)

            output = self.sanitize_unicode(output)
            final_output = {
                "model_output": output,
                "sql": sql,
                "intent": intent,
                "reasoning": reasoning_text
            }
            execution_time = time.perf_counter() - start_time
            message_table_data = {
                "message_id": message_id, "chat_id": payload['chat_id'], "user_id":payload['user_id'],
                "input_message": json.dumps({
                    "user_input":payload['user_input'],
                    "formatted_input": formatted_input
                }), "model_response": json.dumps(final_output), "vote": "", "feedback": "",
                "latency": int(float(f"{execution_time:.2f}")), "topic_id": "shipment_bot", "meta_data": "{}"
            }
            sql_service.insert_chat_history(message_table_data)
            sql_service.insert_session_data(message_table_data)

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.get('chat_id'),
                payload['user_id'],
                locals().get('message_id', ''),
            )


    async def invoke_far_streaming_bot(self, payload):
        output = ""
        accumulated_answer = ""
        formatted_input = ""
        sql = ""
        intent = ""
        reasoning_text = ""
        step = 0
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())
            async for event in self.far_obj.far_app.astream_events(
                payload,
                config=config_data.get_langfuse_config("far_bot"),
                version="v1",
            ):
                evt = event["event"]
                data = event["data"]
                name = event.get("name")
                tags = event.get("tags", [])

                # ✅ STARTING: Detect when LLM starts in summarizer
                if evt == "on_chat_model_start" and "final_response" in tags:
                    is_streaming = True
                    accumulated_answer = ""

                    # Send start signal
                    start_content = {
                        'content': '',
                        'type': 'stream_start',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id":message_id

                    }
                    yield f"data: {json.dumps(start_content)} \n\n"

                elif evt == "on_chat_model_stream" and "final_response" in tags:
                    chunk = data.get("chunk")
                    if chunk and hasattr(chunk, 'content') and chunk.content:
                        accumulated_answer += chunk.content
                        streaming_content = {
                            'content': chunk.content,
                            'type': 'stream_chunk',
                            'chat_id': payload.get('chat_id'),
                            'step': step,
                            "user_id": payload['user_id'],
                            "message_id": message_id
                        }
                        # Fix: Use json.dumps() properly
                        yield f"data: {json.dumps(streaming_content)} \n\n"

                elif evt == "on_chat_model_end" and "final_response" in tags:
                    # Send end signal
                    end_content = {
                        'content': "",
                        'type': 'stream_end',
                        'chat_id': payload.get('chat_id'),
                        'step': step,
                        "user_id": payload['user_id'],
                        "message_id": message_id
                    }
                    yield f"data: {json.dumps(end_content)} \n\n"

                # Node finished:
                if evt == "on_chain_end":
                    print(f'{name} *** {data}')
                    if name == 'question_classifier':
                        step += 1
                        # reasoning will be sent after sql_generator produces it
                    elif name == 'memory_node':
                        step += 1
                        if 'output' in data and 'memory' in data['output'] and data['output']['memory'] != None:
                            formatted_input = data['output']['memory'][0]
                            resp = random.choice(static_response.memory_response).format(data['output']['memory'][0])
                            response_template = {"content": resp, "chat_id": payload['chat_id'], "step": step,
                                                 "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                            yield f"data: {json.dumps(response_template)} \n\n"
                    elif name == 'sql_generator':
                        step += 1
                        # Use generated reasoning from state if available (FAR bot)
                        reasoning_text = data.get('output', {}).get('sql_reasoning', None)
                        if not reasoning_text:
                            reasoning_text = random.choice(static_response.retrieving_responses)
                        response_template = {"content": reasoning_text, "chat_id": payload['chat_id'], "step": step,
                                             "user_id": payload['user_id'], 'type': 'reasoning', "message_id":message_id}
                        yield f"data: {json.dumps(response_template)} \n\n"

                    elif name in ('sql_error_handler', 'gpt_error_handler'):
                        step += 1
                        yield f"data: {json.dumps({'content': '', 'type': 'stream_start', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                        yield f"data: {json.dumps({'content': data['output']['final_answer'], 'type': 'stream_chunk', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                        yield f"data: {json.dumps({'content': '', 'type': 'stream_end', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"

                    elif name == 'LangGraph':
                        sql = "[]"
                        if 'summarizer' in data['output'] and 'sql' in data['output']['summarizer']:
                            sql = data['output']['summarizer']['sql']
                        if 'summarizer' in data['output'] and 'final_answer' in data['output']['summarizer']:
                            sql_result_dict = data['output']['summarizer'].get('sql_data_source', data['output']['summarizer'].get('sql_result', {}))
                            # combined_df = pd.DataFrame()
                            combined_results = {}
                            for df_key, csv_str in sql_result_dict.items():
                                df = pd.read_csv(StringIO(csv_str), sep='|')
                                df = df.drop(['variant_descr'], axis=1, errors='ignore')
                                df = df.replace({np.nan:"null"})
                                df = df.fillna("null")
                                df = df.astype(str)
                                #combined_df = pd.concat([combined_df, df], ignore_index=True)
                                records = df.to_dict(orient='records')
                                combined_results[df_key] = records
                            #combined_results['df_1'] = combined_df.to_dict(orient='records')
                            step += 1
                            output = data['output']['summarizer']['final_answer']
                            intent = data['output']['summarizer']['intent']
                            sql_tables = data['output']['summarizer'].get('sql_tables', [])
                            response_template = {"type": "response_file", "sql" : sql,
                                                 "chat_id": payload['chat_id'], "step": step, "message_id":message_id,
                                                 "user_id": payload['user_id'], "result_dataframe":json.dumps(combined_results),
                                                 "sql_tables": sql_tables}
                            yield f"data: {json.dumps(response_template, ensure_ascii=False)} \n\n"
                        else:
                            _handler_out = next(
                                (data['output'][k] for k in ('gpt_error_handler', 'sql_error_handler', 'timeout_handler')
                                 if k in data.get('output', {})), None)
                            if _handler_out:
                                output = _handler_out.get('final_answer', '') or self.find(data)
                                intent = _handler_out.get('intent') or intent
                                sql    = _handler_out.get('sql') or '[]'
                            else:
                                output = self.find(data)

            output = self.sanitize_unicode(output)
            final_output = {
                "model_output": output,
                "sql": sql,
                "intent": intent,
                "reasoning": reasoning_text
            }
            execution_time = time.perf_counter() - start_time
            message_table_data = {
                "message_id": message_id, "chat_id": payload['chat_id'], "user_id":payload['user_id'],
                "input_message": json.dumps({
                    "user_input":payload['user_input'],
                    "formatted_input": formatted_input
                }), "model_response": json.dumps(final_output), "vote": "", "feedback": "",
                "latency": int(float(f"{execution_time:.2f}")), "topic_id": "far_bot", "meta_data": "{}"
            }
            sql_service.insert_chat_history(message_table_data)
            sql_service.insert_session_data(message_table_data)

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.get('chat_id'),
                payload['user_id'],
                locals().get('message_id', ''),
            )


    async def invoke_universal_streaming_bot(self, payload):
        """Streaming SSE response for the `universal_agent` orchestrator (deepagents-based
        product/shipment/far router). `stream_universal_agent_turn_events` (agent.py) uses
        deepagents' typed `version="v3"` streaming protocol to forward coordinator text as
        `on_chat_model_stream` and delegated answer-node text as labeled
        `on_subagent_chat_model_stream` events. Those become distinct `stream_chunk` and
        `subagent_stream_chunk` SSE types so intermediate answers cannot be mistaken for the
        coordinator's final synthesis. We also drain `UniversalAgentContext.progress_events`
        so delegated-task and SQL reasoning milestones remain visible alongside the streams.

        Final answer SSE events (`stream_start`/`stream_chunk`/`stream_end`/`response_file`)
        mirror the other bot endpoints. Intermediate delegated text is sent separately as
        `subagent_stream_chunk` with its `subagent` label, which clients should render apart
        from the final answer. In particular, `response_file.sql` is JSON-encoded to a string
        here (unlike the list `build_full_result` returns), matching the other bot endpoints.

        `step` semantics also now mirror the other bots: `stream_start`/`stream_chunk`/
        `stream_end` for the final answer all share one `text_step` snapshot taken the moment
        streaming begins (like product bot's `on_chat_model_start` bracket sharing the node's
        current step), while `reasoning` progress events keep incrementing the live `step`
        counter independently -- so trailing reasoning milestones never shift the answer
        bracket's step after the fact. `response_file` still gets the final incremented step.
        """
        output = ""
        sql = []
        intent = []
        reasoning_text = ""
        step = 0
        text_step = None
        result = None
        accumulated_answer = ""
        is_streaming = False
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())
            logger.info(
                f"[invoke_universal_streaming_bot] Starting chat_id={payload.chat_id}, "
                f"user_id={payload.user_id}, user_input={payload.user_input!r}"
            )

            context = UniversalAgentContext(user_id=payload.user_id, chat_id=payload.chat_id)
            reported_events = 0

            def _drain_progress_events():
                nonlocal reported_events, step
                rendered = []
                while reported_events < len(context.progress_events):
                    entry = context.progress_events[reported_events]
                    reported_events += 1
                    content = _render_universal_progress_event(entry)
                    if not content:
                        continue
                    step += 1
                    rendered.append({
                        'content': content,
                        'chat_id': payload.chat_id,
                        'step': step,
                        'user_id': payload.user_id,
                        'type': 'reasoning',
                        'subagent': entry.get('subagent', 'unknown'),
                        'message_id': message_id,
                    })
                return rendered

            async for event in stream_universal_agent_turn_events(
                payload.user_input,
                payload.user_id,
                payload.chat_id,
                context,
            ):
                for template in _drain_progress_events():
                    yield f"data: {json.dumps(template)} \n\n"

                event_type = event.get('event')

                if event_type == 'on_subagent_chat_model_stream':
                    chunk = (event.get('data') or {}).get('chunk')
                    chunk_content = getattr(chunk, 'content', '') if chunk else ''
                    if chunk_content:
                        subagent_content = {
                            'content': chunk_content,
                            'type': 'subagent_stream_chunk',
                            'subagent': event.get('subagent', 'unknown'),
                            'chat_id': payload.chat_id,
                            'step': step,
                            'user_id': payload.user_id,
                            'message_id': message_id,
                        }
                        yield f"data: {json.dumps(subagent_content)} \n\n"
                    continue

                if event_type == 'on_chat_model_stream':
                    chunk = (event.get('data') or {}).get('chunk')
                    chunk_content = getattr(chunk, 'content', '') if chunk else ''
                    if chunk_content:
                        if not is_streaming:
                            is_streaming = True
                            text_step = step
                            accumulated_answer = ""
                            start_content = {
                                'content': '',
                                'type': 'stream_start',
                                'chat_id': payload.chat_id,
                                'step': text_step,
                                'user_id': payload.user_id,
                                'message_id': message_id,
                            }
                            yield f"data: {json.dumps(start_content)} \n\n"
                        accumulated_answer += chunk_content
                        streaming_content = {
                            'content': chunk_content,
                            'type': 'stream_chunk',
                            'chat_id': payload.chat_id,
                            'step': text_step,
                            'user_id': payload.user_id,
                            'message_id': message_id,
                        }
                        yield f"data: {json.dumps(streaming_content)} \n\n"
                    continue

                if event_type != 'on_chain_end':
                    continue

                data = event.get('data') or {}
                if event.get('name') == 'LangGraph':
                    result = data.get('output') or {}

            for template in _drain_progress_events():
                yield f"data: {json.dumps(template)} \n\n"

            if result is None:
                raise RuntimeError('Universal agent completed without a LangGraph output event')

            full_result = build_full_result(payload.user_input, payload.user_id, payload.chat_id, result, context)
            output = self.sanitize_unicode(full_result['model_output'])
            sql = full_result['sql']
            intent = full_result['intent']
            reasoning_text = full_result['reasoning']

            # Do not emit the aggregate `reasoning_text` here. It is built from each
            # sub-agent's intermediate SQL reasoning and often repeats the same task
            # wording already displayed in the per-hop `subagent_started` and
            # `sql_generated` events above.
            if not is_streaming:
                # Fallback for models/events that never produced incremental content chunks --
                # wrap the full answer in the same start/chunk/end bracket the token-streaming
                # path uses (pinned to the current step) so the UI renders it identically.
                text_step = step
                yield f"data: {json.dumps({'content': '', 'type': 'stream_start', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"
                yield f"data: {json.dumps({'content': output, 'type': 'stream_chunk', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"
            yield f"data: {json.dumps({'content': '', 'type': 'stream_end', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"

            step += 1
            combined_results = universal_sql_data_source_to_records(full_result['sql_data_source'])
            response_template = {
                # `sql` is JSON-encoded (a string) here, not a raw list, so this event
                # matches the wire shape product/shipment/far_bot's `response_file` already
                # use -- the shared UI reads `sql` as a string on every bot.
                "type": "response_file", "sql": json.dumps(sql), "chat_id": payload.chat_id, "step": step,
                "message_id": message_id, "user_id": payload.user_id,
                "result_dataframe": json.dumps(combined_results),
                "sql_data_source": full_result['sql_data_source'],
                "general_statement": reasoning_text, "sql_tables": full_result['sql_tables'],
            }
            yield f"data: {json.dumps(response_template, ensure_ascii=False)} \n\n"

            execution_time = time.perf_counter() - start_time
            final_output = {"model_output": output, "sql": sql, "intent": intent, "reasoning": reasoning_text}
            message_table_data = {
                "message_id": message_id, "chat_id": payload.chat_id, "user_id": payload.user_id,
                "input_message": json.dumps({"user_input": payload.user_input, "formatted_input": payload.user_input}),
                "model_response": json.dumps(final_output), "vote": "", "feedback": "",
                # `invoke_universal_agent_full` already persists chat_history (needed for
                # follow-up context resolution), so only session data is recorded here.
                "latency": int(float(f"{execution_time:.2f}")), "topic_id": "universal_agent", "meta_data": "{}"
            }
            sql_service.insert_session_data(message_table_data)
            logger.info(
                f"[invoke_universal_streaming_bot] Completed chat_id={payload.chat_id}, "
                f"latency={execution_time:.2f}s, output_length={len(output)}, intent={intent}"
            )

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.chat_id,
                payload.user_id,
                locals().get('message_id', ''),
            )

    async def invoke_universal_skills_streaming_bot(self, payload):
        """Streaming SSE response for the universal agent in skills mode
        (`agent.is_skill_invocation = True`).

        Same wire contract and `step` semantics as `invoke_universal_streaming_bot`:
          reasoning            skill milestones (skill loaded, reference read, script run/failed);
                               increments the live `step`, carries a `skill` label
          skill_stream_chunk   intermediate coordinator text while working a skill; carries `skill`
                               (the counterpart of `subagent_stream_chunk`)
          stream_start/chunk/end  final answer, all pinned to one `text_step`
          response_file        final incremented step; `sql` JSON-encoded; adds `skills_used`
        """
        output = ""
        sql = []
        intent = []
        reasoning_text = ""
        step = 0
        text_step = None
        result = None
        is_streaming = False
        skills_used = []
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())
            logger.info(
                f"[invoke_universal_skills_streaming_bot] Starting chat_id={payload.chat_id}, "
                f"user_id={payload.user_id}, user_input={payload.user_input!r}"
            )

            context = UniversalAgentContext(user_id=payload.user_id, chat_id=payload.chat_id)

            async for event in stream_universal_skill_turn_events(
                payload.user_input,
                payload.user_id,
                payload.chat_id,
                context,
            ):
                event_type = event.get('event')

                if event_type in ('on_skill_start', 'on_skill_progress'):
                    skill = event.get('skill', 'unknown')
                    if event_type == 'on_skill_start' and skill not in skills_used:
                        skills_used.append(skill)
                    content = _render_skill_progress_event(event)
                    if content:
                        step += 1
                        reasoning_content = {
                            'content': content,
                            'chat_id': payload.chat_id,
                            'step': step,
                            'user_id': payload.user_id,
                            'type': 'reasoning',
                            'skill': skill,
                            'message_id': message_id,
                        }
                        yield f"data: {json.dumps(reasoning_content)} \n\n"
                    continue

                if event_type == 'on_skill_chat_model_stream':
                    chunk = (event.get('data') or {}).get('chunk')
                    chunk_content = getattr(chunk, 'content', '') if chunk else ''
                    if chunk_content:
                        skill_content = {
                            'content': chunk_content,
                            'type': 'skill_stream_chunk',
                            'skill': event.get('skill', 'unknown'),
                            'chat_id': payload.chat_id,
                            'step': step,
                            'user_id': payload.user_id,
                            'message_id': message_id,
                        }
                        yield f"data: {json.dumps(skill_content)} \n\n"
                    continue

                if event_type == 'on_chat_model_stream':
                    chunk = (event.get('data') or {}).get('chunk')
                    chunk_content = getattr(chunk, 'content', '') if chunk else ''
                    if chunk_content:
                        if not is_streaming:
                            is_streaming = True
                            text_step = step
                            start_content = {
                                'content': '',
                                'type': 'stream_start',
                                'chat_id': payload.chat_id,
                                'step': text_step,
                                'user_id': payload.user_id,
                                'message_id': message_id,
                            }
                            yield f"data: {json.dumps(start_content)} \n\n"
                        streaming_content = {
                            'content': chunk_content,
                            'type': 'stream_chunk',
                            'chat_id': payload.chat_id,
                            'step': text_step,
                            'user_id': payload.user_id,
                            'message_id': message_id,
                        }
                        yield f"data: {json.dumps(streaming_content)} \n\n"
                    continue

                if event_type == 'on_chain_end' and event.get('name') == 'LangGraph':
                    result = (event.get('data') or {}).get('output') or {}

            if result is None:
                raise RuntimeError('Universal skills agent completed without a LangGraph output event')

            # Also saves chat_history (save_turn) so follow-up questions keep context.
            full_result = build_full_result(payload.user_input, payload.user_id, payload.chat_id, result, context)
            output = self.sanitize_unicode(full_result['model_output'])
            sql = full_result['sql']
            intent = full_result['intent'] or ", ".join(skills_used)
            reasoning_text = full_result['reasoning']

            if not is_streaming:
                # Fallback when no incremental text arrived: wrap the full answer in the
                # same start/chunk/end bracket so the UI renders it identically.
                text_step = step
                yield f"data: {json.dumps({'content': '', 'type': 'stream_start', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"
                yield f"data: {json.dumps({'content': output, 'type': 'stream_chunk', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"
            yield f"data: {json.dumps({'content': '', 'type': 'stream_end', 'chat_id': payload.chat_id, 'step': text_step, 'user_id': payload.user_id, 'message_id': message_id})} \n\n"

            step += 1
            combined_results = universal_sql_data_source_to_records(full_result['sql_data_source'])
            response_template = {
                "type": "response_file", "sql": json.dumps(sql), "chat_id": payload.chat_id, "step": step,
                "message_id": message_id, "user_id": payload.user_id,
                "result_dataframe": json.dumps(combined_results),
                "sql_data_source": full_result['sql_data_source'],
                "general_statement": reasoning_text, "sql_tables": full_result['sql_tables'],
                "skills_used": skills_used,
            }
            yield f"data: {json.dumps(response_template, ensure_ascii=False)} \n\n"

            execution_time = time.perf_counter() - start_time
            final_output = {"model_output": output, "sql": sql, "intent": intent,
                            "reasoning": reasoning_text, "skills_used": skills_used}
            message_table_data = {
                "message_id": message_id, "chat_id": payload.chat_id, "user_id": payload.user_id,
                "input_message": json.dumps({"user_input": payload.user_input, "formatted_input": payload.user_input}),
                "model_response": json.dumps(final_output), "vote": "", "feedback": "",
                "latency": int(float(f"{execution_time:.2f}")), "topic_id": "universal_agent_skills",
                "meta_data": json.dumps({"skills_used": skills_used}),
            }
            sql_service.insert_session_data(message_table_data)
            logger.info(
                f"[invoke_universal_skills_streaming_bot] Completed chat_id={payload.chat_id}, "
                f"latency={execution_time:.2f}s, output_length={len(output)}, skills={skills_used}"
            )

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.chat_id,
                payload.user_id,
                locals().get('message_id', ''),
            )

    async def invoke_universal_bot(self, payload):
        """Return the universal response in the same state shape as product_bot."""
        try:
            full_result = invoke_universal_agent_full(payload.user_input, payload.user_id, payload.chat_id)
            combined_results = universal_sql_data_source_to_records(full_result['sql_data_source'])
            return {
                "topic_id": "universal_bot",
                "chat_id": payload.chat_id,
                "user_id": payload.user_id,
                "user_input": payload.user_input,
                "user_translated_input": None,
                "intent": full_result['intent'],
                "memory": [payload.user_input],
                "sql": full_result['sql'],
                "sql_result": full_result['sql_data_source'],
                "sql_data_source": full_result['sql_data_source'],
                "sql_tables": full_result['sql_tables'],
                "error": None,
                "retry_query": None,
                "valid": True,
                "stop_iteration": False,
                "retry_count": 0,
                "final_answer": full_result['model_output'],
                "responses": full_result['model_output'],
                "reasoning": full_result['reasoning'],
                "gpt_error": False,
                "sql_error": False,
                "result_dataframe": combined_results,
            }
        except Exception:
            print(f'Error in invoke_universal_bot {traceback.print_exc()}')
            return {}

    async def invoke_product_bot(self, state, payload):
        result = {}
        try:
            result = await self.product_obj.product_app.ainvoke(state)
        except Exception:
            print(f'Error in invoke_product_bot {traceback.print_exc()}')
        return result

    async def invoke_far_bot(self, state, payload):
        result = {}
        try:
            result = await self.far_obj.far_app.ainvoke(state)
        except Exception:
            print(f'Error in invoke_product_bot {traceback.print_exc()}')
        return result

    async def invoke_shipment_bot(self, state, payload):
        result = {}
        try:
            result = await self.shipment_obj.shipment_app.ainvoke(state)
        except Exception:
            print(f'Error in invoke_shipment_bot {traceback.print_exc()}')
        return result

    # async def invoke_general_streaming_bot(self, payload):
    #     """Streaming response for general bot"""
    #     output = ""
    #     step = 0
    #     try:
    #         start_time = time.perf_counter()
    #         message_id = str(uuid.uuid4())
    #         async for event in self.general_obj.general_app.astream_events(payload, config={"callbacks": [config_data.langfuse_handler],
    #                                                                     "metadata": {
    #                                                                         "langfuse_tags": [config_data.environment, "general_bot"]
    #                                                                     }}, version="v1"):
    #             evt = event["event"]
    #             data = event["data"]
    #             name = event.get("name")

    #             # Stream LLM tokens
    #             if evt == "on_chat_model_stream":
    #                 chunk = data["chunk"]
    #                 content = chunk.content
    #                 if content:
    #                     output += content
    #                     response_template = {
    #                         "type": "response",
    #                         "content": content,
    #                         "chat_id": payload.get('chat_id'),
    #                         "step": step,
    #                         "user_id": payload['user_id'],
    #                         "message_id": message_id
    #                     }
    #                     yield f"data: {json.dumps(response_template)} \n\n"

    #             # Graph finished
    #             if evt == "on_chain_end" and name == 'LangGraph':
    #                 step += 1
    #                 end_content = {
    #                     'type': 'end',
    #                     'chat_id': payload.get('chat_id'),
    #                     'step': step,
    #                     "user_id": payload['user_id'],
    #                     "message_id": message_id
    #                 }
    #                 yield f"data: {json.dumps(end_content)} \n\n"

    #         execution_time = time.perf_counter() - start_time
    #         message_table_data = {
    #             "message_id": message_id,
    #             "chat_id": payload['chat_id'],
    #             "user_id": payload['user_id'],
    #             "input_message": json.dumps({"user_input": payload['user_input']}),
    #             "model_response": output,
    #             "vote": "",
    #             "feedback": "",
    #             "latency": int(float(f"{execution_time:.2f}")),
    #             "topic_id": "general_bot",
    #             "meta_data": "{}"
    #         }
    #         sql_service.insert_chat_history(message_table_data)
    #         sql_service.insert_session_data(message_table_data)

    #     except Exception as e:
    #         print(str(traceback.print_exc()))
    #         yield json.dumps({
    #             "type": "error",
    #             "message": str(traceback.print_exc())
    #         }) + "\n"

    # async def invoke_general_bot(self, state, payload):
    #     """Non-streaming response for general bot"""
    #     result = {}
    #     try:
    #         result = self.general_obj.general_app.invoke(state)
    #     except Exception:
    #         print(f'Error in invoke_general_bot {traceback.print_exc()}')
    #     return result

    async def invoke_prod_management_streaming_bot(self, payload):
        """Streaming SSE response for production management document queries."""
        output = ""
        formatted_input = ""
        sources = []
        step = 0
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())

            async for event in self.prod_management_obj.prod_management_app.astream_events(
                payload,
                config=config_data.get_langfuse_config("prod_management"),
                version="v1",
            ):
                evt  = event["event"]
                data = event["data"]
                name = event.get("name")

                # ── Node completion events only ────────────────────────────
                if evt == "on_chain_end":
                    if name == "memory_node":
                        step += 1
                        if data.get("output", {}).get("memory"):
                            formatted_input = data["output"]["memory"][0]
                            resp = random.choice(static_response.memory_response).format(formatted_input)
                            yield f"data: {json.dumps({'content': resp, 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'type': 'reasoning', 'message_id': message_id})} \n\n"
                        step += 1
                        yield f"data: {json.dumps({'content': random.choice(static_response.retrieving_responses), 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'type': 'reasoning', 'message_id': message_id})} \n\n"

                    elif name == "retrieve_documents_and_answer":
                        node_out = data.get("output") or {}
                        if node_out.get("sources"):
                            sources = node_out["sources"]

                    elif name == "LangGraph":
                        step += 1
                        graph_out = data.get("output") or {}
                        output = (
                            graph_out.get("finalize_response", {}).get("responses")
                            or graph_out.get("responses")
                            or ""
                        )
                        # sources are set by retrieve_documents_and_answer; finalize_response
                        # may only emit the keys it directly changed, so check all locations
                        sources = (
                            sources  # already captured from retrieve_documents_and_answer event
                            or graph_out.get("finalize_response", {}).get("sources")
                            or graph_out.get("retrieve_documents_and_answer", {}).get("sources")
                            or graph_out.get("sources")
                            or []
                        )
                        if output:
                            output = replace_s3_images_with_base64(
                                output, config_data.s3_client, config_data.s3_bucket_name
                            )
                            yield f"data: {json.dumps({'content': '', 'type': 'stream_start', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                            yield f"data: {json.dumps({'content': output, 'type': 'stream_chunk', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                            yield f"data: {json.dumps({'content': '', 'type': 'stream_end', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id})} \n\n"
                        yield f"data: {json.dumps({'type': 'response_file', 'chat_id': payload.get('chat_id'), 'step': step, 'user_id': payload['user_id'], 'message_id': message_id, 'sources': sources})} \n\n"

            execution_time = time.perf_counter() - start_time
            final_output = {
                "model_output": output,
                "sources": sources,
            }
            message_table_data = {
                "message_id":    message_id,
                "chat_id":       payload["chat_id"],
                "user_id":       payload["user_id"],
                "input_message": json.dumps({
                    "user_input":      payload["user_input"],
                    "formatted_input": formatted_input,
                }),
                "model_response": json.dumps(final_output),
                "vote":     "",
                "feedback": "",
                "latency":  int(float(f"{execution_time:.2f}")),
                "topic_id": "prod_management",
                "meta_data": "{}",
            }
            sql_service.insert_chat_history(message_table_data)
            sql_service.insert_session_data(message_table_data)

        except Exception as e:
            yield _format_stream_error_event(
                e,
                step,
                payload.get('chat_id'),
                payload['user_id'],
                locals().get('message_id', ''),
            )

    async def invoke_prod_management_bot(self, state: dict) -> dict:
        """Non-streaming invoke for production management document queries."""
        output = ""
        formatted_input = ""
        sources = []
        retrieval_query_text = None
        error = None
        try:
            start_time = time.perf_counter()
            message_id = str(uuid.uuid4())

            result = self.prod_management_obj.invoke(
                user_input        = state["user_input"],
                user_id           = state["user_id"],
                chat_id           = state["chat_id"],
                topic_id          = "prod_management",
                document_sub_type = state.get("document_sub_type"),
                location          = state.get("location"),
                prev_response     = state.get("prev_response", []),
            )

            output          = result.get("responses", "")
            if output:
                output = replace_s3_images_with_base64(
                    output, config_data.s3_client, config_data.s3_bucket_name
                )
            sources = result.get("sources", [])
            retrieval_query_text = result.get("retrieval_query_text")
            memory          = result.get("memory") or []
            formatted_input = memory[0] if memory else state["user_input"]
            error           = result.get("error")

            logger.info(
                f"[invoke_prod_management_bot] Response length: {len(output)}, "
                f"resolved query: {formatted_input!r}, error: {error}"
            )

            execution_time = time.perf_counter() - start_time
            final_output = {
                "model_output": output,
                "sources": sources,
                "retrieval_query_text": retrieval_query_text,
                "error": error,
            }
            message_table_data = {
                "message_id":    message_id,
                "chat_id":       state["chat_id"],
                "user_id":       state["user_id"],
                "input_message": json.dumps({
                    "user_input":      state["user_input"],
                    "formatted_input": formatted_input,
                }),
                "model_response": json.dumps(final_output),
                "vote":     "",
                "feedback": "",
                "latency":  int(float(f"{execution_time:.2f}")),
                "topic_id": "prod_management",
                "meta_data": "{}",
            }
            sql_service.insert_chat_history(message_table_data)
            sql_service.insert_session_data(message_table_data)

        except Exception:
            print(f"Error in invoke_prod_management_bot {traceback.print_exc()}")

        return {
            "responses": output,
            "sources": sources,
            "formatted_input": formatted_input,
            "retrieval_query_text": retrieval_query_text,
            "error": error,
        }

    async def invoke_multiple_product_bot(self, input_dict, attachment):
        result = {}
        filename = ""
        try:
            message_folder = os.path.join("process_id", input_dict['message_id'])
            input_data_folder = os.path.join(message_folder, "input_folder")
            os.makedirs(input_data_folder, exist_ok=True)
            fname = os.path.basename(attachment.filename)
            filename = fname.split(".")[0]
            file_path = os.path.join(input_data_folder, f"{uuid.uuid4()}.xlsx")
            input_dict['filepath'] = file_path
            input_dict['filename'] = fname
            with open(file_path, "wb") as f:
                content = attachment.file.read()
                f.write(content)
            result = self.multiple_product_obj.process_multiple_product(input_dict)
            if result['final_answer'] is None:
                wb = load_workbook(file_path)
                excel_bytes = io.BytesIO()
                wb.save(excel_bytes)
                excel_bytes.seek(0)
                result['final_answer'] = excel_bytes.getvalue()
            if os.path.exists(message_folder):
                shutil.rmtree(message_folder)
                print("Folder deleted successfully")


        except Exception:
            print(f'Error in invoke_product_bot {traceback.print_exc()}')
        return result, filename